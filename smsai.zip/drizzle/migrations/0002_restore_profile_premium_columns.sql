ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS is_premium boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS subscription_tier text NOT NULL DEFAULT 'Free',
  ADD COLUMN IF NOT EXISTS theme text NOT NULL DEFAULT 'midnight';