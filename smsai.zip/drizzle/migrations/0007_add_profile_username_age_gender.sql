ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS username TEXT,
  ADD COLUMN IF NOT EXISTS age INTEGER,
  ADD COLUMN IF NOT EXISTS gender TEXT;

ALTER TABLE public.profiles
  ADD CONSTRAINT profiles_age_range CHECK (age IS NULL OR (age >= 13 AND age <= 120)) NOT VALID;

ALTER TABLE public.profiles
  ADD CONSTRAINT profiles_gender_values CHECK (gender IS NULL OR gender IN ('female','male','non-binary','prefer-not-to-say')) NOT VALID;

CREATE UNIQUE INDEX IF NOT EXISTS profiles_username_lower_idx ON public.profiles (lower(username)) WHERE username IS NOT NULL;