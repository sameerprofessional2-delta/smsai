
-- 1. Switch has_role to SECURITY INVOKER so it runs as the caller (RLS on user_roles
-- still allows checking auth.uid()'s own roles via the existing SELECT policy).
CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role app_role)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY INVOKER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_id = _user_id AND role = _role
  )
$$;

-- 2. Trigger to block non-admin users from self-upgrading premium fields on profiles.
CREATE OR REPLACE FUNCTION public.enforce_profile_premium_guard()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  is_admin boolean;
BEGIN
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_id = auth.uid() AND role = 'admin'
  ) INTO is_admin;

  IF is_admin THEN
    RETURN NEW;
  END IF;

  IF NEW.is_premium IS DISTINCT FROM OLD.is_premium
     OR NEW.subscription_tier IS DISTINCT FROM OLD.subscription_tier
     OR NEW.plan IS DISTINCT FROM OLD.plan
     OR NEW.status IS DISTINCT FROM OLD.status THEN
    RAISE EXCEPTION 'Not authorized to modify subscription or status fields';
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS profiles_premium_guard ON public.profiles;
CREATE TRIGGER profiles_premium_guard
BEFORE UPDATE ON public.profiles
FOR EACH ROW
EXECUTE FUNCTION public.enforce_profile_premium_guard();

-- 3. Defense-in-depth: revoke any accidental write grants on user_roles from
-- authenticated/anon and add explicit deny policies for INSERT/UPDATE/DELETE.
REVOKE INSERT, UPDATE, DELETE ON public.user_roles FROM authenticated;
REVOKE INSERT, UPDATE, DELETE, SELECT ON public.user_roles FROM anon;

DROP POLICY IF EXISTS "Deny user_roles insert" ON public.user_roles;
CREATE POLICY "Deny user_roles insert" ON public.user_roles
  FOR INSERT TO authenticated
  WITH CHECK (false);

DROP POLICY IF EXISTS "Deny user_roles update" ON public.user_roles;
CREATE POLICY "Deny user_roles update" ON public.user_roles
  FOR UPDATE TO authenticated
  USING (false) WITH CHECK (false);

DROP POLICY IF EXISTS "Deny user_roles delete" ON public.user_roles;
CREATE POLICY "Deny user_roles delete" ON public.user_roles
  FOR DELETE TO authenticated
  USING (false);
