
REVOKE EXECUTE ON FUNCTION public.enforce_profile_premium_guard() FROM public, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM public, anon, authenticated;
