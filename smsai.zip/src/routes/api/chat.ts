import { createFileRoute } from "@tanstack/react-router";
import { convertToModelMessages, streamText, type UIMessage } from "ai";
import { z } from "zod";
import { AuthError, authErrorToResponse, getAuthenticatedUser } from "@/lib/auth.server";
import { createLovableAiGatewayProvider } from "@/lib/ai-gateway.server";
import type { Database } from "@/integrations/supabase/types";

type Json = Database["public"]["Tables"]["chat_messages"]["Insert"]["parts"];

const BASE_SYSTEM_PROMPT = `You are SMS AI by Deltacoders, a premium next-generation AI assistant with the tagline "Intelligence Without Limits".
You are helpful, articulate, and capable of deep reasoning, coding, writing, research, and analysis.
Format every answer with clean Markdown for maximum scannability:
- Use clear ## and ### Headings to structure the answer.
- Use **bold key facts**, bullet lists, numbered steps, and fenced code blocks with language tags when sharing code.
- Sprinkle relevant emojis (✅ ⚡ 💡 🚀 ⚠️ 🧠 📊) next to headings and key points to make replies friendly and easy to scan.`;

const ACCURACY_GUARDRAIL = `Prioritize strict factual correctness. If certain information is missing or ambiguous, state that directly without inventing data. Respond succinctly to maximize speed.`;

const MOOD_INSTRUCTIONS = {
  professional: "Adopt a professional, formal, business-grade tone. Be precise, structured, and avoid slang.",
  witty: "Use a witty, lightly sarcastic tone with clever wordplay, while staying genuinely helpful.",
  enthusiastic: "Be highly enthusiastic, upbeat and motivating. Use energetic language and the occasional exclamation.",
  creative: "Be imaginative, vivid and story-driven. Use metaphors, analogies, and creative framing where useful.",
  empathetic: "Be empathetic, validating and gentle. Acknowledge feelings before giving practical guidance.",
  funny: "Be playful and humorous with light jokes and puns where appropriate, without sacrificing correctness.",
  warm: "Be warm, friendly and conversational, like a kind mentor speaking with a friend.",
  point: "Answer in an ultra-concise point-to-point style. Prefer bullet points and short sentences. No filler.",
} as const;

const MOOD_KEYS = Object.keys(MOOD_INSTRUCTIONS) as Array<keyof typeof MOOD_INSTRUCTIONS>;

const DEFAULT_MODEL = "google/gemini-3.7-flash";

const ChatMessageSchema = z.object({
  id: z.string().optional(),
  role: z.enum(["user", "assistant", "system"]),
  parts: z.array(z.record(z.unknown()).and(z.object({ type: z.string() }))),
});

const SourceSchema = z.object({
  index: z.number().int(),
  title: z.string(),
  url: z.string(),
  snippet: z.string().default(""),
  content: z.string().default(""),
});

const ChatRequestSchema = z.object({
  messages: z.array(ChatMessageSchema).min(1, "At least one message is required"),
  threadId: z.string().uuid("Invalid thread id"),
  mood: z.enum(MOOD_KEYS as [string, ...string[]]).optional(),
  sources: z.array(SourceSchema).max(8).optional(),
});

type Source = z.infer<typeof SourceSchema>;

function buildResearchBlock(sources: Source[]): string {
  const corpus = sources
    .map(
      (s) =>
        `[${s.index}] ${s.title}\nURL: ${s.url}\nExcerpt: ${(s.content || s.snippet).slice(0, 3000)}`,
    )
    .join("\n\n");

  return [
    "DEEP RESEARCH MODE — live web results are provided below. Ground your answer in them.",
    "Citation rules (mandatory):",
    "- Cite inline with clickable Markdown anchors using the source number, e.g. [[1]](https://example.com).",
    "- Cite every factual claim taken from the results; never cite a source you did not use.",
    "- End with a `## Sources` section listing each used source as `1. [Title](url)`.",
    "- If the results do not answer part of the question, say so explicitly instead of guessing.",
    "",
    "WEB RESULTS:",
    corpus,
  ].join("\n");
}

function buildSystemPrompt(mood?: string, sources?: Source[]): string {
  const moodKey = (mood ?? "professional").toLowerCase();
  const moodInstruction =
    MOOD_INSTRUCTIONS[moodKey as keyof typeof MOOD_INSTRUCTIONS] ?? MOOD_INSTRUCTIONS.professional;
  const parts = [BASE_SYSTEM_PROMPT, `Personality mood: ${moodInstruction}`, ACCURACY_GUARDRAIL];
  if (sources?.length) parts.push(buildResearchBlock(sources));
  return parts.join("\n\n");
}

async function assertNotBlocked(
  supabase: Awaited<ReturnType<typeof getAuthenticatedUser>>["supabase"],
  userId: string,
): Promise<void> {
  const { data, error } = await supabase.from("profiles").select("status").eq("id", userId).maybeSingle();
  if (error) {
    throw new AuthError(500, "Profile lookup failed");
  }
  if (data?.status === "blocked") {
    throw new AuthError(403, "Account blocked");
  }
}

type Thread = {
  id: string;
  title: string;
  user_id: string;
};

async function loadOwnedThread(
  supabase: Awaited<ReturnType<typeof getAuthenticatedUser>>["supabase"],
  userId: string,
  threadId: string,
): Promise<Thread> {
  const { data, error } = await supabase
    .from("chat_threads")
    .select("id, title, user_id")
    .eq("id", threadId)
    .maybeSingle();

  if (error) {
    throw new AuthError(500, "Thread lookup failed");
  }
  if (!data || data.user_id !== userId) {
    throw new AuthError(404, "Thread not found");
  }
  return data;
}

async function persistUserMessage(
  supabase: Awaited<ReturnType<typeof getAuthenticatedUser>>["supabase"],
  userId: string,
  threadId: string,
  thread: Thread,
  lastMessage: UIMessage | undefined,
): Promise<void> {
  if (!lastMessage || lastMessage.role !== "user") return;

  const insert = await supabase.from("chat_messages").insert({
    thread_id: threadId,
    user_id: userId,
    role: "user",
    parts: lastMessage.parts as unknown as Json,
  });
  if (insert.error) {
    throw new AuthError(500, "Failed to save user message");
  }

  if (thread.title === "New chat") {
    const text = lastMessage.parts
      .map((p) => (p.type === "text" ? p.text : ""))
      .join(" ")
      .trim()
      .slice(0, 60);
    if (text) {
      const update = await supabase.from("chat_threads").update({ title: text }).eq("id", threadId);
      if (update.error) {
        throw new AuthError(500, "Failed to update thread title");
      }
    }
  } else {
    const update = await supabase
      .from("chat_threads")
      .update({ updated_at: new Date().toISOString() })
      .eq("id", threadId);
    if (update.error) {
      throw new AuthError(500, "Failed to update thread");
    }
  }
}

export const Route = createFileRoute("/api/chat")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const key = process.env.LOVABLE_API_KEY;
        if (!key) {
          return new Response("Missing LOVABLE_API_KEY", { status: 500 });
        }

        try {
          const { userId, supabase } = await getAuthenticatedUser(request);
          await assertNotBlocked(supabase, userId);

          const body = await request.json();
          const parseResult = ChatRequestSchema.safeParse(body);
          if (!parseResult.success) {
            return new Response(JSON.stringify({ error: parseResult.error.flatten() }), {
              status: 400,
              headers: { "Content-Type": "application/json" },
            });
          }

          const { messages: rawMessages, threadId, mood, sources } = parseResult.data;
          const messages = rawMessages as UIMessage[];
          const thread = await loadOwnedThread(supabase, userId, threadId);
          await persistUserMessage(supabase, userId, threadId, thread, messages[messages.length - 1]);

          const gateway = createLovableAiGatewayProvider(key);
          const model = gateway(DEFAULT_MODEL);

          const result = streamText({
            model,
            system: buildSystemPrompt(mood, sources),
            messages: await convertToModelMessages(messages),
            abortSignal: request.signal,
          });

          return result.toUIMessageStreamResponse({
            originalMessages: messages,
            onFinish: async ({ messages: finalMessages, isAborted }) => {
              // Aborted runs are persisted client-side (partial answer), so skip here.
              if (isAborted || request.signal.aborted) return;
              const assistantMessage = finalMessages[finalMessages.length - 1];
              if (assistantMessage && assistantMessage.role === "assistant") {
                const [inserted, updated] = await Promise.all([
                  supabase.from("chat_messages").insert({
                    thread_id: threadId,
                    user_id: userId,
                    role: "assistant",
                    parts: assistantMessage.parts as unknown as Json,
                  }),
                  supabase.from("chat_threads").update({ updated_at: new Date().toISOString() }).eq("id", threadId),
                ]);
                if (inserted.error || updated.error) {
                  console.error("Failed to persist assistant message", {
                    insertError: inserted.error,
                    updateError: updated.error,
                  });
                }
              }
            },
          });
        } catch (error) {
          if (error instanceof AuthError) {
            return authErrorToResponse(error);
          }
          if (error instanceof Error && error.name === "AbortError") {
            return new Response(null, { status: 499 });
          }
          console.error("Chat API error", error);
          return new Response("AI service unavailable", { status: 502 });
        }
      },
    },
  },
});
