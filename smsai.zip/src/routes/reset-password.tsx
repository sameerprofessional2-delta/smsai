import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { AnimatedBackground } from "@/components/AnimatedBackground";
import { Logo } from "@/components/Logo";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Loader2 } from "lucide-react";

export const Route = createFileRoute("/reset-password")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "Set a new password — SMS AI" },
      { name: "description", content: "Choose a new password for your SMS AI account." },
      { property: "og:title", content: "Set a new password — SMS AI" },
      { property: "og:description", content: "Choose a new password for your SMS AI account." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: ResetPasswordPage,
});

function ResetPasswordPage() {
  const navigate = useNavigate();
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [loading, setLoading] = useState(false);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => setReady(!!data.session));
    const { data: sub } = supabase.auth.onAuthStateChange((_e, session) => setReady(!!session));
    return () => sub.subscription.unsubscribe();
  }, []);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (password !== confirm) return toast.error("Passwords don't match");
    setLoading(true);
    const { error } = await supabase.auth.updateUser({ password });
    setLoading(false);
    if (error) return toast.error(error.message);
    toast.success("Password updated");
    navigate({ to: "/chat" });
  };

  return (
    <div className="relative min-h-screen flex items-center justify-center px-4">
      <AnimatedBackground />
      <div className="w-full max-w-md">
        <Link to="/" className="flex justify-center mb-8"><Logo size={40} /></Link>
        <div className="glass-strong rounded-2xl p-8">
          <h1 className="text-2xl font-bold text-center">Set a new password</h1>
          <p className="text-sm text-muted-foreground text-center mt-1">
            {ready ? "Choose a strong password you haven't used elsewhere." : "Open this page from the reset link in your email."}
          </p>
          <form onSubmit={submit} className="space-y-3 mt-6">
            <div className="space-y-1.5"><Label>New password</Label><Input type="password" minLength={8} value={password} onChange={(e) => setPassword(e.target.value)} required /></div>
            <div className="space-y-1.5"><Label>Confirm password</Label><Input type="password" minLength={8} value={confirm} onChange={(e) => setConfirm(e.target.value)} required /></div>
            <Button disabled={loading || !ready} type="submit" className="w-full bg-gradient-to-r from-primary to-primary-glow text-primary-foreground">
              {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : "Update password"}
            </Button>
          </form>
          <Link to="/auth" className="block text-center text-xs text-muted-foreground hover:text-foreground mt-4">Back to sign in</Link>
        </div>
      </div>
    </div>
  );
}
