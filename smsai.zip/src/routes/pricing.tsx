import { createFileRoute, Link } from "@tanstack/react-router";
import { Check } from "lucide-react";
import { SiteHeader } from "@/components/SiteHeader";
import { AnimatedBackground } from "@/components/AnimatedBackground";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/pricing")({
  head: () => ({
    meta: [
      { title: "Pricing — SMS AI" },
      { name: "description", content: "Simple, transparent pricing. Free to start, Pro for power users, Enterprise for teams." },
      { property: "og:title", content: "Pricing — SMS AI" },
      { property: "og:description", content: "Free, Pro, and Enterprise plans for SMS AI." },
    ],
  }),
  component: PricingPage,
});

const plans = [
  {
    name: "Free",
    price: "$0",
    period: "/forever",
    desc: "Perfect for getting started.",
    features: ["100 messages/day", "Standard model", "Chat history", "Markdown & code rendering"],
    cta: "Start free",
    highlighted: false,
  },
  {
    name: "Pro",
    price: "$20",
    period: "/month",
    desc: "For power users and creators.",
    features: ["Unlimited messages", "Advanced models", "Image generation", "Document analysis", "Priority speed", "Voice mode"],
    cta: "Go Pro",
    highlighted: true,
  },
  {
    name: "Enterprise",
    price: "Custom",
    period: "",
    desc: "For teams and organizations.",
    features: ["Everything in Pro", "SSO & SAML", "Team workspaces", "Audit logs", "Dedicated support", "Custom SLAs"],
    cta: "Contact sales",
    highlighted: false,
  },
];

function PricingPage() {
  return (
    <div className="relative min-h-screen">
      <AnimatedBackground />
      <SiteHeader />
      <section className="container mx-auto px-6 pt-20 pb-32">
        <div className="text-center max-w-2xl mx-auto">
          <h1 className="text-5xl md:text-6xl font-bold">Simple <span className="text-gradient">pricing</span></h1>
          <p className="mt-4 text-muted-foreground">Choose the plan that fits how you think.</p>
        </div>
        <div className="mt-16 grid md:grid-cols-3 gap-6 max-w-5xl mx-auto">
          {plans.map((p) => (
            <div
              key={p.name}
              className={`relative rounded-2xl p-8 ${p.highlighted ? "glass-strong border-primary/50 shadow-glow" : "glass"}`}
            >
              {p.highlighted && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-gradient-to-r from-primary to-primary-glow px-4 py-1 text-xs font-medium text-primary-foreground">
                  Most popular
                </div>
              )}
              <h3 className="text-lg font-semibold">{p.name}</h3>
              <div className="mt-4 flex items-baseline gap-1">
                <span className="text-5xl font-bold">{p.price}</span>
                <span className="text-muted-foreground">{p.period}</span>
              </div>
              <p className="mt-2 text-sm text-muted-foreground">{p.desc}</p>
              <ul className="mt-6 space-y-3">
                {p.features.map((f) => (
                  <li key={f} className="flex items-start gap-2 text-sm">
                    <Check className="h-4 w-4 text-primary mt-0.5 shrink-0" /> {f}
                  </li>
                ))}
              </ul>
              <Link to="/auth" className="mt-8 block">
                <Button
                  className={`w-full ${p.highlighted ? "bg-gradient-to-r from-primary to-primary-glow text-primary-foreground" : ""}`}
                  variant={p.highlighted ? "default" : "outline"}
                >
                  {p.cta}
                </Button>
              </Link>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
