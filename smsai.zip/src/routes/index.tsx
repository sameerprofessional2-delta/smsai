import { createFileRoute, Link } from "@tanstack/react-router";
import { Sparkles, MessageSquare, Code2, FileText, Image as ImageIcon, Search, Mic, ArrowRight, Zap, Shield, Globe } from "lucide-react";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";
import { PricingTiers } from "@/components/PricingTiers";

import { AnimatedBackground } from "@/components/AnimatedBackground";
import { Button } from "@/components/ui/button";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { useFaqs, useFlags } from "@/lib/admin-store";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "SMS AI by Deltacoders" },
      { name: "description", content: "A next-generation AI platform with chat, code, document analysis, image generation, research, and voice — all in one premium experience." },
      { property: "og:title", content: "SMS AI by Deltacoders — Intelligence Without Limits" },
      { property: "og:description", content: "Premium AI platform for chat, code, research, and creative work." },
    ],
  }),
  component: HomePage,
});

const features = [
  { icon: MessageSquare, title: "AI Chat", desc: "Real-time streaming conversations with long-term memory and markdown rendering." },
  { icon: Code2, title: "Code Generator", desc: "Generate, refactor, and explain code in any language with rich syntax highlighting." },
  { icon: FileText, title: "Document Analysis", desc: "Upload PDFs, DOCX, and TXT files to extract insights instantly." },
  { icon: ImageIcon, title: "Image Generation", desc: "Create stunning visuals from natural language prompts." },
  { icon: Search, title: "Research Assistant", desc: "Web-aware research with cited sources and concise summaries." },
  { icon: Mic, title: "Voice Assistant", desc: "Hands-free interaction with speech-to-text and natural voice replies." },
];

const stats = [
  { value: "10M+", label: "Messages generated" },
  { value: "120+", label: "Languages" },
  { value: "99.99%", label: "Uptime" },
  { value: "<100ms", label: "First token" },
];

function HomePage() {
  const [faqs] = useFaqs();
  const [flags] = useFlags();
  return (
    <div className="relative min-h-screen">
      <AnimatedBackground />
      <SiteHeader />
      {flags.maintenanceMode && (
        <div className="bg-destructive/20 border-b border-destructive/40 text-center py-2 text-sm">
          ⚠️ SMS AI is in maintenance mode — some features may be unavailable.
        </div>
      )}

      {/* Hero */}
      <section className="container mx-auto px-6 pt-20 pb-32 text-center">
        <div className="inline-flex items-center gap-2 rounded-full glass px-4 py-1.5 text-xs text-muted-foreground animate-fade-in-up">
          <Sparkles className="h-3.5 w-3.5 text-primary" />
          <span>Powered by next-generation AI models</span>
        </div>
        <h1 className="mt-6 text-5xl md:text-7xl font-bold tracking-tight animate-fade-in-up" style={{ animationDelay: "0.1s" }}>
          SMS AI
          <br />
          <span className="text-gradient animate-gradient bg-gradient-to-r from-primary via-primary-glow to-primary">Intelligence Without Limits</span>
        </h1>
        <p className="mx-auto mt-6 max-w-2xl text-lg text-muted-foreground animate-fade-in-up" style={{ animationDelay: "0.2s" }}>
          SMS AI is the all-in-one platform that turns ideas into reality. Chat, code, create, analyze, and discover — at the speed of thought.
        </p>
        <div className="mt-10 flex flex-wrap items-center justify-center gap-4 animate-fade-in-up" style={{ animationDelay: "0.3s" }}>
          <Link to="/chat">
            <Button size="lg" className="h-12 px-8 bg-gradient-to-r from-primary to-primary-glow text-primary-foreground shadow-glow hover:opacity-90">
              Start chatting free
              <ArrowRight className="ml-1 h-4 w-4" />
            </Button>
          </Link>
          <Link to="/pricing">
            <Button size="lg" variant="outline" className="h-12 px-8 glass border-border/50">
              View pricing
            </Button>
          </Link>
        </div>

        {/* Stats */}
        <div className="mt-24 grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto">
          {stats.map((s) => (
            <div key={s.label} className="glass rounded-xl p-6">
              <div className="text-3xl font-bold text-gradient">{s.value}</div>
              <div className="mt-1 text-xs text-muted-foreground">{s.label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* Features */}
      <section id="features" className="container mx-auto px-6 pb-32">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <h2 className="text-4xl md:text-5xl font-bold">One platform. <span className="text-gradient">Every capability.</span></h2>
          <p className="mt-4 text-muted-foreground">Everything you need to think, build, and create faster.</p>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {features.map((f) => (
            <div key={f.title} className="group glass rounded-2xl p-6 hover:border-primary/50 transition-all hover:-translate-y-1 hover:shadow-glow">
              <div className="inline-flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-primary/20 to-primary-glow/10 border border-primary/20">
                <f.icon className="h-6 w-6 text-primary" />
              </div>
              <h3 className="mt-5 text-lg font-semibold">{f.title}</h3>
              <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Why */}
      <section className="container mx-auto px-6 pb-32">
        <div className="glass-strong rounded-3xl p-12 md:p-16 text-center">
          <h2 className="text-3xl md:text-4xl font-bold max-w-3xl mx-auto">Built for performance, security, and scale</h2>
          <div className="mt-10 grid md:grid-cols-3 gap-8 text-left">
            {[
              { icon: Zap, title: "Blazing fast", desc: "Streaming responses with sub-second time-to-first-token." },
              { icon: Shield, title: "Enterprise security", desc: "End-to-end encryption, row-level access, SOC-2-ready." },
              { icon: Globe, title: "Global by default", desc: "Multi-language support and worldwide edge delivery." },
            ].map((b) => (
              <div key={b.title}>
                <b.icon className="h-7 w-7 text-primary" />
                <h3 className="mt-3 font-semibold">{b.title}</h3>
                <p className="mt-1 text-sm text-muted-foreground">{b.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <PricingTiers />

      {/* FAQ */}

      {faqs.length > 0 && (
        <section id="faq" className="container mx-auto px-6 pb-32 max-w-3xl">
          <div className="text-center mb-10">
            <h2 className="text-4xl md:text-5xl font-bold">Frequently asked <span className="text-gradient">questions</span></h2>
          </div>
          <div className="glass rounded-2xl p-6">
            <Accordion type="single" collapsible className="w-full">
              {faqs.map((f) => (
                <AccordionItem key={f.id} value={f.id}>
                  <AccordionTrigger className="text-left">{f.question}</AccordionTrigger>
                  <AccordionContent className="text-muted-foreground">{f.answer}</AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </div>
        </section>
      )}

      {/* CTA */}
      <section className="container mx-auto px-6 pb-32 text-center">
        <h2 className="text-4xl md:text-5xl font-bold">Ready to think bigger?</h2>
        <p className="mt-4 text-muted-foreground">Free to start. No credit card required.</p>
        <Link to="/auth" className="mt-8 inline-block">
          <Button size="lg" className="h-12 px-10 bg-gradient-to-r from-primary to-primary-glow text-primary-foreground shadow-glow hover:opacity-90">
            Get started
          </Button>
        </Link>
      </section>

      <SiteFooter />

    </div>
  );
}
