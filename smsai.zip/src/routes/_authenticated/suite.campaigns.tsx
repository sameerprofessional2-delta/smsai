import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import { CAMPAIGNS, generateCopy, usePersona } from "@/lib/sms-suite";
import { cn } from "@/lib/utils";
import { CalendarDays, Check, Copy, Sparkles, Users, Wand2 } from "lucide-react";

export const Route = createFileRoute("/_authenticated/suite/campaigns")({
  component: CampaignsPage,
});

const STEPS = ["Audience", "Message", "Schedule", "Review"] as const;

const AUDIENCES = [
  { id: "vip", label: "VIP + Repeat buyers", size: 8420 },
  { id: "cart", label: "Abandoned carts (48h)", size: 2160 },
  { id: "all", label: "All subscribers", size: 19340 },
  { id: "lapsed", label: "Lapsed 90+ days", size: 5120 },
];

const DRIP = [
  { day: "Day 0", label: "Welcome + offer", detail: "Sent immediately after opt-in" },
  { day: "Day 2", label: "Social proof", detail: "Top reviews + bestseller link" },
  { day: "Day 5", label: "Urgency nudge", detail: "Offer expires in 24h" },
  { day: "Day 9", label: "Winback", detail: "Only if no click recorded" },
];

function CampaignsPage() {
  const { persona } = usePersona();
  const [step, setStep] = useState(0);
  const [audience, setAudience] = useState(AUDIENCES[0]!.id);
  const [goal, setGoal] = useState("Flash sale for running shoes");
  const [variants, setVariants] = useState<string[]>([]);
  const [generating, setGenerating] = useState(false);
  const [chosen, setChosen] = useState<string>("");
  const [date, setDate] = useState("2026-08-11");
  const [time, setTime] = useState("10:00");

  const selected = AUDIENCES.find((a) => a.id === audience)!;

  async function generate() {
    setGenerating(true);
    setVariants([]);
    await new Promise((r) => setTimeout(r, 1100));
    setVariants(generateCopy(goal, persona.tone, persona.agentName));
    setGenerating(false);
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Campaign Builder &amp; Smart Scheduler</h1>
        <p className="text-sm text-muted-foreground">Bulk SMS with AI copywriting and drip automation.</p>
      </div>

      <div className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_320px]">
        <section className="glass rounded-2xl p-5">
          <ol className="flex items-center gap-2 mb-6 overflow-x-auto">
            {STEPS.map((s, i) => (
              <li key={s} className="flex items-center gap-2">
                <button
                  onClick={() => setStep(i)}
                  className={cn(
                    "flex items-center gap-2 rounded-full px-3 py-1.5 text-xs transition-all",
                    i === step ? "bg-primary text-primary-foreground shadow-glow" : i < step ? "bg-primary/15 text-primary" : "bg-muted/40 text-muted-foreground",
                  )}
                >
                  <span className="h-4 w-4 rounded-full bg-background/30 text-[10px] flex items-center justify-center">
                    {i < step ? <Check className="h-2.5 w-2.5" /> : i + 1}
                  </span>
                  {s}
                </button>
                {i < STEPS.length - 1 && <span className="h-px w-6 bg-border" />}
              </li>
            ))}
          </ol>

          {step === 0 && (
            <div className="space-y-2 animate-fade-in">
              {AUDIENCES.map((a) => (
                <button
                  key={a.id}
                  onClick={() => setAudience(a.id)}
                  className={cn(
                    "w-full flex items-center gap-3 rounded-xl border p-3.5 text-left transition-all hover:-translate-y-0.5",
                    audience === a.id ? "border-primary/60 bg-primary/10 shadow-glow" : "border-border/50 bg-muted/20 hover:bg-muted/40",
                  )}
                >
                  <Users className="h-4 w-4 text-primary" />
                  <span className="text-sm">{a.label}</span>
                  <span className="ml-auto text-xs text-muted-foreground">{a.size.toLocaleString()} contacts</span>
                </button>
              ))}
            </div>
          )}

          {step === 1 && (
            <div className="space-y-4 animate-fade-in">
              <div>
                <label className="text-xs text-muted-foreground">Campaign goal</label>
                <div className="mt-1.5 flex gap-2">
                  <Input value={goal} onChange={(e) => setGoal(e.target.value)} className="bg-muted/30 border-border/50" placeholder="e.g. Flash sale for shoes" />
                  <Button onClick={generate} disabled={generating} className="bg-gradient-to-r from-primary to-primary-glow text-primary-foreground shrink-0">
                    <Wand2 className="h-4 w-4 mr-2" /> {generating ? "Writing…" : "AI Copywriter"}
                  </Button>
                </div>
                <p className="mt-1 text-[10.5px] text-muted-foreground">
                  Uses your active persona tone: <span className="text-primary">{persona.tone}</span>
                </p>
              </div>

              {generating && (
                <div className="space-y-2">
                  {Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-20 rounded-xl" />)}
                </div>
              )}

              <div className="space-y-2">
                {variants.map((v, i) => (
                  <div
                    key={i}
                    onClick={() => setChosen(v)}
                    className={cn(
                      "rounded-xl border p-3.5 cursor-pointer transition-all hover:-translate-y-0.5",
                      chosen === v ? "border-primary/60 bg-primary/10" : "border-border/50 bg-muted/20 hover:bg-muted/40",
                    )}
                  >
                    <div className="flex items-center gap-2 text-[10px] uppercase tracking-wider text-muted-foreground">
                      <Sparkles className="h-3 w-3 text-primary" /> Variation {i + 1}
                      <span className={cn("ml-auto", v.length > 160 ? "text-destructive" : "text-emerald-400")}>{v.length}/160</span>
                      <button
                        onClick={(e) => { e.stopPropagation(); void navigator.clipboard.writeText(v); toast.success("Copied"); }}
                        className="hover:text-foreground"
                      >
                        <Copy className="h-3 w-3" />
                      </button>
                    </div>
                    <p className="mt-1.5 text-sm">{v}</p>
                  </div>
                ))}
              </div>

              <div>
                <label className="text-xs text-muted-foreground">Final message</label>
                <Textarea
                  value={chosen}
                  onChange={(e) => setChosen(e.target.value)}
                  rows={3}
                  placeholder="Pick a variation above or write your own…"
                  className="mt-1.5 bg-muted/30 border-border/50 text-sm resize-none"
                />
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-4 animate-fade-in">
              <div className="grid gap-3 sm:grid-cols-2">
                <div>
                  <label className="text-xs text-muted-foreground">Send date</label>
                  <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="mt-1.5 bg-muted/30 border-border/50" />
                </div>
                <div>
                  <label className="text-xs text-muted-foreground">Send time (local)</label>
                  <Input type="time" value={time} onChange={(e) => setTime(e.target.value)} className="mt-1.5 bg-muted/30 border-border/50" />
                </div>
              </div>
              <div>
                <div className="text-xs text-muted-foreground mb-2">Drip timeline</div>
                <ol className="relative border-l border-border/60 ml-2 space-y-3">
                  {DRIP.map((d) => (
                    <li key={d.day} className="ml-4">
                      <span className="absolute -left-[5px] mt-1.5 h-2.5 w-2.5 rounded-full bg-primary shadow-glow" />
                      <div className="rounded-xl border border-border/50 bg-muted/20 p-3">
                        <div className="text-[10px] uppercase tracking-wider text-primary">{d.day}</div>
                        <div className="text-sm">{d.label}</div>
                        <div className="text-[11px] text-muted-foreground">{d.detail}</div>
                      </div>
                    </li>
                  ))}
                </ol>
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-3 animate-fade-in">
              <div className="rounded-xl border border-border/50 bg-muted/20 p-4 space-y-1.5 text-sm">
                <div className="flex justify-between"><span className="text-muted-foreground">Audience</span><span>{selected.label}</span></div>
                <div className="flex justify-between"><span className="text-muted-foreground">Recipients</span><span>{selected.size.toLocaleString()}</span></div>
                <div className="flex justify-between"><span className="text-muted-foreground">Scheduled</span><span>{date} at {time}</span></div>
                <div className="flex justify-between"><span className="text-muted-foreground">Est. cost</span><span>${(selected.size * 0.0075).toFixed(2)}</span></div>
                <div className="pt-2 text-muted-foreground text-xs">Message</div>
                <p className="rounded-lg bg-background/40 p-3 text-sm">{chosen || "— no message selected —"}</p>
              </div>
              <Button
                onClick={() => toast.success(`Campaign scheduled for ${selected.size.toLocaleString()} contacts`)}
                className="w-full bg-gradient-to-r from-primary to-primary-glow text-primary-foreground shadow-glow"
              >
                Schedule campaign
              </Button>
            </div>
          )}

          <div className="mt-6 flex justify-between">
            <Button variant="outline" disabled={step === 0} onClick={() => setStep((s) => s - 1)}>Back</Button>
            <Button variant="outline" disabled={step === STEPS.length - 1} onClick={() => setStep((s) => s + 1)}>Next</Button>
          </div>
        </section>

        <aside className="glass rounded-2xl p-5">
          <h3 className="font-semibold flex items-center gap-2"><CalendarDays className="h-4 w-4 text-primary" /> Scheduled &amp; recent</h3>
          <div className="mt-3 space-y-2">
            {CAMPAIGNS.map((c) => (
              <div key={c.id} className="rounded-xl border border-border/50 bg-muted/20 p-3 transition-colors hover:bg-muted/40">
                <div className="flex items-center gap-2">
                  <span className="text-sm truncate flex-1">{c.name}</span>
                  <Badge
                    variant="outline"
                    className={cn(
                      "text-[9px] py-0 px-1.5",
                      c.status === "Sending" && "bg-primary/15 text-primary border-primary/40",
                      c.status === "Scheduled" && "bg-sky-500/15 text-sky-400 border-sky-500/40",
                      c.status === "Completed" && "bg-emerald-500/15 text-emerald-400 border-emerald-500/40",
                    )}
                  >
                    {c.status}
                  </Badge>
                </div>
                <div className="mt-1 text-[11px] text-muted-foreground">{c.audience} · {c.size.toLocaleString()}</div>
                <div className="mt-1 text-[11px] text-muted-foreground">{c.sendAt} · CTR {c.ctr}%</div>
              </div>
            ))}
          </div>
        </aside>
      </div>
    </div>
  );
}
