import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { TONES, usePersona, type ToneId } from "@/lib/sms-suite";
import {
  AGENTS,
  STYLES,
  VARIABLES,
  checkCompliance,
  complianceScore,
  previewMessage,
  renderTemplate,
  type AgentId,
  type StyleId,
} from "@/lib/sms-suite-pro";
import { cn } from "@/lib/utils";
import { AlertTriangle, CheckCircle2, ShieldCheck, Variable, XCircle } from "lucide-react";

export const Route = createFileRoute("/_authenticated/suite/agents")({
  head: () => ({
    meta: [
      { title: "Multi-Agent Studio — SMS AI by Deltacoders" },
      { name: "description", content: "Configure Support, Sales, Retention and Onboarding AI agents with a tone & style matrix, dynamic variables and compliance checks." },
      { property: "og:title", content: "Multi-Agent Studio — SMS AI" },
      { property: "og:description", content: "Tone matrix, live preview, variable engine and TCPA compliance scoring." },
    ],
  }),
  component: AgentsPage,
});

function AgentsPage() {
  const { persona, setPersona } = usePersona();
  const [agentId, setAgentId] = useState<AgentId>("support");
  const [tone, setTone] = useState<ToneId>(persona.tone);
  const [style, setStyle] = useState<StyleId>("concise");
  const [draft, setDraft] = useState(
    "Hi {first_name}! {dynamic_coupon} gets you 15% off at Northline: nl.co/shop Reply STOP to opt out.",
  );

  const agent = AGENTS.find((a) => a.id === agentId)!;
  const preview = previewMessage(agent, tone, style);
  const rendered = useMemo(() => renderTemplate(draft), [draft]);
  const issues = useMemo(() => checkCompliance(draft), [draft]);
  const score = complianceScore(issues);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Multi-Agent Studio</h1>
        <p className="text-sm text-muted-foreground">
          Distinct AI personas, a tone &amp; style matrix with live preview, dynamic variables and compliance guardrails.
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        {AGENTS.map((a) => (
          <button
            key={a.id}
            onClick={() => {
              setAgentId(a.id);
              setTone(a.defaultTone);
            }}
            className={cn(
              "glass rounded-2xl p-5 text-left transition-all duration-300 hover:-translate-y-0.5",
              agentId === a.id ? "border-primary/60 shadow-glow" : "hover:border-primary/40",
            )}
          >
            <div className="text-2xl">{a.emoji}</div>
            <div className="mt-2 font-semibold">{a.name}</div>
            <div className="text-xs text-primary">{a.role}</div>
            <p className="mt-2 text-xs text-muted-foreground">{a.objective}</p>
            <Badge variant="outline" className="mt-3 text-[10px]">{a.handoff}</Badge>
          </button>
        ))}
      </div>

      <div className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_minmax(0,420px)]">
        <section className="glass rounded-2xl p-5 space-y-5">
          <div>
            <div className="text-xs uppercase tracking-wider text-muted-foreground mb-2">Tone matrix</div>
            <div className="grid gap-2 sm:grid-cols-2">
              {TONES.map((t) => (
                <button
                  key={t.id}
                  onClick={() => setTone(t.id)}
                  className={cn(
                    "rounded-xl border p-3 text-left text-sm transition-all hover:-translate-y-0.5",
                    tone === t.id ? "border-primary/60 bg-primary/10" : "border-border/50 bg-muted/20 hover:bg-muted/40",
                  )}
                >
                  <span className="mr-1.5">{t.emoji}</span>
                  {t.label}
                  <div className="text-[11px] text-muted-foreground">{t.blurb}</div>
                </button>
              ))}
            </div>
          </div>

          <div>
            <div className="text-xs uppercase tracking-wider text-muted-foreground mb-2">Style matrix</div>
            <div className="flex flex-wrap gap-2">
              {STYLES.map((s) => (
                <button
                  key={s.id}
                  onClick={() => setStyle(s.id)}
                  className={cn(
                    "rounded-full border px-3 py-1.5 text-xs transition-all",
                    style === s.id ? "border-primary/60 bg-primary/15 text-primary" : "border-border/50 text-muted-foreground hover:text-foreground",
                  )}
                  title={s.blurb}
                >
                  {s.label}
                </button>
              ))}
            </div>
          </div>

          <div className="rounded-2xl border border-primary/30 bg-gradient-to-br from-primary/10 to-transparent p-4">
            <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Real-time preview</div>
            <p className="mt-2 text-sm">{renderTemplate(preview).text}</p>
            <div className="mt-2 text-[11px] text-muted-foreground">
              {agent.name} · {tone} · {style}
            </div>
          </div>

          <Button
            onClick={() => setPersona({ tone, agentName: `${agent.name} — ${agent.role}` })}
            className="bg-gradient-to-r from-primary to-primary-glow text-primary-foreground shadow-glow"
          >
            Activate {agent.name} across channels
          </Button>
        </section>

        <aside className="glass rounded-2xl p-5 space-y-4">
          <Tabs defaultValue="variables">
            <TabsList className="w-full">
              <TabsTrigger value="variables" className="flex-1 text-xs">
                <Variable className="h-3.5 w-3.5 mr-1.5" /> Variables
              </TabsTrigger>
              <TabsTrigger value="compliance" className="flex-1 text-xs">
                <ShieldCheck className="h-3.5 w-3.5 mr-1.5" /> Compliance
              </TabsTrigger>
            </TabsList>

            <TabsContent value="variables" className="space-y-3 pt-3">
              <Textarea
                value={draft}
                onChange={(e) => setDraft(e.target.value)}
                rows={4}
                className="bg-muted/30 border-border/50 text-sm resize-none"
              />
              <div className="flex flex-wrap gap-1.5">
                {VARIABLES.map((v) => (
                  <button
                    key={v.token}
                    onClick={() => setDraft((d) => `${d}${d.endsWith(" ") || d === "" ? "" : " "}${v.token}`)}
                    className="rounded-full border border-border/50 bg-muted/30 px-2.5 py-1 text-[11px] text-muted-foreground hover:text-primary hover:border-primary/50 transition-colors"
                  >
                    {v.token}
                  </button>
                ))}
              </div>
              <div className="rounded-xl border border-border/50 bg-muted/20 p-3">
                <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Parsed output</div>
                <p className="mt-1.5 text-sm">{rendered.text}</p>
                {rendered.missing.length > 0 && (
                  <p className="mt-2 text-[11px] text-amber-400">Unknown tokens: {rendered.missing.join(", ")}</p>
                )}
              </div>
            </TabsContent>

            <TabsContent value="compliance" className="space-y-3 pt-3">
              <div>
                <div className="flex items-center justify-between text-xs mb-1.5">
                  <span className="text-muted-foreground">Compliance score</span>
                  <span className={cn("font-semibold", score >= 80 ? "text-emerald-400" : score >= 50 ? "text-amber-400" : "text-destructive")}>
                    {score}%
                  </span>
                </div>
                <Progress value={score} />
              </div>
              <ul className="space-y-2">
                {issues.map((i) => (
                  <li key={i.id} className="flex items-start gap-2 rounded-xl border border-border/50 bg-muted/20 p-2.5 text-xs">
                    {i.level === "pass" ? (
                      <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-400" />
                    ) : i.level === "warning" ? (
                      <AlertTriangle className="h-4 w-4 shrink-0 text-amber-400" />
                    ) : (
                      <XCircle className="h-4 w-4 shrink-0 text-destructive" />
                    )}
                    <span className={cn(i.level === "error" && "text-destructive")}>{i.message}</span>
                  </li>
                ))}
              </ul>
            </TabsContent>
          </Tabs>
        </aside>
      </div>
    </div>
  );
}
