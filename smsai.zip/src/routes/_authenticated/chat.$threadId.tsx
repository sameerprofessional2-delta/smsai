import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useChat } from "@ai-sdk/react";
import { DefaultChatTransport, type UIMessage } from "ai";
import { supabase } from "@/integrations/supabase/client";
import { ChatMessage } from "@/components/ChatMessage";
import { Logo } from "@/components/Logo";
import { ChatInput, type ChatInputHandle } from "@/components/ChatInput";
import { MathKeyboard } from "@/components/MathKeyboard";
import { DeepResearchProgress, type ResearchPhase } from "@/components/DeepResearchProgress";
import { deepResearch, type ResearchSource } from "@/lib/websearch.functions";
import { withStreamingResilience } from "@/lib/resilient-fetch";
import { useServerFn } from "@tanstack/react-start";
import { ImageGenerator } from "@/components/ImageGenerator";
import { PaymentModal } from "@/components/PaymentModal";
import { MoodSelector } from "@/components/MoodSelector";
import { AttachMenu, attachmentsToPrompt, type Attachment } from "@/components/AttachMenu";
import { getStoredMood } from "@/lib/mood";
import { useProfile } from "@/lib/profile";
import { Sparkles, Globe, ImageIcon, Lock, Square } from "lucide-react";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/chat/$threadId")({
  component: ChatThread,
});

const suggestions = [
  "Explain quantum entanglement like I'm 12",
  "Write a TypeScript debounce hook",
  "Draft a launch announcement email",
  "Compare PostgreSQL vs MongoDB for analytics",
];

function ChatThread() {
  const { threadId } = Route.useParams();
  const { user } = Route.useRouteContext();
  const { isPremium } = useProfile();
  const [webSearch, setWebSearch] = useState(false);
  const [research, setResearch] = useState<{
    query: string;
    phase: ResearchPhase;
    sourceCount: number;
  } | null>(null);
  const sourcesRef = useRef<ResearchSource[] | null>(null);
  const runResearch = useServerFn(deepResearch);
  const [showImageGen, setShowImageGen] = useState(false);
  const [showPayment, setShowPayment] = useState(false);
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  const interruptedRef = useRef(false);
  const messagesRef = useRef<UIMessage[]>([]);
  const scrollerRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<ChatInputHandle>(null);
  const stickToBottom = useRef(true);

  const { data: initialMessages, isLoading } = useQuery({
    queryKey: ["messages", threadId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("chat_messages")
        .select("id, role, parts, created_at")
        .eq("thread_id", threadId)
        .order("created_at", { ascending: true });
      if (error) throw error;
      return (data ?? []).map((m) => ({
        id: m.id,
        role: m.role as "user" | "assistant",
        parts: m.parts as UIMessage["parts"],
      })) as UIMessage[];
    },
  });

  const transport = useMemo(() => {
    // Retry with exponential backoff + aggregate SSE chunks so a brief network
    // drop resumes instead of freezing the answer mid-sentence.
    const resilient = withStreamingResilience((url, init) => fetch(url, init), {
      onNotice: (notice) => {
        if (notice.type === "retry") toast.info("Connection hiccup — reconnecting…");
        if (notice.type === "recovered") toast.success("Connection restored");
        if (notice.type === "interrupted") {
          interruptedRef.current = true;
          toast.warning("Stream interrupted — saved the partial answer.");
        }
      },
    });

    return new DefaultChatTransport({
      api: "/api/chat",
      fetch: async (url, init) => {
        const { data } = await supabase.auth.getSession();
        const headers = new Headers(init?.headers);
        if (data.session?.access_token) {
          headers.set("Authorization", `Bearer ${data.session.access_token}`);
        }
        let body = init?.body;
        if (typeof body === "string") {
          try {
            const parsed = JSON.parse(body);
            parsed.threadId = threadId;
            parsed.mood = getStoredMood();
            if (sourcesRef.current?.length) parsed.sources = sourcesRef.current;
            sourcesRef.current = null;
            body = JSON.stringify(parsed);
          } catch {
            /* leave body untouched */
          }
        }
        return resilient(url, { ...init, headers, body });
      },
    });
  }, [threadId]);

  const { messages, sendMessage, status, setMessages, stop } = useChat({
    id: threadId,
    transport,
    onError: (e) => {
      console.error("Chat stream error", e);
      toast.error("Failed to send message. Please try again.");
    },
  });

  useEffect(() => {
    if (initialMessages) setMessages(initialMessages);
  }, [initialMessages, setMessages]);

  messagesRef.current = messages;

  // Track whether the user is reading history; only auto-follow when at bottom.
  const onScroll = useCallback(() => {
    const el = scrollerRef.current;
    if (!el) return;
    stickToBottom.current = el.scrollHeight - el.scrollTop - el.clientHeight < 120;
  }, []);

  const isBusy = status === "submitted" || status === "streaming";

  useEffect(() => {
    const el = scrollerRef.current;
    if (!el || !stickToBottom.current) return;
    let frame = 0;
    const follow = () => {
      if (!stickToBottom.current || !scrollerRef.current) return;
      scrollerRef.current.scrollTop = scrollerRef.current.scrollHeight;
      if (isBusy) frame = requestAnimationFrame(follow);
    };
    frame = requestAnimationFrame(follow);
    return () => cancelAnimationFrame(frame);
  }, [messages, isBusy]);

  useEffect(() => {
    inputRef.current?.focus();
  }, [threadId]);

  // Persist a partial assistant answer when a stream is stopped or interrupted
  // (the server skips persistence for aborted runs to avoid duplicates).
  const persistPartial = useCallback(async () => {
    const last = messagesRef.current[messagesRef.current.length - 1];
    if (!last || last.role !== "assistant") return;
    const text = last.parts
      .map((p) => (p.type === "text" ? p.text : ""))
      .join("")
      .trim();
    if (!text) return;
    const { error } = await supabase.from("chat_messages").insert({
      thread_id: threadId,
      user_id: user.id,
      role: "assistant",
      parts: last.parts as never,
    });
    if (error) console.error("Failed to persist partial answer", error);
  }, [threadId, user.id]);

  const handleStop = useCallback(async () => {
    await stop();
    await persistPartial();
  }, [persistPartial, stop]);

  useEffect(() => {
    if (interruptedRef.current && !isBusy) {
      interruptedRef.current = false;
      void persistPartial();
    }
  }, [isBusy, persistPartial]);

  const dispatch = useCallback(
    async (value: string, sources?: ResearchSource[]) => {
      const attachPrefix = attachmentsToPrompt(attachments);
      setAttachments([]);
      stickToBottom.current = true;
      sourcesRef.current = sources?.length ? sources : null;
      try {
        await sendMessage({ text: attachPrefix + value });
      } catch (e) {
        console.error("Send failed", e);
        toast.error("Message could not be sent.");
      }
      inputRef.current?.focus();
    },
    [attachments, sendMessage],
  );

  const submit = useCallback(
    (value: string) => {
      const text = value.trim();
      if (!text || isBusy || research) return;

      if (!webSearch) {
        void dispatch(text);
        return;
      }

      // Deep Research: real web search, then stream the cited answer.
      setResearch({ query: text, phase: "search", sourceCount: 0 });
      void (async () => {
        try {
          const result = await runResearch({ data: { query: text, limit: 5 } });
          setResearch({ query: text, phase: "analyze", sourceCount: result.sources.length });
          await new Promise((r) => setTimeout(r, 450));
          setResearch({ query: text, phase: "synthesize", sourceCount: result.sources.length });
          await new Promise((r) => setTimeout(r, 250));
          setResearch(null);
          if (!result.sources.length) {
            toast.warning("No web results found — answering from model knowledge.");
            await dispatch(text);
            return;
          }
          await dispatch(text, result.sources);
        } catch (e) {
          console.error("Deep Research failed", e);
          setResearch(null);
          toast.error(e instanceof Error ? e.message : "Web search failed.");
        }
      })();
    },
    [dispatch, isBusy, research, runResearch, webSearch],
  );

  const empty = !isLoading && messages.length === 0;
  const userInitial = (user.email?.[0] ?? "U").toUpperCase();
  const lastId = messages.length ? messages[messages.length - 1].id : null;

  return (
    <div className="flex h-full min-h-0 flex-col">
      <div ref={scrollerRef} onScroll={onScroll} className="flex-1 min-h-0 overflow-y-auto overflow-x-hidden">
        <div className="mx-auto w-full max-w-3xl">
          {empty ? (
            <div className="flex h-full flex-col items-center justify-center px-6 py-24 text-center">
              <Logo size={56} withText={false} />
              <h2 className="mt-6 text-3xl font-bold">How can I help you today?</h2>
              <p className="mt-2 text-sm text-muted-foreground">
                Ask anything — I can write, code, analyze, and more.
              </p>
              <div className="mt-8 grid w-full max-w-2xl gap-2 sm:grid-cols-2">
                {suggestions.map((s) => (
                  <button
                    key={s}
                    onClick={() => submit(s)}
                    className="glass rounded-xl p-4 text-left text-sm transition-all hover:border-primary/50 hover:bg-primary/5"
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>
          ) : (
            <>
              {messages.map((m) => (
                <ChatMessage
                  key={m.id}
                  message={m}
                  userInitial={userInitial}
                  onUpgrade={() => setShowPayment(true)}
                  streaming={status === "streaming" && m.role === "assistant" && m.id === lastId}
                />
              ))}
              {status === "submitted" && (
                <div className="flex gap-4 px-4 py-6">
                  <div className="glass flex h-8 w-8 items-center justify-center rounded-full">
                    <Logo size={20} withText={false} />
                  </div>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Sparkles className="h-4 w-4 animate-pulse text-primary" /> Thinking…
                  </div>
                </div>
              )}
              <div className="h-8" />
            </>
          )}
        </div>
      </div>

      <div className="glass-strong border-t border-border/50 p-4">
        <div className="mx-auto w-full max-w-3xl">
          {research && (
            <DeepResearchProgress
              query={research.query}
              phase={research.phase}
              sourceCount={research.sourceCount}
            />
          )}

          {isBusy && (
            <div className="mb-2 flex justify-center">
              <button
                type="button"
                onClick={() => void handleStop()}
                className="inline-flex items-center gap-1.5 rounded-lg border border-border/60 bg-background/60 px-3 py-1.5 text-xs text-muted-foreground transition-colors hover:text-foreground"
              >
                <Square className="h-3 w-3 fill-current" /> Stop generating
              </button>
            </div>
          )}

          <ChatInput
            ref={inputRef}
            busy={!!research}
            placeholder={webSearch ? "Ask the web…" : "Message SMS AI…"}
            onSubmit={submit}
          />

          <div className="mt-2 flex flex-wrap items-center gap-2 px-1">
            <MoodSelector />
            <MathKeyboard onInsert={(s) => inputRef.current?.insert(s)} />

            <button
              type="button"
              onClick={() => setWebSearch((w) => !w)}
              className={cn(
                "inline-flex items-center gap-1.5 rounded-lg border px-2.5 py-1.5 text-xs transition-colors",
                webSearch
                  ? "border-primary/60 bg-primary/15 text-primary"
                  : "border-border/50 text-muted-foreground hover:bg-muted/40 hover:text-foreground",
              )}
              title="Web Intelligence Agent"
            >
              <Globe className="h-3.5 w-3.5" />
              Web Intelligence {webSearch ? "· on" : ""}
            </button>

            <AttachMenu attachments={attachments} onChange={setAttachments} />

            <button
              type="button"
              onClick={() => (isPremium ? setShowImageGen(true) : setShowPayment(true))}
              className="inline-flex items-center gap-1.5 rounded-lg border border-border/50 px-2.5 py-1.5 text-xs text-muted-foreground transition-colors hover:bg-muted/40 hover:text-foreground"
              title={isPremium ? "Generate image" : "Premium feature — upgrade to unlock"}
            >
              {isPremium ? <ImageIcon className="h-3.5 w-3.5" /> : <Lock className="h-3.5 w-3.5" />}
              Image
            </button>

            <p className="ml-auto text-[10px] text-muted-foreground">
              SMS AI can make mistakes. Verify important information.
            </p>
          </div>
        </div>
      </div>

      <ImageGenerator open={showImageGen} onOpenChange={setShowImageGen} />
      <PaymentModal open={showPayment} onOpenChange={setShowPayment} />
    </div>
  );
}
