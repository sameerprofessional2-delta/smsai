import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { MODELS, TONES, simulateReply, usePersona } from "@/lib/sms-suite";
import { cn } from "@/lib/utils";
import { RotateCcw, Send, Signal, Sparkles, Wifi, BatteryFull } from "lucide-react";

export const Route = createFileRoute("/_authenticated/suite/simulator")({
  component: SimulatorPage,
});

type Bubble = { id: string; from: "me" | "ai"; text: string; confidence?: number };

const STARTERS = ["Where's my order?", "Is the sale still on?", "I want a refund", "What are your hours?"];

function SimulatorPage() {
  const { persona } = usePersona();
  const [bubbles, setBubbles] = useState<Bubble[]>([
    { id: "b0", from: "ai", text: `Hi! ${persona.agentName.split(" ")[0]} here — text me anything.`, confidence: 99 },
  ]);
  const [input, setInput] = useState("");
  const [typing, setTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  const model = MODELS.find((m) => m.id === persona.model)!;
  const tone = TONES.find((t) => t.id === persona.tone)!;

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [bubbles, typing]);

  async function send(text?: string) {
    const value = (text ?? input).trim();
    if (!value || typing) return;
    setInput("");
    setBubbles((b) => [...b, { id: `${Date.now()}`, from: "me", text: value }]);
    setTyping(true);
    await new Promise((r) => setTimeout(r, 300 + (6 - model.speed) * 260));
    const reply = simulateReply(value, persona);
    setTyping(false);
    setBubbles((b) => [...b, { id: `${Date.now()}-ai`, from: "ai", text: reply.text, confidence: reply.confidence }]);
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Live SMS Sandbox</h1>
        <p className="text-sm text-muted-foreground">Text your agent and watch it respond with the persona you configured.</p>
      </div>

      <div className="grid gap-6 lg:grid-cols-[380px_minmax(0,1fr)] items-start">
        {/* Phone mockup */}
        <div className="mx-auto w-[340px] rounded-[2.6rem] border border-border/60 bg-background/60 p-3 shadow-2xl backdrop-blur-xl">
          <div className="relative rounded-[2.1rem] border border-border/50 bg-muted/20 overflow-hidden h-[620px] flex flex-col">
            <div className="absolute left-1/2 top-2 z-10 h-6 w-28 -translate-x-1/2 rounded-full bg-background/90" />
            <div className="flex items-center justify-between px-5 pt-3 pb-2 text-[10px] text-muted-foreground">
              <span>9:41</span>
              <span className="flex items-center gap-1"><Signal className="h-3 w-3" /><Wifi className="h-3 w-3" /><BatteryFull className="h-3 w-3" /></span>
            </div>
            <div className="px-4 py-2 border-b border-border/50 text-center">
              <div className="text-sm font-semibold">{persona.agentName}</div>
              <div className="text-[10px] text-muted-foreground">{tone.emoji} {tone.label} · {model.label}</div>
            </div>

            <div ref={scrollRef} className="flex-1 overflow-y-auto p-3 space-y-2">
              {bubbles.map((b) => (
                <div key={b.id} className={cn("flex flex-col animate-fade-in", b.from === "me" ? "items-end" : "items-start")}>
                  <div
                    className={cn(
                      "max-w-[80%] rounded-2xl px-3.5 py-2 text-[13px] leading-snug",
                      b.from === "me" ? "bg-primary text-primary-foreground rounded-br-sm" : "bg-muted text-foreground rounded-bl-sm",
                    )}
                  >
                    {b.text}
                  </div>
                  {b.from === "ai" && b.confidence != null && (
                    <span className="mt-0.5 text-[9.5px] text-muted-foreground">Confidence {b.confidence}%</span>
                  )}
                </div>
              ))}
              {typing && (
                <div className="flex items-center gap-1 rounded-2xl rounded-bl-sm bg-muted px-3 py-2.5 w-fit">
                  <span className="h-1.5 w-1.5 rounded-full bg-foreground/60 animate-bounce [animation-delay:0ms]" />
                  <span className="h-1.5 w-1.5 rounded-full bg-foreground/60 animate-bounce [animation-delay:120ms]" />
                  <span className="h-1.5 w-1.5 rounded-full bg-foreground/60 animate-bounce [animation-delay:240ms]" />
                </div>
              )}
            </div>

            <div className="p-3 border-t border-border/50">
              <div className="relative">
                <input
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && send()}
                  placeholder="Text message"
                  className="w-full rounded-full bg-muted/50 border border-border/50 pl-4 pr-10 py-2.5 text-[13px] outline-none focus:border-primary/60 transition-colors"
                />
                <button
                  onClick={() => send()}
                  disabled={!input.trim() || typing}
                  className="absolute right-1.5 top-1.5 h-7 w-7 rounded-full bg-gradient-to-r from-primary to-primary-glow text-primary-foreground flex items-center justify-center disabled:opacity-40"
                >
                  <Send className="h-3.5 w-3.5" />
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Side panel */}
        <div className="space-y-4">
          <section className="glass rounded-2xl p-5">
            <h3 className="font-semibold">Active configuration</h3>
            <div className="mt-3 grid gap-2 sm:grid-cols-2 text-sm">
              <Info label="Agent" value={persona.agentName} />
              <Info label="Tone" value={`${tone.emoji} ${tone.label}`} />
              <Info label="Model" value={model.label} />
              <Info label="Auto-reply" value={persona.autoReply ? "On" : "Off"} />
            </div>
            <div className="mt-3 flex flex-wrap gap-1.5">
              {persona.knowledge.map((k) => (
                <Badge key={k.id} variant="outline" className="text-[10px] py-0 px-1.5">{k.name}</Badge>
              ))}
            </div>
            <p className="mt-3 text-[11px] text-muted-foreground line-clamp-3">{persona.instructions}</p>
          </section>

          <section className="glass rounded-2xl p-5">
            <h3 className="font-semibold flex items-center gap-2"><Sparkles className="h-4 w-4 text-primary" /> Try a scenario</h3>
            <div className="mt-3 grid gap-2 sm:grid-cols-2">
              {STARTERS.map((s) => (
                <button
                  key={s}
                  onClick={() => send(s)}
                  className="rounded-xl border border-border/50 bg-muted/20 p-3 text-left text-sm transition-all hover:-translate-y-0.5 hover:border-primary/50 hover:bg-primary/5"
                >
                  {s}
                </button>
              ))}
            </div>
            <Button
              variant="outline"
              className="mt-3 w-full"
              onClick={() => setBubbles([{ id: "b0", from: "ai", text: `Hi! ${persona.agentName.split(" ")[0]} here — text me anything.`, confidence: 99 }])}
            >
              <RotateCcw className="h-4 w-4 mr-2" /> Reset conversation
            </Button>
          </section>
        </div>
      </div>
    </div>
  );
}

function Info({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg border border-border/50 bg-muted/20 px-3 py-2">
      <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</div>
      <div className="text-[13px] truncate">{value}</div>
    </div>
  );
}
