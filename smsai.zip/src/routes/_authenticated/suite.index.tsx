import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Line,
  LineChart,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { CONVERSION_DATA, SENTIMENT_DATA, VOLUME_DATA } from "@/lib/sms-suite";
import { Skeleton } from "@/components/ui/skeleton";
import { Slider } from "@/components/ui/slider";
import { Bot, MessageSquare, MousePointerClick, PiggyBank, TrendingUp } from "lucide-react";

export const Route = createFileRoute("/_authenticated/suite/")({
  component: AnalyticsPage,
});

const SENTIMENT_SPLIT = [
  { name: "Positive", value: 74, color: "hsl(152 60% 50%)" },
  { name: "Neutral", value: 20, color: "hsl(220 12% 55%)" },
  { name: "Negative", value: 6, color: "hsl(0 70% 58%)" },
];

function useMockLoad(ms = 700) {
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    const t = setTimeout(() => setLoading(false), ms);
    return () => clearTimeout(t);
  }, [ms]);
  return loading;
}

function Kpi({ icon: Icon, label, value, delta }: { icon: typeof Bot; label: string; value: string; delta: string }) {
  return (
    <div className="glass rounded-2xl p-5 transition-all duration-300 hover:-translate-y-0.5 hover:border-primary/50">
      <div className="flex items-center justify-between">
        <span className="text-xs uppercase tracking-wider text-muted-foreground">{label}</span>
        <Icon className="h-4 w-4 text-primary" />
      </div>
      <div className="mt-3 text-3xl font-bold">{value}</div>
      <div className="mt-1 text-xs text-emerald-400 flex items-center gap-1">
        <TrendingUp className="h-3 w-3" /> {delta}
      </div>
    </div>
  );
}

function ChartCard({ title, subtitle, children }: { title: string; subtitle: string; children: React.ReactNode }) {
  return (
    <div className="glass rounded-2xl p-5">
      <h3 className="font-semibold">{title}</h3>
      <p className="text-xs text-muted-foreground mb-4">{subtitle}</p>
      <div className="h-64">{children}</div>
    </div>
  );
}

const tooltipStyle = {
  background: "hsl(var(--popover, 240 10% 8%))",
  border: "1px solid hsl(var(--border, 240 6% 20%))",
  borderRadius: 12,
  fontSize: 12,
  color: "inherit",
} as const;

function AnalyticsPage() {
  const loading = useMockLoad();
  const [volume, setVolume] = useState(42000);
  const [minutes, setMinutes] = useState(3);
  const [rate, setRate] = useState(22);

  const automationRate = 88;
  const savedHours = Math.round((volume * (automationRate / 100) * minutes) / 60);
  const savings = savedHours * rate;

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="h-28 rounded-2xl" />
          ))}
        </div>
        <div className="grid gap-4 lg:grid-cols-2">
          <Skeleton className="h-80 rounded-2xl" />
          <Skeleton className="h-80 rounded-2xl" />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Analytics &amp; ROI</h1>
        <p className="text-sm text-muted-foreground">Live performance across every SMS conversation and campaign.</p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Kpi icon={MessageSquare} label="Messages / week" value="9,920" delta="+12.4% vs last week" />
        <Kpi icon={Bot} label="AI automation rate" value="88%" delta="+3.1 pts" />
        <Kpi icon={MousePointerClick} label="Link click rate" value="34.2%" delta="+5.8 pts" />
        <Kpi icon={PiggyBank} label="Est. monthly savings" value="$41.2k" delta="+$6.9k" />
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <ChartCard title="Message volume & AI automation" subtitle="Total inbound vs. handled autonomously by AI">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={VOLUME_DATA}>
              <defs>
                <linearGradient id="gTotal" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="currentColor" stopOpacity={0.35} className="text-muted-foreground" />
                  <stop offset="100%" stopColor="currentColor" stopOpacity={0} className="text-muted-foreground" />
                </linearGradient>
                <linearGradient id="gAi" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="currentColor" stopOpacity={0.5} className="text-primary" />
                  <stop offset="100%" stopColor="currentColor" stopOpacity={0} className="text-primary" />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" strokeOpacity={0.12} />
              <XAxis dataKey="day" tickLine={false} axisLine={false} fontSize={11} />
              <YAxis tickLine={false} axisLine={false} fontSize={11} width={40} />
              <Tooltip contentStyle={tooltipStyle} />
              <Legend wrapperStyle={{ fontSize: 11 }} />
              <Area type="monotone" dataKey="total" name="All messages" stroke="currentColor" className="text-muted-foreground" fill="url(#gTotal)" strokeWidth={2} />
              <Area type="monotone" dataKey="ai" name="Handled by AI" stroke="currentColor" className="text-primary" fill="url(#gAi)" strokeWidth={2} />
            </AreaChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Campaign conversion" subtitle="Link click rate vs. purchase conversion (%)">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={CONVERSION_DATA}>
              <CartesianGrid strokeDasharray="3 3" strokeOpacity={0.12} />
              <XAxis dataKey="week" tickLine={false} axisLine={false} fontSize={11} />
              <YAxis tickLine={false} axisLine={false} fontSize={11} width={40} unit="%" />
              <Tooltip contentStyle={tooltipStyle} />
              <Legend wrapperStyle={{ fontSize: 11 }} />
              <Line type="monotone" dataKey="clicks" name="Click rate" stroke="currentColor" className="text-primary" strokeWidth={2.5} dot={{ r: 3 }} />
              <Line type="monotone" dataKey="conversions" name="Conversion" stroke="hsl(152 60% 50%)" strokeWidth={2.5} dot={{ r: 3 }} />
            </LineChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Sentiment trend" subtitle="Share of conversations by detected sentiment">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={SENTIMENT_DATA} stackOffset="expand">
              <CartesianGrid strokeDasharray="3 3" strokeOpacity={0.12} />
              <XAxis dataKey="day" tickLine={false} axisLine={false} fontSize={11} />
              <YAxis tickLine={false} axisLine={false} fontSize={11} width={40} tickFormatter={(v: number) => `${Math.round(v * 100)}%`} />
              <Tooltip contentStyle={tooltipStyle} />
              <Legend wrapperStyle={{ fontSize: 11 }} />
              <Bar dataKey="positive" name="Positive" stackId="s" fill="hsl(152 60% 50%)" radius={[4, 4, 0, 0]} />
              <Bar dataKey="neutral" name="Neutral" stackId="s" fill="hsl(220 12% 45%)" />
              <Bar dataKey="negative" name="Negative" stackId="s" fill="hsl(0 70% 58%)" radius={[0, 0, 4, 4]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <div className="glass rounded-2xl p-5">
          <h3 className="font-semibold">Cost savings calculator</h3>
          <p className="text-xs text-muted-foreground mb-5">Model what AI deflection is worth to your support desk.</p>
          <div className="grid gap-5 sm:grid-cols-2">
            <div className="space-y-5">
              <Field label="Monthly messages" value={volume.toLocaleString()}>
                <Slider value={[volume]} onValueChange={([v]) => setVolume(v ?? 0)} min={1000} max={200000} step={1000} />
              </Field>
              <Field label="Minutes saved per message" value={`${minutes} min`}>
                <Slider value={[minutes]} onValueChange={([v]) => setMinutes(v ?? 0)} min={1} max={10} step={1} />
              </Field>
              <Field label="Agent hourly cost" value={`$${rate}/hr`}>
                <Slider value={[rate]} onValueChange={([v]) => setRate(v ?? 0)} min={10} max={80} step={1} />
              </Field>
            </div>
            <div className="rounded-2xl border border-primary/40 bg-gradient-to-br from-primary/15 to-primary-glow/5 p-5 flex flex-col justify-center">
              <div className="text-xs uppercase tracking-wider text-muted-foreground">Estimated monthly savings</div>
              <div className="mt-2 text-4xl font-bold text-primary">
                ${savings.toLocaleString(undefined, { maximumFractionDigits: 0 })}
              </div>
              <div className="mt-2 text-xs text-muted-foreground">
                {savedHours.toLocaleString()} agent hours deflected at an {automationRate}% automation rate.
              </div>
              <div className="mt-4 h-24">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie data={SENTIMENT_SPLIT} dataKey="value" innerRadius={26} outerRadius={44} paddingAngle={3} stroke="none">
                      {SENTIMENT_SPLIT.map((s) => (
                        <Cell key={s.name} fill={s.color} />
                      ))}
                    </Pie>
                    <Tooltip contentStyle={tooltipStyle} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function Field({ label, value, children }: { label: string; value: string; children: React.ReactNode }) {
  return (
    <div>
      <div className="flex items-center justify-between text-xs mb-2">
        <span className="text-muted-foreground">{label}</span>
        <span className="font-medium">{value}</span>
      </div>
      {children}
    </div>
  );
}
