import { createFileRoute, Outlet, useNavigate, useParams, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Logo } from "@/components/Logo";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { ThemeSwitcher } from "@/components/ThemeSwitcher";
import { PaymentModal } from "@/components/PaymentModal";
import { useProfile } from "@/lib/profile";
import { useServerFn } from "@tanstack/react-start";
import { checkAdminAccess } from "@/lib/admin.functions";
import { Plus, MessageSquare, Search, LogOut, LayoutDashboard, Trash2, ShieldAlert, Sparkles, Zap } from "lucide-react";
import { useState, useMemo } from "react";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/chat")({
  head: () => ({ meta: [{ title: "Chat — SMS AI" }] }),
  component: ChatLayout,
});

function ChatLayout() {
  const { user } = Route.useRouteContext();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const params = useParams({ strict: false }) as { threadId?: string };
  const activeId = params.threadId;
  const [query, setQuery] = useState("");
  const [showPay, setShowPay] = useState(false);
  const { isPremium, tier } = useProfile();
  const checkAccess = useServerFn(checkAdminAccess);
  const { data: adminAccess } = useQuery({
    queryKey: ["admin", "access", user.id],
    queryFn: () => checkAccess(),
    staleTime: 60_000,
  });
  const isAdmin = !!adminAccess?.isAdmin;

  const { data: threads = [] } = useQuery({
    queryKey: ["threads", user.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("chat_threads")
        .select("id, title, updated_at")
        .order("updated_at", { ascending: false });
      if (error) throw error;
      return data ?? [];
    },
  });

  const filtered = useMemo(
    () => (query.trim() ? threads.filter((t) => t.title.toLowerCase().includes(query.toLowerCase())) : threads),
    [threads, query],
  );

  async function newChat() {
    const { data, error } = await supabase
      .from("chat_threads")
      .insert({ user_id: user.id, title: "New chat" })
      .select("id")
      .single();
    if (error || !data) return toast.error("Couldn't create chat");
    qc.invalidateQueries({ queryKey: ["threads", user.id] });
    navigate({ to: "/chat/$threadId", params: { threadId: data.id } });
  }

  async function deleteThread(id: string, e: React.MouseEvent) {
    e.preventDefault();
    e.stopPropagation();
    const { error } = await supabase.from("chat_threads").delete().eq("id", id);
    if (error) return toast.error("Couldn't delete");
    qc.invalidateQueries({ queryKey: ["threads", user.id] });
    if (activeId === id) navigate({ to: "/chat" });
  }

  async function signOut() {
    await qc.cancelQueries();
    qc.clear();
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  }

  return (
    <div className="flex h-screen overflow-hidden">
      {/* Sidebar */}
      <aside className="hidden md:flex w-72 flex-col glass-strong border-r border-border/50">
        <div className="p-4 border-b border-border/50">
          <Link to="/"><Logo /></Link>
        </div>
        <div className="p-3">
          <Button onClick={newChat} className="w-full bg-gradient-to-r from-primary to-primary-glow text-primary-foreground shadow-glow">
            <Plus className="h-4 w-4 mr-2" /> New chat
          </Button>
        </div>
        <div className="px-3 pb-2">
          <div className="relative">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search chats…" className="pl-8 bg-muted/30 border-border/50" />
          </div>
        </div>
        <nav className="flex-1 overflow-y-auto px-2 py-2 space-y-0.5">
          {filtered.length === 0 && <p className="text-xs text-muted-foreground px-3 py-6 text-center">No chats yet</p>}
          {filtered.map((t) => (
            <Link
              key={t.id}
              to="/chat/$threadId"
              params={{ threadId: t.id }}
              className={`group flex items-center gap-2 rounded-lg px-3 py-2 text-sm transition-colors ${
                activeId === t.id ? "bg-primary/10 text-foreground" : "hover:bg-muted/40 text-muted-foreground"
              }`}
            >
              <MessageSquare className="h-3.5 w-3.5 shrink-0" />
              <span className="truncate flex-1">{t.title}</span>
              <button onClick={(e) => deleteThread(t.id, e)} className="opacity-0 group-hover:opacity-100 hover:text-destructive">
                <Trash2 className="h-3.5 w-3.5" />
              </button>
            </Link>
          ))}
        </nav>
        <div className="p-3 border-t border-border/50 space-y-1">
          {!isPremium && (
            <button
              onClick={() => setShowPay(true)}
              className="w-full rounded-xl border border-primary/40 bg-gradient-to-br from-primary/15 to-primary-glow/5 p-3 text-left hover:from-primary/25 transition-all"
            >
              <div className="flex items-center gap-2 text-xs font-semibold">
                <Sparkles className="h-3.5 w-3.5 text-primary" /> Unlock Ultra-Accurate 3000 Mode
              </div>
              <div className="mt-0.5 text-[10.5px] text-muted-foreground">Image gen · Data tables · Premium themes</div>
            </button>
          )}
          <Link to="/suite">
            <Button variant="ghost" className="w-full justify-start" size="sm">
              <Zap className="h-4 w-4 mr-2 text-primary" /> Automation Suite
            </Button>
          </Link>
          <div className="flex items-center justify-between gap-1">
            <Link to="/dashboard" className="flex-1">
              <Button variant="ghost" className="w-full justify-start" size="sm">
                <LayoutDashboard className="h-4 w-4 mr-2" /> Dashboard
              </Button>
            </Link>
            <ThemeSwitcher onUpgrade={() => setShowPay(true)} />
          </div>
          {isAdmin && (
            <Link to="/admin">
              <Button variant="ghost" className="w-full justify-start" size="sm">
                <ShieldAlert className="h-4 w-4 mr-2 text-primary" /> Admin Dashboard
              </Button>
            </Link>
          )}
          <div className="flex items-center gap-2 px-2 py-1.5">
            <div className="h-8 w-8 rounded-full bg-gradient-to-br from-primary to-primary-glow flex items-center justify-center text-xs font-semibold text-primary-foreground">
              {user.email?.[0]?.toUpperCase()}
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-xs truncate">{user.email}</div>
              <div className="text-[10px] text-muted-foreground flex items-center gap-1">
                <Badge variant="outline" className={isPremium ? "bg-primary/15 text-primary border-primary/40 text-[9px] py-0 px-1.5" : "text-[9px] py-0 px-1.5"}>
                  {tier}
                </Badge>
              </div>
            </div>
            <Button variant="ghost" size="icon" onClick={signOut} title="Sign out"><LogOut className="h-4 w-4" /></Button>
          </div>
        </div>
      </aside>

      <main className="flex-1 overflow-hidden relative">
        <Outlet />
      </main>

      <PaymentModal open={showPay} onOpenChange={setShowPay} />
    </div>
  );
}
