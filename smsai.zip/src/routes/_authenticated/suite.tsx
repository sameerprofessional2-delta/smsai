import { createFileRoute, Link, Outlet, useRouterState } from "@tanstack/react-router";
import { AnimatedBackground } from "@/components/AnimatedBackground";
import { SiteHeader } from "@/components/SiteHeader";
import { BarChart3, Bot, Inbox, Megaphone, Smartphone } from "lucide-react";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/suite")({
  head: () => ({
    meta: [
      { title: "Automation Suite — SMS AI by Deltacoders" },
      { name: "description", content: "Enterprise SMS automation: AI personas, live inbox, analytics, campaigns and a live SMS sandbox." },
      { property: "og:title", content: "Automation Suite — SMS AI by Deltacoders" },
      { property: "og:description", content: "AI personas, a 3-pane live inbox, ROI analytics, campaign builder and an SMS sandbox." },
    ],
  }),
  component: SuiteLayout,
});

const NAV: { to: string; label: string; icon: typeof BarChart3; exact?: boolean }[] = [
  { to: "/suite", label: "Analytics & ROI", icon: BarChart3, exact: true },
  { to: "/suite/persona", label: "AI Persona", icon: Bot },
  { to: "/suite/inbox", label: "Live Inbox", icon: Inbox },
  { to: "/suite/campaigns", label: "Campaigns", icon: Megaphone },
  { to: "/suite/simulator", label: "Sandbox", icon: Smartphone },
];

function SuiteLayout() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  return (
    <div className="relative min-h-screen">
      <AnimatedBackground />
      <SiteHeader />
      <div className="container mx-auto px-4 md:px-6 py-6">
        <nav className="glass rounded-2xl p-1.5 flex gap-1 overflow-x-auto mb-6">
          {NAV.map((item) => {
            const active = item.exact ? pathname === item.to : pathname.startsWith(item.to);
            return (
              <Link
                key={item.to}
                to={item.to}
                className={cn(
                  "flex items-center gap-2 whitespace-nowrap rounded-xl px-3.5 py-2 text-sm transition-all duration-200",
                  active
                    ? "bg-gradient-to-r from-primary to-primary-glow text-primary-foreground shadow-glow"
                    : "text-muted-foreground hover:text-foreground hover:bg-muted/40",
                )}
              >
                <item.icon className="h-4 w-4" />
                {item.label}
              </Link>
            );
          })}
        </nav>
        <div className="animate-fade-in">
          <Outlet />
        </div>
      </div>
    </div>
  );
}
