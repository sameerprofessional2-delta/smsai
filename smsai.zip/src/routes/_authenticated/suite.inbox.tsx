import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import {
  STATUS_META,
  THREADS,
  simulateReply,
  usePersona,
  type InboxThread,
  type SmsMessage,
  type ThreadStatus,
} from "@/lib/sms-suite";
import { cn } from "@/lib/utils";
import { Bot, MapPin, Search, Send, Sparkles, UserRound, Wallet } from "lucide-react";

export const Route = createFileRoute("/_authenticated/suite/inbox")({
  component: InboxPage,
});

const FILTERS: { id: "all" | ThreadStatus; label: string }[] = [
  { id: "all", label: "All" },
  { id: "ai", label: "AI Responded" },
  { id: "review", label: "Needs Review" },
  { id: "closed", label: "Closed" },
];

function InboxPage() {
  const { persona } = usePersona();
  const [threads, setThreads] = useState<InboxThread[]>(THREADS);
  const [filter, setFilter] = useState<"all" | ThreadStatus>("all");
  const [query, setQuery] = useState("");
  const [activeId, setActiveId] = useState(THREADS[0]!.id);
  const [humanMode, setHumanMode] = useState<Record<string, boolean>>({});
  const [draft, setDraft] = useState("");
  const [typing, setTyping] = useState(false);

  const visible = useMemo(
    () =>
      threads.filter(
        (t) =>
          (filter === "all" || t.status === filter) &&
          (!query.trim() || t.name.toLowerCase().includes(query.toLowerCase()) || t.phone.includes(query)),
      ),
    [threads, filter, query],
  );

  const active = threads.find((t) => t.id === activeId) ?? threads[0]!;
  const isHuman = !!humanMode[active.id];

  function push(threadId: string, msg: SmsMessage) {
    setThreads((prev) => prev.map((t) => (t.id === threadId ? { ...t, messages: [...t.messages, msg] } : t)));
  }

  async function send() {
    const text = draft.trim();
    if (!text) return;
    setDraft("");
    push(active.id, {
      id: `${Date.now()}`,
      from: "agent",
      text,
      at: "now",
      byAI: false,
    });

    if (!isHuman && persona.autoReply) {
      setTyping(true);
      await new Promise((r) => setTimeout(r, 1200));
      const reply = simulateReply(text, persona);
      push(active.id, {
        id: `${Date.now()}-ai`,
        from: "customer",
        text: "Thanks — that helps!",
        at: "now",
      });
      setTyping(false);
      void reply;
    }
  }

  function toggleHuman(v: boolean) {
    setHumanMode((m) => ({ ...m, [active.id]: v }));
    toast[v ? "warning" : "success"](
      v ? `Human takeover active for ${active.name} — AI auto-replies paused` : `AI mode restored for ${active.name}`,
    );
  }

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold">Live SMS Inbox</h1>
        <p className="text-sm text-muted-foreground">Triage, review and take over conversations in real time.</p>
      </div>

      <div className="grid gap-4 lg:grid-cols-[300px_minmax(0,1fr)_290px]">
        {/* Pane 1 — thread list */}
        <aside className="glass rounded-2xl flex flex-col overflow-hidden max-h-[70vh]">
          <div className="p-3 border-b border-border/50 space-y-2">
            <div className="relative">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search people…" className="pl-8 bg-muted/30 border-border/50" />
            </div>
            <div className="flex gap-1 flex-wrap">
              {FILTERS.map((f) => (
                <button
                  key={f.id}
                  onClick={() => setFilter(f.id)}
                  className={cn(
                    "rounded-lg px-2.5 py-1 text-[11px] transition-colors",
                    filter === f.id ? "bg-primary/15 text-primary border border-primary/40" : "border border-border/50 text-muted-foreground hover:text-foreground",
                  )}
                >
                  {f.label}
                </button>
              ))}
            </div>
          </div>
          <div className="flex-1 overflow-y-auto p-2 space-y-1">
            {visible.map((t) => (
              <button
                key={t.id}
                onClick={() => setActiveId(t.id)}
                className={cn(
                  "w-full rounded-xl p-3 text-left transition-all duration-200",
                  t.id === active.id ? "bg-primary/10 border border-primary/40" : "border border-transparent hover:bg-muted/40",
                )}
              >
                <div className="flex items-center gap-2">
                  <span className="h-7 w-7 shrink-0 rounded-full bg-gradient-to-br from-primary to-primary-glow text-primary-foreground text-[11px] font-semibold flex items-center justify-center">
                    {t.name[0]}
                  </span>
                  <span className="text-sm font-medium truncate flex-1">{t.name}</span>
                  {t.unread > 0 && (
                    <span className="rounded-full bg-primary px-1.5 text-[10px] text-primary-foreground">{t.unread}</span>
                  )}
                </div>
                <p className="mt-1.5 text-[11.5px] text-muted-foreground line-clamp-1">
                  {t.messages[t.messages.length - 1]?.text}
                </p>
                <Badge variant="outline" className={cn("mt-2 text-[9px] py-0 px-1.5", STATUS_META[t.status].className)}>
                  {STATUS_META[t.status].label}
                </Badge>
              </button>
            ))}
            {visible.length === 0 && <p className="text-xs text-muted-foreground text-center py-8">No conversations match.</p>}
          </div>
        </aside>

        {/* Pane 2 — chat */}
        <section className="glass rounded-2xl flex flex-col overflow-hidden max-h-[70vh]">
          <header className="p-4 border-b border-border/50 flex items-center gap-3">
            <span className="h-9 w-9 rounded-full bg-gradient-to-br from-primary to-primary-glow text-primary-foreground text-sm font-semibold flex items-center justify-center">
              {active.name[0]}
            </span>
            <div className="min-w-0">
              <div className="text-sm font-semibold truncate">{active.name}</div>
              <div className="text-[11px] text-muted-foreground">{active.phone}</div>
            </div>
            <Badge variant="outline" className={cn("ml-auto text-[10px]", STATUS_META[active.status].className)}>
              {STATUS_META[active.status].label}
            </Badge>
          </header>

          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            {active.messages.map((m) => (
              <div key={m.id} className={cn("flex flex-col animate-fade-in", m.from === "agent" ? "items-end" : "items-start")}>
                <div
                  className={cn(
                    "max-w-[78%] rounded-2xl px-3.5 py-2 text-sm",
                    m.from === "agent"
                      ? "bg-primary text-primary-foreground rounded-br-sm"
                      : "bg-muted text-foreground rounded-bl-sm",
                  )}
                >
                  {m.text}
                </div>
                <div className="mt-1 text-[10px] text-muted-foreground flex items-center gap-1.5">
                  {m.byAI && <Sparkles className="h-3 w-3 text-primary" />}
                  {m.byAI ? `AI replied using '${m.persona}' · Confidence ${m.confidence}%` : m.from === "agent" ? "Sent by human agent" : "Customer"} · {m.at}
                </div>
              </div>
            ))}
            {typing && (
              <div className="flex items-center gap-1.5 text-muted-foreground">
                <span className="h-2 w-2 rounded-full bg-primary animate-bounce [animation-delay:0ms]" />
                <span className="h-2 w-2 rounded-full bg-primary animate-bounce [animation-delay:120ms]" />
                <span className="h-2 w-2 rounded-full bg-primary animate-bounce [animation-delay:240ms]" />
                <span className="text-[11px] ml-1">{active.name} is typing…</span>
              </div>
            )}
          </div>

          <footer className="p-3 border-t border-border/50">
            {!isHuman && (
              <p className="mb-2 text-[11px] text-muted-foreground flex items-center gap-1.5">
                <Bot className="h-3.5 w-3.5 text-primary" /> AI mode is handling this thread automatically.
              </p>
            )}
            <div className="relative">
              <Textarea
                value={draft}
                onChange={(e) => setDraft(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && !e.shiftKey) {
                    e.preventDefault();
                    void send();
                  }
                }}
                rows={2}
                placeholder={isHuman ? "Write a manual reply…" : "Send an assist message…"}
                className="resize-none bg-muted/30 border-border/50 pr-12 text-sm"
              />
              <Button
                size="icon"
                onClick={send}
                disabled={!draft.trim()}
                className="absolute right-2 bottom-2 h-8 w-8 rounded-lg bg-gradient-to-r from-primary to-primary-glow text-primary-foreground"
              >
                <Send className="h-4 w-4" />
              </Button>
            </div>
            <div className="mt-1.5 text-[10px] text-muted-foreground text-right">{draft.length}/160 characters</div>
          </footer>
        </section>

        {/* Pane 3 — profile */}
        <aside className="glass rounded-2xl p-4 space-y-4 max-h-[70vh] overflow-y-auto">
          <div className="text-center">
            <span className="mx-auto h-14 w-14 rounded-full bg-gradient-to-br from-primary to-primary-glow text-primary-foreground text-lg font-semibold flex items-center justify-center">
              {active.name[0]}
            </span>
            <div className="mt-2 font-semibold">{active.name}</div>
            <div className="text-[11px] text-muted-foreground">{active.phone}</div>
          </div>

          <div
            className={cn(
              "rounded-xl border p-3 transition-colors",
              isHuman ? "border-amber-500/50 bg-amber-500/10" : "border-primary/40 bg-primary/10",
            )}
          >
            <div className="flex items-center justify-between gap-2">
              <div>
                <div className="text-sm font-medium">{isHuman ? "Human Takeover" : "AI Mode"}</div>
                <div className="text-[10.5px] text-muted-foreground">
                  {isHuman ? "Auto-replies paused" : "Agent replies instantly"}
                </div>
              </div>
              <Switch checked={isHuman} onCheckedChange={toggleHuman} />
            </div>
          </div>

          <div className="space-y-2 text-sm">
            <Row icon={Wallet} label="Lifetime value" value={`$${active.lifetimeValue.toLocaleString()}`} />
            <Row icon={MapPin} label="Location" value={active.location} />
            <Row icon={UserRound} label="Customer since" value={active.joined} />
          </div>

          <div>
            <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-2">Tags</div>
            <div className="flex flex-wrap gap-1.5">
              {active.tags.map((tag) => (
                <Badge key={tag} variant="outline" className="text-[10px] py-0 px-1.5">{tag}</Badge>
              ))}
            </div>
          </div>

          <div className="rounded-xl border border-border/50 bg-muted/20 p-3">
            <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Sentiment</div>
            <div
              className={cn(
                "mt-1 text-sm font-medium capitalize",
                active.sentiment === "positive" ? "text-emerald-400" : active.sentiment === "negative" ? "text-destructive" : "text-muted-foreground",
              )}
            >
              {active.sentiment}
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}

function Row({ icon: Icon, label, value }: { icon: typeof Wallet; label: string; value: string }) {
  return (
    <div className="flex items-center gap-2 rounded-lg border border-border/50 bg-muted/20 px-3 py-2">
      <Icon className="h-3.5 w-3.5 text-primary" />
      <span className="text-[11px] text-muted-foreground">{label}</span>
      <span className="ml-auto text-[12px]">{value}</span>
    </div>
  );
}
