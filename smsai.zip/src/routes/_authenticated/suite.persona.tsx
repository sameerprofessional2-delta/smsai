import { createFileRoute } from "@tanstack/react-router";
import { useRef, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider";
import { Badge } from "@/components/ui/badge";
import { MODELS, TONES, usePersona, type ModelId, type ToneId } from "@/lib/sms-suite";
import { cn } from "@/lib/utils";
import { Check, FileText, Gauge, Trash2, Upload, Zap } from "lucide-react";

export const Route = createFileRoute("/_authenticated/suite/persona")({
  component: PersonaPage,
});

function Meter({ label, value, tone }: { label: string; value: number; tone: "cost" | "speed" | "quality" }) {
  const color = tone === "cost" ? "bg-amber-400" : tone === "speed" ? "bg-sky-400" : "bg-primary";
  return (
    <div className="flex items-center gap-2">
      <span className="w-14 text-[10px] uppercase tracking-wider text-muted-foreground">{label}</span>
      <div className="flex gap-1">
        {Array.from({ length: 5 }).map((_, i) => (
          <span key={i} className={cn("h-1.5 w-4 rounded-full transition-colors", i < value ? color : "bg-muted")} />
        ))}
      </div>
    </div>
  );
}

function PersonaPage() {
  const { persona, setPersona } = usePersona();
  const fileRef = useRef<HTMLInputElement>(null);
  const [saving, setSaving] = useState(false);

  function onFiles(files: FileList | null) {
    if (!files?.length) return;
    const added = Array.from(files).map((f, i) => ({
      id: `${Date.now()}-${i}`,
      name: f.name,
      size: f.size,
      addedAt: new Date().toISOString().slice(0, 10),
    }));
    setPersona({ knowledge: [...persona.knowledge, ...added] });
    toast.success(`${added.length} file(s) added to the knowledge base`);
  }

  async function save() {
    setSaving(true);
    await new Promise((r) => setTimeout(r, 900));
    setSaving(false);
    toast.success("Persona deployed to all active channels");
  }

  return (
    <div className="space-y-6">
      <div className="flex items-end justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-2xl font-bold">AI Persona &amp; Prompt Engine</h1>
          <p className="text-sm text-muted-foreground">Shape how your agent sounds, thinks and escalates.</p>
        </div>
        <Button onClick={save} disabled={saving} className="bg-gradient-to-r from-primary to-primary-glow text-primary-foreground shadow-glow">
          {saving ? "Deploying…" : "Save & deploy"}
        </Button>
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <div className="lg:col-span-2 space-y-4">
          <section className="glass rounded-2xl p-5 space-y-4">
            <h3 className="font-semibold">Identity</h3>
            <div>
              <label className="text-xs text-muted-foreground">Agent name</label>
              <Input
                value={persona.agentName}
                onChange={(e) => setPersona({ agentName: e.target.value })}
                className="mt-1.5 bg-muted/30 border-border/50"
                placeholder="e.g. Ava from Northline"
              />
            </div>
            <div>
              <label className="text-xs text-muted-foreground">Core persona / tone</label>
              <div className="mt-2 grid gap-2 sm:grid-cols-2">
                {TONES.map((t) => (
                  <button
                    key={t.id}
                    onClick={() => setPersona({ tone: t.id as ToneId })}
                    className={cn(
                      "rounded-xl border p-3 text-left transition-all duration-200 hover:-translate-y-0.5",
                      persona.tone === t.id
                        ? "border-primary/60 bg-primary/10 shadow-glow"
                        : "border-border/50 bg-muted/20 hover:bg-muted/40",
                    )}
                  >
                    <div className="flex items-center gap-2 text-sm font-medium">
                      <span>{t.emoji}</span> {t.label}
                      {persona.tone === t.id && <Check className="h-3.5 w-3.5 ml-auto text-primary" />}
                    </div>
                    <div className="mt-0.5 text-[11px] text-muted-foreground">{t.blurb}</div>
                  </button>
                ))}
              </div>
            </div>
            <div>
              <label className="text-xs text-muted-foreground">Custom system instructions</label>
              <Textarea
                value={persona.instructions}
                onChange={(e) => setPersona({ instructions: e.target.value })}
                rows={6}
                className="mt-1.5 bg-muted/30 border-border/50 text-sm"
              />
              <p className="mt-1 text-[10px] text-muted-foreground">{persona.instructions.length} characters</p>
            </div>
            <div className="grid gap-4 sm:grid-cols-2 pt-1">
              <div>
                <div className="flex items-center justify-between text-xs mb-2">
                  <span className="text-muted-foreground">Creativity</span>
                  <span className="font-medium">{persona.creativity}%</span>
                </div>
                <Slider value={[persona.creativity]} onValueChange={([v]) => setPersona({ creativity: v ?? 0 })} max={100} step={5} />
              </div>
              <div className="flex items-center justify-between rounded-xl border border-border/50 bg-muted/20 px-3.5 py-2.5">
                <div>
                  <div className="text-sm">Auto-reply</div>
                  <div className="text-[10.5px] text-muted-foreground">AI answers without approval</div>
                </div>
                <Switch checked={persona.autoReply} onCheckedChange={(v) => setPersona({ autoReply: v })} />
              </div>
            </div>
          </section>

          <section
            className="glass rounded-2xl p-5"
            onDragOver={(e) => e.preventDefault()}
            onDrop={(e) => {
              e.preventDefault();
              onFiles(e.dataTransfer.files);
            }}
          >
            <h3 className="font-semibold">Knowledge base</h3>
            <p className="text-xs text-muted-foreground">FAQs, policies and price lists the agent can quote from.</p>
            <button
              onClick={() => fileRef.current?.click()}
              className="mt-4 w-full rounded-xl border border-dashed border-border/70 bg-muted/10 p-8 text-center transition-colors hover:border-primary/60 hover:bg-primary/5"
            >
              <Upload className="h-6 w-6 mx-auto text-primary" />
              <div className="mt-2 text-sm">Drop files or click to upload</div>
              <div className="text-[11px] text-muted-foreground">PDF, CSV, TXT, MD — up to 20MB each</div>
            </button>
            <input ref={fileRef} type="file" multiple className="hidden" onChange={(e) => onFiles(e.target.files)} />
            <ul className="mt-4 space-y-2">
              {persona.knowledge.map((k) => (
                <li key={k.id} className="flex items-center gap-3 rounded-xl border border-border/50 bg-muted/20 px-3 py-2 text-sm">
                  <FileText className="h-4 w-4 text-primary shrink-0" />
                  <span className="truncate flex-1">{k.name}</span>
                  <span className="text-[10.5px] text-muted-foreground">{(k.size / 1024).toFixed(0)} KB · {k.addedAt}</span>
                  <button
                    className="text-muted-foreground hover:text-destructive transition-colors"
                    onClick={() => setPersona({ knowledge: persona.knowledge.filter((x) => x.id !== k.id) })}
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </li>
              ))}
              {persona.knowledge.length === 0 && (
                <li className="text-xs text-muted-foreground text-center py-4">No documents indexed yet.</li>
              )}
            </ul>
          </section>
        </div>

        <div className="space-y-4">
          <section className="glass rounded-2xl p-5">
            <h3 className="font-semibold">Model backend</h3>
            <p className="text-xs text-muted-foreground mb-3">Balance cost against speed and answer quality.</p>
            <div className="space-y-2">
              {MODELS.map((m) => (
                <button
                  key={m.id}
                  onClick={() => setPersona({ model: m.id as ModelId })}
                  className={cn(
                    "w-full rounded-xl border p-3 text-left transition-all duration-200",
                    persona.model === m.id ? "border-primary/60 bg-primary/10 shadow-glow" : "border-border/50 bg-muted/20 hover:bg-muted/40",
                  )}
                >
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-medium">{m.label}</span>
                    <Badge variant="outline" className="text-[9px] py-0 px-1.5">{m.vendor}</Badge>
                    {persona.model === m.id && <Check className="h-3.5 w-3.5 ml-auto text-primary" />}
                  </div>
                  <div className="mt-2 space-y-1">
                    <Meter label="Cost" value={m.cost} tone="cost" />
                    <Meter label="Speed" value={m.speed} tone="speed" />
                    <Meter label="Quality" value={m.quality} tone="quality" />
                  </div>
                  <div className="mt-2 text-[10.5px] text-muted-foreground">{m.note}</div>
                </button>
              ))}
            </div>
          </section>

          <section className="glass rounded-2xl p-5">
            <h3 className="font-semibold flex items-center gap-2"><Gauge className="h-4 w-4 text-primary" /> Live preview</h3>
            <div className="mt-3 rounded-2xl bg-muted/20 border border-border/50 p-3 space-y-2 text-sm">
              <div className="max-w-[85%] rounded-2xl rounded-bl-sm bg-muted px-3 py-2">Is the flash sale still on?</div>
              <div className="max-w-[85%] ml-auto rounded-2xl rounded-br-sm bg-primary text-primary-foreground px-3 py-2">
                {persona.tone === "aggressive"
                  ? "⏰ 6 hours left — up to 50% off. Go now: nl.co/shop"
                  : persona.tone === "casual"
                    ? "Yep! Still live till midnight 😄 nl.co/shop"
                    : persona.tone === "supportive"
                      ? "It is — happy to help you pick something: nl.co/shop"
                      : `${persona.agentName.split(" ")[0]} here: yes, the sale runs until midnight. nl.co/shop`}
              </div>
              <div className="text-[10px] text-muted-foreground flex items-center gap-1">
                <Zap className="h-3 w-3 text-primary" /> {MODELS.find((m) => m.id === persona.model)?.label} · confidence 94%
              </div>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}
