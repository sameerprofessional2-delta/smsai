import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { ShieldAlert, Trash2, Plus, KeyRound, Lock, RefreshCw, Loader2, Ban, ShieldCheck } from "lucide-react";
import { AnimatedBackground } from "@/components/AnimatedBackground";
import { SiteHeader } from "@/components/SiteHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Accordion, AccordionContent, AccordionItem, AccordionTrigger,
} from "@/components/ui/accordion";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import { toast } from "sonner";
import { useFaqs, useFlags, type Faq } from "@/lib/admin-store";
import { listRealUsers, setUserTier, setUserSuspended, checkAdminAccess, type AdminUserRow } from "@/lib/admin.functions";

export const Route = createFileRoute("/_authenticated/admin")({
  head: () => ({ meta: [{ title: "Admin — SMS AI" }] }),
  component: AdminPage,
});

function Forbidden({ email }: { email: string }) {
  return (
    <div className="relative min-h-screen">
      <AnimatedBackground />
      <SiteHeader />
      <div className="container mx-auto px-6 py-24 flex items-center justify-center">
        <div className="glass rounded-2xl p-10 max-w-lg text-center">
          <div className="mx-auto inline-flex h-14 w-14 items-center justify-center rounded-full bg-destructive/15 border border-destructive/30">
            <Lock className="h-6 w-6 text-destructive" />
          </div>
          <div className="mt-5 text-xs uppercase tracking-[0.2em] text-destructive">Error 403</div>
          <h1 className="mt-2 text-3xl font-bold">Unauthorized Access</h1>
          <p className="mt-3 text-sm text-muted-foreground">
            The account <span className="text-foreground font-medium">{email}</span> does not have permission
            to view the SMS AI control plane. This incident has been logged.
          </p>
          <Link to="/dashboard" className="mt-6 inline-block">
            <Button variant="outline">Back to dashboard</Button>
          </Link>
        </div>
      </div>
    </div>
  );
}

function AdminPage() {
  const { user } = Route.useRouteContext();
  const checkAccess = useServerFn(checkAdminAccess);
  const accessQuery = useQuery({
    queryKey: ["admin", "access", user.id],
    queryFn: () => checkAccess(),
    staleTime: 60_000,
  });

  if (accessQuery.isLoading) {
    return (
      <div className="relative min-h-screen flex items-center justify-center">
        <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
      </div>
    );
  }
  if (!accessQuery.data?.isAdmin) {
    return <Forbidden email={user.email ?? "unknown"} />;
  }
  return <AdminPanel adminEmail={user.email ?? ""} />;
}


function AdminPanel({ adminEmail }: { adminEmail: string }) {
  const fetchUsers = useServerFn(listRealUsers);
  const updateTier = useServerFn(setUserTier);
  const updateSuspended = useServerFn(setUserSuspended);

  const qc = useQueryClient();
  const usersQuery = useQuery({
    queryKey: ["admin", "real-users"],
    queryFn: () => fetchUsers(),
    refetchInterval: 30_000,
  });
  const users: AdminUserRow[] = usersQuery.data ?? [];

  const tierMutation = useMutation({
    mutationFn: (vars: { userId: string; tier: "Free" | "Pro Mode" | "Advanced" }) => updateTier({ data: vars }),
    onSuccess: (_d, vars) => {
      toast.success(`Tier updated → ${vars.tier}`);
      qc.invalidateQueries({ queryKey: ["admin", "real-users"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const suspendMutation = useMutation({
    mutationFn: (vars: { userId: string; suspended: boolean }) => updateSuspended({ data: vars }),
    onMutate: async (vars) => {
      await qc.cancelQueries({ queryKey: ["admin", "real-users"] });
      const prev = qc.getQueryData<AdminUserRow[]>(["admin", "real-users"]);
      qc.setQueryData<AdminUserRow[]>(["admin", "real-users"], (old) =>
        (old ?? []).map((u) =>
          u.id === vars.userId
            ? { ...u, suspended: vars.suspended, status: vars.suspended ? "blocked" : "active" }
            : u,
        ),
      );

      return { prev };
    },
    onSuccess: (_d, vars) => {
      toast.success(vars.suspended ? "User blocked and signed out" : "User unblocked");
      qc.invalidateQueries({ queryKey: ["admin", "real-users"] });
    },
    onError: (e: Error, _v, ctx) => {
      if (ctx?.prev) qc.setQueryData(["admin", "real-users"], ctx.prev);
      toast.error(e.message);
    },
  });


  const [faqs, setFaqs] = useFaqs();
  const [flags, setFlags] = useFlags();
  const [q, setQ] = useState("");
  const [a, setA] = useState("");
  const [userSearch, setUserSearch] = useState("");
  const filteredUsers = userSearch.trim()
    ? users.filter((u) => u.email.toLowerCase().includes(userSearch.toLowerCase()))
    : users;


  const tierColor = (t: AdminUserRow["tier"]) =>
    t === "Advanced" ? "bg-primary/20 text-primary border-primary/30"
    : t === "Pro Mode" ? "bg-blue-500/15 text-blue-300 border-blue-500/30"
    : "bg-muted text-muted-foreground border-border";

  function addFaq() {
    if (!q.trim() || !a.trim()) {
      toast.error("Both question and answer are required");
      return;
    }
    const next: Faq = { id: crypto.randomUUID(), question: q.trim(), answer: a.trim() };
    setFaqs([...faqs, next]);
    setQ(""); setA("");
    toast.success("FAQ published to home page");
  }

  function removeFaq(id: string) {
    setFaqs(faqs.filter((f) => f.id !== id));
    toast.success("FAQ removed");
  }

  const fmt = (iso: string | null) => {
    if (!iso) return "—";
    try { return new Date(iso).toLocaleString(); } catch { return iso; }
  };

  return (
    <div className="relative min-h-screen">
      <AnimatedBackground />
      <SiteHeader />
      <div className="container mx-auto px-6 py-10 space-y-8">
        <div className="flex items-center gap-3">
          <div className="inline-flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-primary/30 to-primary-glow/10 border border-primary/30">
            <ShieldAlert className="h-5 w-5 text-primary" />
          </div>
          <div>
            <h1 className="text-3xl font-bold">Admin Control Plane</h1>
            <p className="text-sm text-muted-foreground">Signed in as {adminEmail}</p>
          </div>
        </div>

        {/* USERS */}
        <section className="glass rounded-2xl p-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="font-semibold">User Management</h2>
              <p className="text-xs text-muted-foreground">Live accounts registered on SMS AI.</p>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant="outline">{users.length} {users.length === 1 ? "user" : "users"}</Badge>
              <Button size="sm" variant="ghost" onClick={() => usersQuery.refetch()} disabled={usersQuery.isFetching}>
                {usersQuery.isFetching
                  ? <Loader2 className="h-3.5 w-3.5 mr-1 animate-spin" />
                  : <RefreshCw className="h-3.5 w-3.5 mr-1" />}
                Refresh
              </Button>
            </div>
          </div>
          <div className="mb-3">
            <Input
              value={userSearch}
              onChange={(e) => setUserSearch(e.target.value)}
              placeholder="Search users by email…"
              className="max-w-sm bg-muted/30 border-border/50"
            />
          </div>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Email</TableHead>
                  <TableHead>Registered</TableHead>
                  <TableHead>Last sign-in</TableHead>
                  <TableHead>Provider</TableHead>
                  <TableHead>Plan</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {usersQuery.isLoading && (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center text-muted-foreground py-8">
                      <Loader2 className="h-4 w-4 animate-spin inline mr-2" />
                      Loading live accounts…
                    </TableCell>
                  </TableRow>
                )}
                {usersQuery.isError && (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center text-destructive py-8">
                      Failed to load users. {(usersQuery.error as Error)?.message}
                    </TableCell>
                  </TableRow>
                )}
                {!usersQuery.isLoading && filteredUsers.length === 0 && !usersQuery.isError && (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center text-muted-foreground py-8">
                      {userSearch ? "No users match your search." : "No registered users yet."}
                    </TableCell>
                  </TableRow>
                )}
                {filteredUsers.map((u) => {
                  const isBlocked = u.suspended || u.status === "blocked";
                  return (
                  <TableRow key={u.id} className={isBlocked ? "opacity-60" : ""}>
                    <TableCell className="font-medium">
                      {u.email}
                      {u.role === "admin" && (
                        <Badge variant="outline" className="ml-2 bg-primary/15 text-primary border-primary/30">Admin</Badge>
                      )}
                    </TableCell>
                    <TableCell className="text-muted-foreground">{fmt(u.registered)}</TableCell>
                    <TableCell className="text-muted-foreground">{fmt(u.lastSignIn)}</TableCell>
                    <TableCell className="text-muted-foreground capitalize">{u.provider}</TableCell>
                    <TableCell>
                      <Badge variant="outline" className={tierColor(u.tier)}>{u.tier}</Badge>
                    </TableCell>
                    <TableCell>
                      {isBlocked
                        ? <Badge variant="outline" className="bg-destructive/15 text-destructive border-destructive/30">Blocked</Badge>
                        : <Badge variant="outline" className="bg-emerald-500/15 text-emerald-300 border-emerald-500/30">Active</Badge>}
                    </TableCell>

                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-1">
                        <Select
                          value={u.tier}
                          onValueChange={(v) => tierMutation.mutate({ userId: u.id, tier: v as AdminUserRow["tier"] })}
                          disabled={tierMutation.isPending}
                        >
                          <SelectTrigger className="h-7 w-[120px] text-xs"><SelectValue /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Free">Free</SelectItem>
                            <SelectItem value="Pro Mode">Pro Mode</SelectItem>
                            <SelectItem value="Advanced">Advanced</SelectItem>
                          </SelectContent>
                        </Select>
                        <Button size="sm" variant="ghost" onClick={() => toast.success(`Reset link queued for ${u.email}`)}>
                          <KeyRound className="h-3.5 w-3.5" />
                        </Button>
                        {u.role === "admin" ? (
                          <Button size="sm" variant="ghost" disabled title="Admin account cannot be blocked">
                            <ShieldCheck className="h-3.5 w-3.5 mr-1" /> Protected
                          </Button>
                        ) : isBlocked ? (
                          <Button
                            size="sm"
                            variant="secondary"
                            onClick={() => suspendMutation.mutate({ userId: u.id, suspended: false })}
                            disabled={suspendMutation.isPending}
                          >
                            <ShieldCheck className="h-3.5 w-3.5 mr-1" /> Unblock User
                          </Button>
                        ) : (
                          <Button
                            size="sm"
                            variant="destructive"
                            onClick={() => suspendMutation.mutate({ userId: u.id, suspended: true })}
                            disabled={suspendMutation.isPending}
                          >
                            <Ban className="h-3.5 w-3.5 mr-1" /> Block User
                          </Button>
                        )}


                      </div>
                    </TableCell>
                  </TableRow>
                );
                })}

              </TableBody>
            </Table>
          </div>
        </section>

        <div className="grid lg:grid-cols-2 gap-6">
          {/* FAQ MANAGEMENT */}
          <section className="glass rounded-2xl p-6">
            <h2 className="font-semibold">FAQ & System Rules</h2>
            <p className="text-xs text-muted-foreground mt-1">Live-publishes to the home page accordion.</p>
            <div className="mt-4 space-y-2">
              <Input placeholder="Question" value={q} onChange={(e) => setQ(e.target.value)} />
              <Textarea placeholder="Answer" value={a} onChange={(e) => setA(e.target.value)} rows={3} />
              <Button onClick={addFaq} className="bg-gradient-to-r from-primary to-primary-glow text-primary-foreground">
                <Plus className="h-4 w-4 mr-1" /> Publish FAQ
              </Button>
            </div>
            <div className="mt-5">
              <Accordion type="single" collapsible className="w-full">
                {faqs.map((f) => (
                  <AccordionItem key={f.id} value={f.id}>
                    <div className="flex items-center gap-2">
                      <AccordionTrigger className="flex-1 text-left">{f.question}</AccordionTrigger>
                      <Button size="icon" variant="ghost" onClick={() => removeFaq(f.id)} aria-label="Remove">
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </div>
                    <AccordionContent className="text-muted-foreground">{f.answer}</AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
              {faqs.length === 0 && <p className="text-sm text-muted-foreground">No FAQs yet.</p>}
            </div>
          </section>

          {/* SYSTEM STATUS */}
          <section className="glass rounded-2xl p-6">
            <h2 className="font-semibold">System Status</h2>
            <p className="text-xs text-muted-foreground mt-1">Global master switches across the platform.</p>
            <div className="mt-5 space-y-4">
              {[
                { key: "registrationsOff" as const, label: "Turn off public registrations", desc: "Blocks new sign-ups on the auth page." },
                { key: "maintenanceMode" as const, label: "Enable maintenance mode", desc: "Shows a maintenance banner site-wide." },
                { key: "forceDarkMode" as const, label: "Force global dark mode", desc: "Locks UI to the dark premium theme." },
              ].map((row) => (
                <div key={row.key} className="flex items-center justify-between rounded-xl border border-border/50 p-4">
                  <div>
                    <div className="font-medium text-sm">{row.label}</div>
                    <div className="text-xs text-muted-foreground">{row.desc}</div>
                  </div>
                  <Switch
                    checked={flags[row.key]}
                    onCheckedChange={(v) => {
                      setFlags({ ...flags, [row.key]: v });
                      toast.success(`${row.label}: ${v ? "ON" : "OFF"}`);
                    }}
                  />
                </div>
              ))}
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}
