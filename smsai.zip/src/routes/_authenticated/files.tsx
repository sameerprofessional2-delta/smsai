import { createFileRoute } from "@tanstack/react-router";
import { useCallback, useEffect, useRef, useState } from "react";
import { AnimatedBackground } from "@/components/AnimatedBackground";
import { Button } from "@/components/ui/button";
import { Upload, FileText, Image as ImageIcon, FileSpreadsheet, File as FileIcon, Sparkles, X, ArrowLeft } from "lucide-react";
import { Link } from "@tanstack/react-router";
import { cn } from "@/lib/utils";
import { useServerFn } from "@tanstack/react-start";
import { analyzeDocument } from "@/lib/documents.functions";

export const Route = createFileRoute("/_authenticated/files")({
  head: () => ({ meta: [{ title: "File Lab — SMS AI" }] }),
  component: FileLab,
});

interface UploadedFile {
  id: string;
  name: string;
  size: number;
  type: string;
  url?: string;
  text?: string;
  progress: number;
  status: "uploading" | "ready";
}

function iconFor(type: string) {
  if (type.startsWith("image/")) return ImageIcon;
  if (type === "application/pdf") return FileText;
  if (type.includes("csv") || type.includes("spreadsheet")) return FileSpreadsheet;
  return FileIcon;
}

const TEXT_EXTS = /\.(txt|md|markdown|csv|tsv|json|log|ya?ml|html?|xml|ts|tsx|js|jsx|py|sql)$/i;

function isTextual(f: File) {
  return f.type.startsWith("text/") || /json|csv|xml|javascript|typescript/.test(f.type) || TEXT_EXTS.test(f.name);
}

function FileLab() {
  const [files, setFiles] = useState<UploadedFile[]>([]);
  const [active, setActive] = useState<string | null>(null);
  const [dragging, setDragging] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const runAnalysis = useServerFn(analyzeDocument);

  const accept = (list: FileList | null) => {
    if (!list) return;
    Array.from(list).forEach(async (f) => {
      const id = crypto.randomUUID();
      const isImg = f.type.startsWith("image/");
      const url = isImg ? URL.createObjectURL(f) : undefined;
      const entry: UploadedFile = { id, name: f.name, size: f.size, type: f.type || "application/octet-stream", url, progress: 0, status: "uploading" };
      setFiles((arr) => [entry, ...arr]);
      setActive((cur) => cur ?? id);

      const tick = setInterval(() => {
        setFiles((arr) => arr.map((x) => (x.id === id ? { ...x, progress: Math.min(92, x.progress + Math.random() * 9 + 3) } : x)));
      }, 240);

      const finish = (text: string) =>
        setFiles((arr) => arr.map((x) => (x.id === id ? { ...x, progress: 100, status: "ready", text } : x)));

      try {
        if (!isTextual(f)) {
          clearInterval(tick);
          finish(
            `Preview only — ${f.name}\n\nThis file type isn't text-extractable in the browser yet.\nUpload a TXT, MD, CSV, JSON, XML, HTML or code file to run full AI document analysis with large-file chunking.`,
          );
          return;
        }

        const raw = await f.text();
        const result = await runAnalysis({
          data: { name: f.name, mimeType: f.type || "text/plain", text: raw.slice(0, 2_000_000) },
        });
        clearInterval(tick);

        const header = `${result.name}\n${result.words.toLocaleString()} words · ${result.chars.toLocaleString()} chars · ${result.chunks} chunk${result.chunks === 1 ? "" : "s"} analyzed${result.truncated ? " (truncated)" : ""}\n\n`;
        const detail =
          result.chunks > 1
            ? `\n\n— Per-chunk notes —\n\n${result.chunkSummaries.map((s, i) => `Chunk ${i + 1}:\n${s}`).join("\n\n")}`
            : "";
        finish(header + result.summary + detail);
      } catch (err) {
        clearInterval(tick);
        finish(`Analysis failed: ${err instanceof Error ? err.message : "unknown error"}`);
      }
    });
  };

  const onDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragging(false);
    accept(e.dataTransfer.files);
  }, []);

  useEffect(() => () => files.forEach((f) => f.url && URL.revokeObjectURL(f.url)), [files]);

  const activeFile = files.find((f) => f.id === active);

  return (
    <div className="relative min-h-screen">
      <AnimatedBackground />
      <div className="container mx-auto px-6 py-8">
        <div className="flex items-center justify-between mb-6">
          <div>
            <Link to="/dashboard" className="text-xs text-muted-foreground hover:text-foreground inline-flex items-center gap-1">
              <ArrowLeft className="h-3 w-3" /> Dashboard
            </Link>
            <h1 className="text-3xl font-bold mt-1">File Lab</h1>
            <p className="text-sm text-muted-foreground">Drop a file. Watch the AI read it.</p>
          </div>
          <Button onClick={() => inputRef.current?.click()} className="bg-gradient-to-r from-primary to-primary-glow text-primary-foreground">
            <Upload className="h-4 w-4 mr-2" /> Upload
          </Button>
          <input ref={inputRef} type="file" multiple hidden accept="image/*,application/pdf,.csv,.txt,.md,.json" onChange={(e) => accept(e.target.files)} />
        </div>

        <div
          onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
          onDragLeave={() => setDragging(false)}
          onDrop={onDrop}
          onClick={() => inputRef.current?.click()}
          className={cn(
            "glass rounded-2xl border-2 border-dashed transition-all cursor-pointer p-10 text-center",
            dragging ? "border-primary bg-primary/5" : "border-border/50 hover:border-primary/50",
          )}
        >
          <div className="mx-auto h-12 w-12 rounded-2xl bg-primary/10 flex items-center justify-center">
            <Upload className="h-5 w-5 text-primary" />
          </div>
          <p className="mt-3 font-medium">Drop images, PDFs, CSVs or text here</p>
          <p className="text-xs text-muted-foreground">Up to 20MB · multi-file supported</p>
        </div>

        <div className="mt-6 grid lg:grid-cols-[280px_1fr] gap-6">
          <div className="space-y-2">
            <h3 className="text-xs uppercase tracking-wider text-muted-foreground px-1">Queue</h3>
            {files.length === 0 && <p className="text-sm text-muted-foreground px-1">No files yet.</p>}
            {files.map((f) => {
              const Icon = iconFor(f.type);
              return (
                <button
                  key={f.id}
                  onClick={() => setActive(f.id)}
                  className={cn(
                    "w-full text-left glass rounded-xl p-3 transition-colors",
                    active === f.id ? "border-primary/60 bg-primary/5" : "hover:bg-muted/30",
                  )}
                >
                  <div className="flex items-center gap-2">
                    <Icon className="h-4 w-4 text-primary shrink-0" />
                    <span className="text-sm truncate flex-1">{f.name}</span>
                    <button onClick={(e) => { e.stopPropagation(); setFiles((arr) => arr.filter((x) => x.id !== f.id)); }} className="text-muted-foreground hover:text-destructive">
                      <X className="h-3.5 w-3.5" />
                    </button>
                  </div>
                  <div className="mt-2 h-1 rounded-full bg-muted/40 overflow-hidden">
                    <div className="h-full bg-gradient-to-r from-primary to-primary-glow transition-all" style={{ width: `${f.progress}%` }} />
                  </div>
                  <div className="mt-1 text-[10px] text-muted-foreground">{f.status === "ready" ? "Ready" : `Uploading… ${Math.round(f.progress)}%`}</div>
                </button>
              );
            })}
          </div>

          <div className="grid md:grid-cols-2 gap-4 min-h-[420px]">
            <div className="glass rounded-2xl p-4 flex flex-col">
              <div className="text-xs uppercase tracking-wider text-muted-foreground mb-2">Preview</div>
              <div className="flex-1 rounded-xl bg-black/30 border border-border/40 flex items-center justify-center overflow-hidden">
                {!activeFile && <p className="text-sm text-muted-foreground">Select a file to preview</p>}
                {activeFile?.url && <img src={activeFile.url} alt={activeFile.name} className="max-h-full max-w-full object-contain" />}
                {activeFile && !activeFile.url && (
                  <div className="text-center p-6">
                    <FileText className="h-10 w-10 text-primary mx-auto" />
                    <p className="mt-3 text-sm">{activeFile.name}</p>
                    <p className="text-xs text-muted-foreground">{(activeFile.size / 1024).toFixed(1)} KB · {activeFile.type}</p>
                  </div>
                )}
              </div>
            </div>
            <div className="glass rounded-2xl p-4 flex flex-col">
              <div className="flex items-center justify-between mb-2">
                <div className="text-xs uppercase tracking-wider text-muted-foreground">AI Extraction</div>
                <Sparkles className="h-3.5 w-3.5 text-primary" />
              </div>
              <div className="flex-1 rounded-xl bg-black/30 border border-border/40 p-4 overflow-y-auto text-sm whitespace-pre-wrap leading-relaxed">
                {!activeFile && <p className="text-muted-foreground">Awaiting a file…</p>}
                {activeFile?.status === "uploading" && (
                  <div className="text-muted-foreground inline-flex items-center gap-2">
                    <Sparkles className="h-4 w-4 text-primary animate-pulse" /> Reading file…
                  </div>
                )}
                {activeFile?.status === "ready" && activeFile.text}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
