import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useRef } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useQueryClient } from "@tanstack/react-query";
import { Logo } from "@/components/Logo";
import { Sparkles } from "lucide-react";

export const Route = createFileRoute("/_authenticated/chat/")({
  component: ChatIndex,
});

function ChatIndex() {
  const { user } = Route.useRouteContext();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const creating = useRef(false);

  useEffect(() => {
    (async () => {
      if (creating.current) return;
      const { data: existing } = await supabase
        .from("chat_threads")
        .select("id")
        .order("updated_at", { ascending: false })
        .limit(1)
        .maybeSingle();
      if (existing) {
        navigate({ to: "/chat/$threadId", params: { threadId: existing.id }, replace: true });
        return;
      }
      creating.current = true;
      const { data } = await supabase
        .from("chat_threads")
        .insert({ user_id: user.id, title: "New chat" })
        .select("id")
        .single();
      if (data) {
        qc.invalidateQueries({ queryKey: ["threads", user.id] });
        navigate({ to: "/chat/$threadId", params: { threadId: data.id }, replace: true });
      }
    })();
  }, [user.id, navigate, qc]);

  return (
    <div className="h-full flex items-center justify-center">
      <div className="text-center animate-fade-in-up">
        <Logo size={48} withText={false} />
        <div className="mt-4 flex items-center gap-2 text-sm text-muted-foreground">
          <Sparkles className="h-4 w-4 text-primary animate-pulse" /> Preparing your workspace…
        </div>
      </div>
    </div>
  );
}
