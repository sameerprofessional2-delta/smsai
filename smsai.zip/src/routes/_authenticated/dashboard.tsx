import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { AnimatedBackground } from "@/components/AnimatedBackground";
import { SiteHeader } from "@/components/SiteHeader";
import { DebugPanel } from "@/components/DebugPanel";
import { MessageSquare, Sparkles, Zap, TrendingUp, FolderUp } from "lucide-react";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/_authenticated/dashboard")({
  head: () => ({ meta: [{ title: "Dashboard — SMS AI" }] }),
  component: Dashboard,
});

function Dashboard() {
  const { user } = Route.useRouteContext();

  const { data: stats } = useQuery({
    queryKey: ["dashboard-stats", user.id],
    queryFn: async () => {
      const [{ count: threads }, { count: messages }, { data: recent }] = await Promise.all([
        supabase.from("chat_threads").select("*", { count: "exact", head: true }),
        supabase.from("chat_messages").select("*", { count: "exact", head: true }).eq("role", "user"),
        supabase.from("chat_threads").select("id, title, updated_at").order("updated_at", { ascending: false }).limit(5),
      ]);
      return { threads: threads ?? 0, messages: messages ?? 0, recent: recent ?? [] };
    },
  });

  return (
    <div className="relative min-h-screen">
      <AnimatedBackground />
      <SiteHeader />
      <div className="container mx-auto px-6 py-10">
        <div className="flex items-center justify-between flex-wrap gap-4">
          <div>
            <h1 className="text-3xl font-bold">Welcome back</h1>
            <p className="text-muted-foreground">{user.email}</p>
          </div>
          <div className="flex gap-2">
            <Link to="/suite">
              <Button variant="outline">
                <Zap className="h-4 w-4 mr-2" /> Automation Suite
              </Button>
            </Link>
            <Link to="/files">
              <Button variant="outline">
                <FolderUp className="h-4 w-4 mr-2" /> File Lab
              </Button>
            </Link>
            <Link to="/chat">
              <Button className="bg-gradient-to-r from-primary to-primary-glow text-primary-foreground shadow-glow">
                New chat
              </Button>
            </Link>
          </div>
        </div>

        <div className="mt-8 grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            { icon: MessageSquare, label: "Conversations", value: stats?.threads ?? 0 },
            { icon: Sparkles, label: "Messages sent", value: stats?.messages ?? 0 },
            { icon: Zap, label: "Plan", value: "Free" },
            { icon: TrendingUp, label: "Streak", value: "1 day" },
          ].map((s) => (
            <div key={s.label} className="glass rounded-2xl p-6">
              <s.icon className="h-5 w-5 text-primary" />
              <div className="mt-3 text-3xl font-bold">{s.value}</div>
              <div className="text-xs text-muted-foreground mt-1">{s.label}</div>
            </div>
          ))}
        </div>

        <div className="mt-10 glass rounded-2xl p-6">
          <h2 className="font-semibold">Recent chats</h2>
          <div className="mt-4 space-y-2">
            {stats?.recent && stats.recent.length > 0 ? (
              stats.recent.map((t) => (
                <Link key={t.id} to="/chat/$threadId" params={{ threadId: t.id }} className="flex items-center justify-between rounded-lg px-3 py-2 hover:bg-muted/40">
                  <span className="truncate">{t.title}</span>
                  <span className="text-xs text-muted-foreground">{new Date(t.updated_at).toLocaleDateString()}</span>
                </Link>
              ))
            ) : (
              <p className="text-sm text-muted-foreground">No chats yet — start your first conversation.</p>
            )}
          </div>
        </div>

        <div className="mt-6">
          <DebugPanel />
        </div>
      </div>
    </div>
  );
}
