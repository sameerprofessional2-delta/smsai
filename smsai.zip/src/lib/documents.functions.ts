import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { analyzeDocumentText, type DocumentAnalysis } from "@/lib/documents.server";

export type { DocumentAnalysis };

const InputSchema = z.object({
  name: z.string().min(1).max(300),
  mimeType: z.string().max(200).default("text/plain"),
  text: z.string().min(1).max(2_000_000),
});

/**
 * Real document analysis: chunks large text, summarizes each chunk (map),
 * then reduces the chunk summaries into one final analysis.
 */
export const analyzeDocument = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => InputSchema.parse(input))
  .handler(async ({ data }): Promise<DocumentAnalysis> => {
    const key = process.env["LOVABLE_API_KEY"];
    if (!key) throw new Error("Document analysis is not configured.");
    return analyzeDocumentText(key, data.name, data.mimeType, data.text);
  });
