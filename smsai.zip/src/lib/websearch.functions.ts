import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const GATEWAY = "https://connector-gateway.lovable.dev/firecrawl/v2";

export type ResearchSource = {
  index: number;
  title: string;
  url: string;
  snippet: string;
  content: string;
};

export type ResearchResult = {
  query: string;
  sources: ResearchSource[];
};

const InputSchema = z.object({
  query: z.string().min(2).max(600),
  limit: z.number().int().min(1).max(8).optional(),
});

type FirecrawlSearchResponse = {
  success?: boolean;
  error?: string;
  data?:
    | {
        web?: Array<{ url?: string; title?: string; description?: string; markdown?: string }>;
      }
    | Array<{ url?: string; title?: string; description?: string; markdown?: string }>;
};

function clean(value: string, max: number): string {
  return value.replace(/\s+/g, " ").trim().slice(0, max);
}

/** Live web search used by the Deep Research toggle. */
export const deepResearch = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => InputSchema.parse(input))
  .handler(async ({ data }): Promise<ResearchResult> => {
    const lovableKey = process.env["LOVABLE_API_KEY"];
    const connectionKey = process.env["FIRECRAWL_API_KEY"];
    if (!lovableKey || !connectionKey) {
      throw new Error("Web search is not configured for this project.");
    }

    const response = await fetch(`${GATEWAY}/search`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${lovableKey}`,
        "X-Connection-Api-Key": connectionKey,
      },
      body: JSON.stringify({
        query: data.query,
        limit: data.limit ?? 5,
        scrapeOptions: { formats: ["markdown"], onlyMainContent: true },
      }),
    });

    const payload = (await response.json().catch(() => null)) as FirecrawlSearchResponse | null;

    if (!response.ok) {
      const detail = payload?.error ?? response.statusText;
      console.error(`Firecrawl search failed [${response.status}]: ${detail}`);
      if (response.status === 402 || (response.status === 403 && /credit/i.test(String(detail)))) {
        throw new Error("Web search credits are exhausted. Top up credits to keep Deep Research running.");
      }
      throw new Error(`Web search failed (${response.status}): ${detail}`);
    }

    const raw = Array.isArray(payload?.data) ? payload?.data : payload?.data?.web;
    const sources: ResearchSource[] = (raw ?? [])
      .filter((r): r is { url: string; title?: string; description?: string; markdown?: string } => !!r?.url)
      .slice(0, data.limit ?? 5)
      .map((r, i) => ({
        index: i + 1,
        title: clean(r.title || new URL(r.url).hostname, 140) || r.url,
        url: r.url,
        snippet: clean(r.description ?? "", 320),
        content: clean(r.markdown ?? r.description ?? "", 4000),
      }));

    return { query: data.query, sources };
  });
