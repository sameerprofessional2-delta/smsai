import { createParser } from "eventsource-parser";
import { flushSync } from "react-dom";
import { supabase } from "@/integrations/supabase/client";

type ImageEvent =
  | { type: "image_generation.partial_image"; b64_json: string; partial_image_index: number }
  | { type: "image_generation.completed"; b64_json: string };

export async function streamImage(prompt: string, onFrame: (dataUrl: string, isFinal: boolean) => void) {
  const { data: sess } = await supabase.auth.getSession();
  const token = sess.session?.access_token;
  if (!token) throw new Error("Sign in required to generate images");

  const res = await fetch("/api/generate-image", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
    body: JSON.stringify({ prompt }),
  });
  if (!res.ok || !res.body) throw new Error(`Image generation failed: ${res.status}`);

  let completed = false;
  const parser = createParser({
    onEvent(ev) {
      if (ev.event !== "image_generation.partial_image" && ev.event !== "image_generation.completed") return;
      let payload: ImageEvent;
      try { payload = JSON.parse(ev.data); } catch { return; }
      const isFinal = ev.event === "image_generation.completed";
      flushSync(() => onFrame(`data:image/png;base64,${payload.b64_json}`, isFinal));
      if (isFinal) completed = true;
    },
  });

  const reader = res.body.pipeThrough(new TextDecoderStream()).getReader();
  try {
    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      parser.feed(value);
    }
  } finally {
    reader.cancel().catch(() => {});
  }
  if (!completed) throw new Error("Image stream ended without completion");
}
