import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import { supabase } from "@/integrations/supabase/client";

export type ThemeId =
  | "cyber"
  | "sunset"
  | "emerald"
  | "velvet"
  | "stark"
  | "sakura"
  | "solarized"
  | "ocean"
  | "draconic"
  | "steampunk"
  | "arctic";

export const THEMES: { id: ThemeId; label: string; description: string; premium: boolean; swatch: string[] }[] = [
  { id: "cyber",      label: "Deep Cyber",      description: "Neon blue on deep navy",        premium: false, swatch: ["#0b1020", "#1a2548", "#3b82f6", "#8ab4ff"] },
  { id: "sunset",     label: "Sunset Orange",   description: "Warm orange & coral gradients", premium: true,  swatch: ["#1a0f08", "#3d1c0a", "#ff7a1a", "#ffd089"] },
  { id: "emerald",    label: "Emerald Forest",  description: "Deep greens with crisp whites", premium: true,  swatch: ["#0c1a14", "#143226", "#10b981", "#a7f3d0"] },
  { id: "velvet",     label: "Royal Velvet",    description: "Royal purple & antique gold",   premium: true,  swatch: ["#170a1f", "#2b1542", "#a855f7", "#f5d272"] },
  { id: "stark",      label: "Minimal Stark",   description: "Pure monochrome",               premium: false, swatch: ["#0a0a0a", "#1f1f1f", "#a3a3a3", "#fafafa"] },
  { id: "sakura",     label: "Sakura Pink",     description: "Soft pastel cherry blossom",    premium: true,  swatch: ["#fff1f6", "#ffd6e6", "#ff7aa8", "#ffb1c8"] },
  { id: "solarized",  label: "Solarized Light", description: "Retro developer warm cream",    premium: false, swatch: ["#fdf6e3", "#eee8d5", "#cb4b16", "#268bd2"] },
  { id: "ocean",      label: "Ocean Breeze",    description: "Teal & cyan tides",             premium: true,  swatch: ["#08161b", "#0e2d3b", "#22d3ee", "#a5f3fc"] },
  { id: "draconic",   label: "Draconic Blood",  description: "Crimson on obsidian",           premium: true,  swatch: ["#170707", "#3b0e0e", "#ef4444", "#fca5a5"] },
  { id: "steampunk",  label: "Steampunk",       description: "Copper, brass & sepia",         premium: true,  swatch: ["#17120a", "#3a2b14", "#c08454", "#e8c896"] },
  { id: "arctic",     label: "Arctic Frost",    description: "Ice blue with cool gray",       premium: true,  swatch: ["#eef4fb", "#cfe0f1", "#3b82f6", "#9ec3ec"] },
];

const STORAGE_KEY = "sms_ai_theme";
const LIGHT_THEMES: ThemeId[] = ["solarized", "sakura", "arctic"];

function applyTheme(theme: ThemeId) {
  if (typeof document === "undefined") return;
  document.documentElement.setAttribute("data-theme", theme);
  document.documentElement.classList.toggle("dark", !LIGHT_THEMES.includes(theme));
}

type Ctx = { theme: ThemeId; setTheme: (t: ThemeId) => void };
const ThemeContext = createContext<Ctx>({ theme: "cyber", setTheme: () => {} });

export function useTheme() { return useContext(ThemeContext); }

const VALID_IDS = new Set<ThemeId>(THEMES.map((t) => t.id));
function coerce(v: string | null | undefined): ThemeId {
  return v && VALID_IDS.has(v as ThemeId) ? (v as ThemeId) : "cyber";
}

export function ThemeProvider({ children }: { children: ReactNode }) {
  const [theme, setThemeState] = useState<ThemeId>("cyber");

  useEffect(() => {
    const stored = coerce(typeof localStorage !== "undefined" ? localStorage.getItem(STORAGE_KEY) : null);
    setThemeState(stored);
    applyTheme(stored);

    supabase.auth.getUser().then(async ({ data }) => {
      if (!data.user) return;
      const { data: row } = await supabase.from("profiles").select("theme").eq("id", data.user.id).maybeSingle();
      if (row?.theme) {
        const next = coerce(row.theme as string);
        setThemeState(next);
        applyTheme(next);
        try { localStorage.setItem(STORAGE_KEY, next); } catch {}
      }
    });
  }, []);

  const setTheme = (t: ThemeId) => {
    setThemeState(t);
    applyTheme(t);
    try { localStorage.setItem(STORAGE_KEY, t); } catch {}
    supabase.auth.getUser().then(({ data }) => {
      if (data.user) supabase.from("profiles").update({ theme: t }).eq("id", data.user.id).then(() => {});
    });
  };

  return <ThemeContext.Provider value={{ theme, setTheme }}>{children}</ThemeContext.Provider>;
}
