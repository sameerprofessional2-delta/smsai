import { useEffect, useRef, useState } from "react";

/**
 * Word-granular pacing for streamed text.
 *
 * Instead of dumping every chunk the model returns (which arrives in bursty
 * blocks), this reveals the incoming text one word at a time on a fixed
 * cadence, so each word can mount and animate individually. Falls back to the
 * full text instantly when `enabled` is false.
 */
export function useSmoothWords(text: string, enabled: boolean, intervalMs = 34): string {
  const [shown, setShown] = useState(enabled ? "" : text);
  const targetRef = useRef(text);
  const cursorRef = useRef(enabled ? 0 : text.length);

  targetRef.current = text;

  useEffect(() => {
    if (!enabled) {
      cursorRef.current = text.length;
      setShown(text);
      return;
    }

    // Stream restarted (shorter target) — rewind.
    if (cursorRef.current > text.length) cursorRef.current = 0;

    const timer = setInterval(() => {
      const target = targetRef.current;
      let cursor = cursorRef.current;
      if (cursor >= target.length) return;

      const remaining = target.length - cursor;
      // Reveal more words per tick when far behind so we never lag the model.
      const wordsThisTick = remaining > 900 ? 6 : remaining > 320 ? 3 : 1;

      for (let i = 0; i < wordsThisTick && cursor < target.length; i++) {
        // Skip leading whitespace, then consume one word.
        while (cursor < target.length && /\s/.test(target[cursor])) cursor++;
        while (cursor < target.length && !/\s/.test(target[cursor])) cursor++;
      }

      cursorRef.current = cursor;
      setShown(target.slice(0, cursor));
    }, intervalMs);

    return () => clearInterval(timer);
  }, [enabled, text, intervalMs]);

  return enabled ? shown : text;
}
