import { useEffect, useState } from "react";

export type MoodId =
  | "professional"
  | "witty"
  | "enthusiastic"
  | "creative"
  | "empathetic"
  | "funny"
  | "warm"
  | "point";

export const MOODS: { id: MoodId; label: string; emoji: string; description: string; instruction: string }[] = [
  { id: "professional", label: "Professional",     emoji: "🧑‍💼", description: "Formal, precise, business-grade",
    instruction: "Adopt a professional, formal, business-grade tone. Be precise, structured, and avoid slang." },
  { id: "witty",        label: "Witty / Sarcastic", emoji: "😏", description: "Sharp, clever, lightly sarcastic",
    instruction: "Use a witty, lightly sarcastic tone with clever wordplay, while staying genuinely helpful." },
  { id: "enthusiastic", label: "Enthusiastic",     emoji: "🚀", description: "High-energy and motivating",
    instruction: "Be highly enthusiastic, upbeat and motivating. Use energetic language and the occasional exclamation." },
  { id: "creative",     label: "Creative",         emoji: "🎨", description: "Imaginative, vivid, story-driven",
    instruction: "Be imaginative, vivid and story-driven. Use metaphors, analogies, and creative framing where useful." },
  { id: "empathetic",   label: "Empathetic",       emoji: "🤝", description: "Caring, validating, gentle",
    instruction: "Be empathetic, validating and gentle. Acknowledge feelings before giving practical guidance." },
  { id: "funny",        label: "Funny",            emoji: "😄", description: "Playful and humorous",
    instruction: "Be playful and humorous with light jokes and puns where appropriate, without sacrificing correctness." },
  { id: "warm",         label: "Warm",             emoji: "☀️", description: "Friendly, conversational, kind",
    instruction: "Be warm, friendly and conversational, like a kind mentor speaking with a friend." },
  { id: "point",        label: "Point to Point",   emoji: "🎯", description: "Ultra-concise, bulleted",
    instruction: "Answer in an ultra-concise point-to-point style. Prefer bullet points and short sentences. No filler." },
];

const STORAGE_KEY = "sms_ai_mood";

export function getStoredMood(): MoodId {
  if (typeof localStorage === "undefined") return "professional";
  const v = localStorage.getItem(STORAGE_KEY) as MoodId | null;
  return MOODS.some((m) => m.id === v) ? (v as MoodId) : "professional";
}

export function useMood() {
  const [mood, setMoodState] = useState<MoodId>("professional");
  useEffect(() => { setMoodState(getStoredMood()); }, []);
  const setMood = (m: MoodId) => {
    setMoodState(m);
    try { localStorage.setItem(STORAGE_KEY, m); } catch {}
  };
  return { mood, setMood };
}
