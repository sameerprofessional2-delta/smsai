import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export type SubscriptionTier = "Free" | "Pro Mode" | "Advanced";

export type Profile = {
  id: string;
  email: string | null;
  display_name: string | null;
  is_premium: boolean;
  subscription_tier: SubscriptionTier;
  theme: string;
};

export function useProfile() {
  const qc = useQueryClient();
  const query = useQuery({
    queryKey: ["profile"],
    queryFn: async (): Promise<Profile | null> => {
      const { data: u } = await supabase.auth.getUser();
      if (!u.user) return null;
      const { data, error } = await supabase
        .from("profiles")
        .select("id, email, display_name, is_premium, subscription_tier, theme")
        .eq("id", u.user.id)
        .maybeSingle();
      if (error) throw error;
      return (data as Profile) ?? null;
    },
    staleTime: 30_000,
  });

  const isPremium = !!query.data?.is_premium;
  const tier: SubscriptionTier = (query.data?.subscription_tier as SubscriptionTier) ?? "Free";

  // Premium/subscription fields are protected by a DB trigger and can only be
  // set by admins through the server-side setUserTier function (called from a
  // verified payment webhook or the admin panel). The client cannot self-upgrade.
  async function upgrade(_tier: SubscriptionTier = "Pro Mode") {
    throw new Error(
      "Premium activation requires a verified payment. Contact support to complete your upgrade.",
    );
  }

  return { profile: query.data, isPremium, tier, isLoading: query.isLoading, upgrade, refetch: query.refetch };
}
