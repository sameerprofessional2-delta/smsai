import { useCallback, useEffect, useState } from "react";

/* ------------------------------------------------------------------ */
/* Persona / model configuration                                       */
/* ------------------------------------------------------------------ */

export type ToneId = "casual" | "professional" | "aggressive" | "supportive";

export const TONES: { id: ToneId; label: string; blurb: string; emoji: string }[] = [
  { id: "casual", label: "Casual", blurb: "Friendly, emoji-light, human texting style", emoji: "😎" },
  { id: "professional", label: "Professional", blurb: "Polished, concise, brand-safe", emoji: "🧑‍💼" },
  { id: "aggressive", label: "Aggressive Sales", blurb: "Urgency, scarcity, hard CTA", emoji: "🔥" },
  { id: "supportive", label: "Supportive", blurb: "Empathetic support & de-escalation", emoji: "🤝" },
];

export type ModelId = "gpt-4o" | "claude-3-5-sonnet" | "gemini-pro" | "sms-nano";

export const MODELS: {
  id: ModelId;
  label: string;
  vendor: string;
  cost: number; // 1-5
  speed: number; // 1-5
  quality: number; // 1-5
  note: string;
}[] = [
  { id: "gpt-4o", label: "GPT-4o", vendor: "OpenAI", cost: 4, speed: 4, quality: 5, note: "Best all-round reasoning" },
  { id: "claude-3-5-sonnet", label: "Claude 3.5 Sonnet", vendor: "Anthropic", cost: 3, speed: 4, quality: 5, note: "Great long-form tone control" },
  { id: "gemini-pro", label: "Gemini Pro", vendor: "Google", cost: 2, speed: 5, quality: 4, note: "Fast + cheap at volume" },
  { id: "sms-nano", label: "SMS Nano", vendor: "In-house", cost: 1, speed: 5, quality: 3, note: "Ultra-cheap for simple replies" },
];

export type KnowledgeFile = { id: string; name: string; size: number; addedAt: string };

export type PersonaConfig = {
  agentName: string;
  tone: ToneId;
  model: ModelId;
  instructions: string;
  creativity: number;
  autoReply: boolean;
  knowledge: KnowledgeFile[];
};

export const DEFAULT_PERSONA: PersonaConfig = {
  agentName: "Ava from Northline",
  tone: "professional",
  model: "gpt-4o",
  instructions:
    "You are an SMS agent for Northline Retail. Keep every reply under 160 characters. Always confirm order numbers before sharing status. Escalate refunds above $200 to a human.",
  creativity: 45,
  autoReply: true,
  knowledge: [
    { id: "k1", name: "returns-policy.pdf", size: 184320, addedAt: "2026-07-14" },
    { id: "k2", name: "shipping-faq.md", size: 20480, addedAt: "2026-07-22" },
  ],
};

const PERSONA_KEY = "sms_suite_persona";
const EVT = "sms-suite-persona";

export function readPersona(): PersonaConfig {
  if (typeof localStorage === "undefined") return DEFAULT_PERSONA;
  try {
    const raw = localStorage.getItem(PERSONA_KEY);
    return raw ? { ...DEFAULT_PERSONA, ...(JSON.parse(raw) as PersonaConfig) } : DEFAULT_PERSONA;
  } catch {
    return DEFAULT_PERSONA;
  }
}

export function usePersona() {
  const [persona, setPersonaState] = useState<PersonaConfig>(DEFAULT_PERSONA);

  useEffect(() => {
    setPersonaState(readPersona());
    const sync = () => setPersonaState(readPersona());
    window.addEventListener(EVT, sync);
    window.addEventListener("storage", sync);
    return () => {
      window.removeEventListener(EVT, sync);
      window.removeEventListener("storage", sync);
    };
  }, []);

  const setPersona = useCallback((next: Partial<PersonaConfig>) => {
    const merged = { ...readPersona(), ...next };
    try {
      localStorage.setItem(PERSONA_KEY, JSON.stringify(merged));
    } catch {
      /* ignore quota errors */
    }
    setPersonaState(merged);
    window.dispatchEvent(new Event(EVT));
  }, []);

  return { persona, setPersona };
}

/* ------------------------------------------------------------------ */
/* Inbox mock data                                                     */
/* ------------------------------------------------------------------ */

export type ThreadStatus = "ai" | "review" | "closed";
export type Sentiment = "positive" | "neutral" | "negative";

export type SmsMessage = {
  id: string;
  from: "customer" | "agent";
  text: string;
  at: string;
  byAI?: boolean;
  persona?: string;
  confidence?: number;
};

export type InboxThread = {
  id: string;
  name: string;
  phone: string;
  status: ThreadStatus;
  sentiment: Sentiment;
  tags: string[];
  lifetimeValue: number;
  location: string;
  joined: string;
  unread: number;
  messages: SmsMessage[];
};

export const THREADS: InboxThread[] = [
  {
    id: "t1",
    name: "Maya Chen",
    phone: "+1 (415) 555-0132",
    status: "ai",
    sentiment: "positive",
    tags: ["VIP", "Repeat buyer", "Campaign: Flash Sale"],
    lifetimeValue: 2480,
    location: "San Francisco, CA",
    joined: "2024-03-11",
    unread: 0,
    messages: [
      { id: "m1", from: "customer", text: "Hey! Did my order #48219 ship yet?", at: "09:41" },
      { id: "m2", from: "agent", text: "Hi Maya! Order #48219 shipped this morning — arriving Thu. Track: nl.co/t/48219", at: "09:41", byAI: true, persona: "Professional Persona", confidence: 96 },
      { id: "m3", from: "customer", text: "Perfect, thank you 🙌", at: "09:43" },
      { id: "m4", from: "agent", text: "Anytime! Your VIP code VIP15 is still good for 15% off this week.", at: "09:43", byAI: true, persona: "Professional Persona", confidence: 92 },
    ],
  },
  {
    id: "t2",
    name: "Devon Parker",
    phone: "+1 (312) 555-0188",
    status: "review",
    sentiment: "negative",
    tags: ["Refund request", "> $200", "Escalated"],
    lifetimeValue: 890,
    location: "Chicago, IL",
    joined: "2025-01-05",
    unread: 2,
    messages: [
      { id: "m1", from: "customer", text: "This is the second time the wrong size arrived. I want a full refund.", at: "11:02" },
      { id: "m2", from: "agent", text: "I'm really sorry, Devon. I've logged the issue — a specialist will confirm your refund shortly.", at: "11:02", byAI: true, persona: "Supportive Persona", confidence: 61 },
      { id: "m3", from: "customer", text: "How long is shortly? I need this resolved today.", at: "11:15" },
    ],
  },
  {
    id: "t3",
    name: "Priya Raman",
    phone: "+44 7700 900412",
    status: "ai",
    sentiment: "neutral",
    tags: ["New lead", "Campaign: Spring Drop"],
    lifetimeValue: 0,
    location: "London, UK",
    joined: "2026-07-30",
    unread: 1,
    messages: [
      { id: "m1", from: "customer", text: "Do you ship to the UK?", at: "14:20" },
      { id: "m2", from: "agent", text: "We do! UK delivery is 4–6 days, free over £75. Want me to send the Spring Drop link?", at: "14:20", byAI: true, persona: "Professional Persona", confidence: 89 },
      { id: "m3", from: "customer", text: "Yes please", at: "14:26" },
    ],
  },
  {
    id: "t4",
    name: "Luis Ortega",
    phone: "+1 (786) 555-0110",
    status: "closed",
    sentiment: "positive",
    tags: ["Resolved", "NPS 9"],
    lifetimeValue: 1310,
    location: "Miami, FL",
    joined: "2023-11-19",
    unread: 0,
    messages: [
      { id: "m1", from: "customer", text: "Got the replacement, all good now.", at: "Yesterday" },
      { id: "m2", from: "agent", text: "Love to hear it, Luis! Closing this out — text us anytime.", at: "Yesterday", byAI: true, persona: "Casual Persona", confidence: 94 },
    ],
  },
  {
    id: "t5",
    name: "Sarah Whitfield",
    phone: "+1 (206) 555-0147",
    status: "review",
    sentiment: "neutral",
    tags: ["Wholesale", "Needs pricing"],
    lifetimeValue: 5600,
    location: "Seattle, WA",
    joined: "2022-06-02",
    unread: 1,
    messages: [
      { id: "m1", from: "customer", text: "Can we get bulk pricing for 400 units?", at: "16:05" },
      { id: "m2", from: "agent", text: "That's above my authority — routing you to our wholesale team now.", at: "16:05", byAI: true, persona: "Professional Persona", confidence: 48 },
    ],
  },
];

export const STATUS_META: Record<ThreadStatus, { label: string; className: string }> = {
  ai: { label: "AI Responded", className: "bg-primary/15 text-primary border-primary/40" },
  review: { label: "Needs Human Review", className: "bg-amber-500/15 text-amber-400 border-amber-500/40" },
  closed: { label: "Closed", className: "bg-muted text-muted-foreground border-border" },
};

/* ------------------------------------------------------------------ */
/* Analytics mock data                                                 */
/* ------------------------------------------------------------------ */

export const VOLUME_DATA = [
  { day: "Mon", total: 1240, ai: 1090 },
  { day: "Tue", total: 1480, ai: 1310 },
  { day: "Wed", total: 1320, ai: 1180 },
  { day: "Thu", total: 1710, ai: 1520 },
  { day: "Fri", total: 2050, ai: 1840 },
  { day: "Sat", total: 1180, ai: 1040 },
  { day: "Sun", total: 940, ai: 830 },
];

export const CONVERSION_DATA = [
  { week: "W1", clicks: 18.2, conversions: 4.1 },
  { week: "W2", clicks: 21.6, conversions: 5.3 },
  { week: "W3", clicks: 24.9, conversions: 6.2 },
  { week: "W4", clicks: 29.4, conversions: 8.1 },
  { week: "W5", clicks: 31.8, conversions: 9.4 },
  { week: "W6", clicks: 34.2, conversions: 10.7 },
];

export const SENTIMENT_DATA = [
  { day: "Mon", positive: 62, neutral: 28, negative: 10 },
  { day: "Tue", positive: 65, neutral: 26, negative: 9 },
  { day: "Wed", positive: 61, neutral: 29, negative: 10 },
  { day: "Thu", positive: 68, neutral: 24, negative: 8 },
  { day: "Fri", positive: 72, neutral: 21, negative: 7 },
  { day: "Sat", positive: 70, neutral: 23, negative: 7 },
  { day: "Sun", positive: 74, neutral: 20, negative: 6 },
];

/* ------------------------------------------------------------------ */
/* Campaigns                                                           */
/* ------------------------------------------------------------------ */

export type Campaign = {
  id: string;
  name: string;
  audience: string;
  size: number;
  status: "Scheduled" | "Sending" | "Completed" | "Draft";
  sendAt: string;
  ctr: number;
};

export const CAMPAIGNS: Campaign[] = [
  { id: "c1", name: "Flash Sale — Sneakers", audience: "VIP + Repeat buyers", size: 8420, status: "Scheduled", sendAt: "Aug 11, 10:00", ctr: 31.4 },
  { id: "c2", name: "Cart Recovery Drip", audience: "Abandoned carts 48h", size: 2160, status: "Sending", sendAt: "Continuous", ctr: 22.8 },
  { id: "c3", name: "Spring Drop Launch", audience: "All subscribers", size: 19340, status: "Completed", sendAt: "Aug 2, 09:00", ctr: 27.1 },
  { id: "c4", name: "Winback 90-day", audience: "Lapsed customers", size: 5120, status: "Draft", sendAt: "—", ctr: 0 },
];

export function generateCopy(goal: string, tone: ToneId, agentName: string): string[] {
  const g = goal.trim() || "our latest offer";
  const brand = agentName.split(" ")[0] || "Team";
  const packs: Record<ToneId, string[]> = {
    casual: [
      `Hey! ${g} is live 👟 Grab yours before it's gone: nl.co/shop — ${brand}`,
      `Psst… ${g}. We saved you a spot: nl.co/shop. Reply STOP to opt out.`,
      `${g} just dropped and it's moving fast. Take a look: nl.co/shop`,
    ],
    professional: [
      `${brand} here: ${g} is now available. Shop the selection: nl.co/shop. Reply STOP to unsubscribe.`,
      `Your early access to ${g} is open until Sunday. Details: nl.co/shop`,
      `A quick note — ${g} begins today. Browse the full range at nl.co/shop`,
    ],
    aggressive: [
      `⏰ 6 HOURS LEFT: ${g}. Up to 50% off — once it's gone, it's gone: nl.co/shop`,
      `FINAL CALL on ${g}. Stock is nearly out. Claim yours now → nl.co/shop`,
      `You're about to miss ${g}. Last chance pricing ends tonight: nl.co/shop`,
    ],
    supportive: [
      `Hi! We thought you'd like to know about ${g}. No rush — here if you need us: nl.co/shop`,
      `${brand} here. ${g} is on, and we're happy to help you pick: nl.co/shop`,
      `Just a heads-up about ${g}. Questions? Reply and a human will answer.`,
    ],
  };
  return packs[tone];
}

/* ------------------------------------------------------------------ */
/* Simulator reply engine                                              */
/* ------------------------------------------------------------------ */

export function simulateReply(input: string, persona: PersonaConfig): { text: string; confidence: number } {
  const t = input.toLowerCase();
  const name = persona.agentName.split(" ")[0] || "Ava";
  let core: string;
  let confidence = 88 + Math.floor(Math.random() * 10);

  if (/refund|return|broken|wrong/.test(t)) {
    core = "I can start a return right away — can you share your order number?";
    confidence = 74;
  } else if (/ship|deliver|track|where/.test(t)) {
    core = "Standard delivery is 2–4 days and tracking is texted the moment it leaves us.";
  } else if (/price|cost|discount|sale|deal/.test(t)) {
    core = "This week's offer is 15% off with code VIP15 — it stacks on sale items.";
  } else if (/hour|open|store|location/.test(t)) {
    core = "We're open 9am–8pm daily, and the online store never closes.";
  } else if (/hi|hey|hello/.test(t)) {
    core = "Hey! How can I help today?";
  } else {
    core = "Got it — let me pull that up for you. Anything specific you'd like me to check?";
    confidence = 81;
  }

  const dressed: Record<ToneId, string> = {
    casual: `${core} 😊`,
    professional: `${name} here. ${core}`,
    aggressive: `${core} Move fast — this ends tonight! nl.co/shop`,
    supportive: `Thanks for reaching out. ${core} I'm here the whole way.`,
  };

  return { text: dressed[persona.tone].slice(0, 160), confidence };
}
