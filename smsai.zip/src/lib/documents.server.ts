import { generateText } from "ai";
import { createLovableAiGatewayProvider } from "@/lib/ai-gateway.server";

const MODEL = "google/gemini-3.7-flash";
const CHUNK_CHARS = 12_000;
const CHUNK_OVERLAP = 400;
const MAX_CHUNKS = 12;

export type DocumentAnalysis = {
  name: string;
  chars: number;
  words: number;
  chunks: number;
  chunkSummaries: string[];
  summary: string;
  truncated: boolean;
};

/** Split on paragraph-ish boundaries so chunks stay semantically coherent. */
export function chunkText(text: string, size = CHUNK_CHARS, overlap = CHUNK_OVERLAP): string[] {
  const chunks: string[] = [];
  let cursor = 0;
  while (cursor < text.length) {
    let end = Math.min(text.length, cursor + size);
    if (end < text.length) {
      const window = text.slice(cursor, end);
      const breakAt = Math.max(window.lastIndexOf("\n\n"), window.lastIndexOf("\n"), window.lastIndexOf(". "));
      if (breakAt > size * 0.5) end = cursor + breakAt + 1;
    }
    chunks.push(text.slice(cursor, end).trim());
    if (end >= text.length) break;
    cursor = Math.max(end - overlap, cursor + 1);
  }
  return chunks.filter(Boolean);
}

export async function analyzeDocumentText(
  lovableApiKey: string,
  name: string,
  mimeType: string,
  text: string,
): Promise<DocumentAnalysis> {
  const gateway = createLovableAiGatewayProvider(lovableApiKey);
  const model = gateway(MODEL);

  const all = chunkText(text);
  const truncated = all.length > MAX_CHUNKS;
  const chunks = all.slice(0, MAX_CHUNKS);

  // MAP pass — summarize every chunk in parallel.
  const chunkSummaries = await Promise.all(
    chunks.map(async (chunk, i) => {
      const { text: out } = await generateText({
        model,
        system:
          "You extract signal from document chunks. Reply with 3-6 terse bullet points capturing facts, figures, entities and decisions. No preamble.",
        prompt: `Document: ${name} (${mimeType})\nChunk ${i + 1} of ${chunks.length}:\n"""\n${chunk}\n"""`,
      });
      return out.trim();
    }),
  );

  // REDUCE pass — one coherent analysis over all chunk summaries.
  const { text: summary } = await generateText({
    model,
    system:
      "You are a document analyst. Produce clean Markdown with '## Summary', '## Key points', '## Entities & figures' and '## Suggested next steps'. Be concrete and never invent facts.",
    prompt:
      `Document: ${name} (${mimeType})\n` +
      `${chunks.length} analyzed chunk${chunks.length === 1 ? "" : "s"}` +
      `${truncated ? ` (of ${all.length} total — later chunks omitted)` : ""}.\n\n` +
      chunkSummaries.map((s, i) => `### Chunk ${i + 1}\n${s}`).join("\n\n"),
  });

  return {
    name,
    chars: text.length,
    words: text.trim() ? text.trim().split(/\s+/).length : 0,
    chunks: chunks.length,
    chunkSummaries,
    summary: summary.trim(),
    truncated,
  };
}
