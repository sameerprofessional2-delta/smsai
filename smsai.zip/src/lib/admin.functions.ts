import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export type AdminUserRow = {
  id: string;
  email: string;
  registered: string;
  lastSignIn: string | null;
  provider: string;
  tier: "Free" | "Pro Mode" | "Advanced";
  isPremium: boolean;
  suspended: boolean;
  status: "active" | "blocked";
  role: "admin" | "user";
};

async function isAdminUser(userId: string): Promise<boolean> {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data, error } = await supabaseAdmin
    .from("user_roles")
    .select("role")
    .eq("user_id", userId)
    .eq("role", "admin")
    .maybeSingle();
  return !error && !!data;
}

async function assertAdmin(userId: string) {
  if (!(await isAdminUser(userId))) throw new Error("Forbidden");
}

export const checkAdminAccess = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }): Promise<{ isAdmin: boolean }> => {
    return { isAdmin: await isAdminUser(context.claims.sub as string) };
  });

export const listRealUsers = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }): Promise<AdminUserRow[]> => {
    await assertAdmin(context.claims.sub as string);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const adminEmailEnv = (process.env.ADMIN_EMAIL ?? "").toLowerCase();

    const rows: AdminUserRow[] = [];
    let page = 1;
    const perPage = 200;
    for (let i = 0; i < 10; i++) {
      const { data, error } = await supabaseAdmin.auth.admin.listUsers({ page, perPage });
      if (error) throw error;
      const users = data?.users ?? [];
      for (const u of users) {
        rows.push({
          id: u.id,
          email: u.email ?? "(no email)",
          registered: u.created_at ?? "",
          lastSignIn: u.last_sign_in_at ?? null,
          provider: (u.app_metadata?.provider as string) ?? "email",
          tier: "Free",
          isPremium: false,
          suspended: Boolean((u as { banned_until?: string }).banned_until),
          status: "active",
          role: "user",
        });
      }
      if (users.length < perPage) break;
      page++;
    }

    const ids = rows.map((r) => r.id);

    const { data: profiles } = await supabaseAdmin
      .from("profiles")
      .select("id, subscription_tier, is_premium, status")
      .in("id", ids);
    const pmap = new Map((profiles ?? []).map((p) => [p.id, p]));
    for (const r of rows) {
      const p = pmap.get(r.id);
      if (p) {
        const t = (p.subscription_tier ?? "Free") as AdminUserRow["tier"];
        r.tier = ["Free", "Pro Mode", "Advanced"].includes(t) ? t : "Free";
        r.isPremium = !!p.is_premium;
        r.status = (p.status as "active" | "blocked") ?? "active";
      }
    }

    const { data: roles } = await supabaseAdmin
      .from("user_roles")
      .select("user_id, role")
      .in("user_id", ids);
    const rmap = new Map<string, "admin" | "user">();
    for (const r of roles ?? []) {
      if (r.role === "admin") rmap.set(r.user_id, "admin");
    }
    for (const r of rows) {
      if (rmap.get(r.id) === "admin" || (adminEmailEnv && r.email.toLowerCase() === adminEmailEnv)) {
        r.role = "admin";
      }
    }

    rows.sort((a, b) => (b.lastSignIn ?? "").localeCompare(a.lastSignIn ?? ""));
    return rows;
  });

export const setUserTier = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: { userId: string; tier: "Free" | "Pro Mode" | "Advanced" }) => {
    if (!data?.userId || !["Free", "Pro Mode", "Advanced"].includes(data?.tier)) {
      throw new Error("Invalid input");
    }
    return data;
  })
  .handler(async ({ data, context }): Promise<{ ok: true }> => {
    await assertAdmin(context.claims.sub as string);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin
      .from("profiles")
      .update({ subscription_tier: data.tier, is_premium: data.tier !== "Free" })
      .eq("id", data.userId);
    if (error) throw error;
    return { ok: true };
  });

export const setUserSuspended = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: { userId: string; suspended: boolean }) => {
    if (!data?.userId || typeof data?.suspended !== "boolean") {
      throw new Error("Invalid input");
    }
    return data;
  })
  .handler(async ({ data, context }): Promise<{ ok: true }> => {
    await assertAdmin(context.claims.sub as string);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const adminEmailEnv = (process.env.ADMIN_EMAIL ?? "").toLowerCase();

    const { data: target, error: getErr } = await supabaseAdmin.auth.admin.getUserById(data.userId);
    if (getErr) throw getErr;
    const targetEmail = (target.user?.email ?? "").toLowerCase();
    const targetIsAdmin = await isAdminUser(data.userId);
    if (targetIsAdmin || (adminEmailEnv && targetEmail === adminEmailEnv)) {
      throw new Error("Admin accounts cannot be blocked.");
    }

    const { error: banErr } = await supabaseAdmin.auth.admin.updateUserById(data.userId, {
      ban_duration: data.suspended ? "876000h" : "none",
    });
    if (banErr) throw banErr;

    const { error: profErr } = await supabaseAdmin
      .from("profiles")
      .update({ status: data.suspended ? "blocked" : "active" })
      .eq("id", data.userId);
    if (profErr) throw profErr;

    if (data.suspended) {
      await supabaseAdmin.auth.admin.signOut(data.userId, "global").catch(() => {});
    }
    return { ok: true };
  });

