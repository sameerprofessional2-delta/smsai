import type { ToneId } from "./sms-suite";

/* ------------------------------------------------------------------ */
/* Multi-agent personas                                                */
/* ------------------------------------------------------------------ */

export type AgentId = "support" | "sales" | "retention" | "onboarding";

export type AgentPersona = {
  id: AgentId;
  name: string;
  role: string;
  emoji: string;
  defaultTone: ToneId;
  objective: string;
  sample: string;
  handoff: string;
};

export const AGENTS: AgentPersona[] = [
  {
    id: "support",
    name: "Ava",
    role: "Support Agent",
    emoji: "🎧",
    defaultTone: "supportive",
    objective: "Resolve order, shipping and returns questions in one reply.",
    sample: "Hi {first_name}! Order {order_id} is out for delivery today — track it here: nl.co/t/{order_id}",
    handoff: "Escalates refunds above $200 to a human.",
  },
  {
    id: "sales",
    name: "Rex",
    role: "Sales Closer",
    emoji: "🔥",
    defaultTone: "aggressive",
    objective: "Convert warm leads with urgency and a single clear CTA.",
    sample: "{first_name}, your cart is still warm 🔥 {dynamic_coupon} takes 15% off — expires tonight: nl.co/shop",
    handoff: "Hands off to Support when the reply is a complaint.",
  },
  {
    id: "retention",
    name: "Nova",
    role: "Retention Expert",
    emoji: "💎",
    defaultTone: "professional",
    objective: "Win back lapsed customers and reduce churn with tailored offers.",
    sample: "We miss you, {first_name}. Since your {last_purchase}, we've added 40 new styles — here's {dynamic_coupon}.",
    handoff: "Routes wholesale interest to the sales team.",
  },
  {
    id: "onboarding",
    name: "Milo",
    role: "Onboarding Guide",
    emoji: "🚀",
    defaultTone: "casual",
    objective: "Activate new subscribers within their first 48 hours.",
    sample: "Welcome aboard {first_name}! Reply MENU any time. First order? {dynamic_coupon} is on us 🎁",
    handoff: "Escalates anything account-related to Support.",
  },
];

/* ------------------------------------------------------------------ */
/* Tone & style matrix                                                 */
/* ------------------------------------------------------------------ */

export type StyleId = "concise" | "storytelling" | "emoji" | "formal";

export const STYLES: { id: StyleId; label: string; blurb: string }[] = [
  { id: "concise", label: "Concise", blurb: "One sentence, one CTA" },
  { id: "storytelling", label: "Storytelling", blurb: "Micro-narrative hook" },
  { id: "emoji", label: "Emoji-rich", blurb: "Playful, visual, scannable" },
  { id: "formal", label: "Formal", blurb: "No contractions, brand-safe" },
];

export function previewMessage(agent: AgentPersona, tone: ToneId, style: StyleId): string {
  const base = agent.sample;
  const toned: Record<ToneId, string> = {
    casual: base,
    professional: `${agent.name} from Northline here. ${base}`,
    aggressive: `${base} Last chance — ends tonight.`,
    supportive: `Happy to help! ${base} I'm here if you need anything else.`,
  };
  const styled: Record<StyleId, string> = {
    concise: toned[tone].split(" — ")[0] ?? toned[tone],
    storytelling: `Quick story: 400 people grabbed this today. ${toned[tone]}`,
    emoji: `✨ ${toned[tone]} 🚀`,
    formal: toned[tone].replace(/!/g, ".").replace(/'/g, "'"),
  };
  return styled[style];
}

/* ------------------------------------------------------------------ */
/* Dynamic variable parsing engine                                     */
/* ------------------------------------------------------------------ */

export type VariableContext = Record<string, string>;

export const VARIABLES: { token: string; label: string; example: string }[] = [
  { token: "{first_name}", label: "First name", example: "Maya" },
  { token: "{last_name}", label: "Last name", example: "Chen" },
  { token: "{city}", label: "City", example: "San Francisco" },
  { token: "{last_purchase}", label: "Last purchase", example: "Trail Runner 2" },
  { token: "{order_id}", label: "Order ID", example: "48219" },
  { token: "{dynamic_coupon}", label: "Dynamic coupon", example: "VIP15" },
  { token: "{ltv}", label: "Lifetime value", example: "$2,480" },
];

export const SAMPLE_CONTEXT: VariableContext = Object.fromEntries(
  VARIABLES.map((v) => [v.token.slice(1, -1), v.example]),
);

export function renderTemplate(template: string, ctx: VariableContext = SAMPLE_CONTEXT) {
  const missing: string[] = [];
  const text = template.replace(/\{([a-z0-9_]+)\}/gi, (full, key: string) => {
    const value = ctx[key];
    if (value == null) {
      missing.push(full);
      return full;
    }
    return value;
  });
  return { text, missing };
}

/* ------------------------------------------------------------------ */
/* Compliance guardrails                                               */
/* ------------------------------------------------------------------ */

export type ComplianceIssue = { id: string; level: "error" | "warning" | "pass"; message: string };

const BANNED = ["guaranteed", "risk free", "free money", "act now or else", "100% free"];

export function checkCompliance(message: string): ComplianceIssue[] {
  const rendered = renderTemplate(message).text;
  const issues: ComplianceIssue[] = [];

  issues.push(
    /stop\b/i.test(rendered)
      ? { id: "optout", level: "pass", message: "STOP opt-out instruction present" }
      : { id: "optout", level: "error", message: "Missing STOP opt-out instruction (TCPA requirement)" },
  );

  const len = rendered.length;
  issues.push(
    len <= 160
      ? { id: "length", level: "pass", message: `${len}/160 characters — single SMS segment` }
      : {
          id: "length",
          level: len <= 320 ? "warning" : "error",
          message: `${len} characters — sends as ${Math.ceil(len / 153)} segments`,
        },
  );

  const brandOk = /northline|nl\.co/i.test(rendered);
  issues.push(
    brandOk
      ? { id: "brand", level: "pass", message: "Sender brand identified" }
      : { id: "brand", level: "warning", message: "No brand identifier — add your business name" },
  );

  const banned = BANNED.filter((b) => rendered.toLowerCase().includes(b));
  issues.push(
    banned.length === 0
      ? { id: "banned", level: "pass", message: "No high-risk carrier-filtered phrases" }
      : { id: "banned", level: "error", message: `High-risk phrases: ${banned.join(", ")}` },
  );

  const unicode = /[^\u0000-\u00FF]/.test(rendered);
  issues.push(
    unicode
      ? { id: "encoding", level: "warning", message: "Unicode/emoji detected — reduces segment size to 70 chars" }
      : { id: "encoding", level: "pass", message: "GSM-7 safe encoding" },
  );

  return issues;
}

export function complianceScore(issues: ComplianceIssue[]) {
  const weight = issues.reduce((acc, i) => acc + (i.level === "pass" ? 1 : i.level === "warning" ? 0.5 : 0), 0);
  return Math.round((weight / Math.max(issues.length, 1)) * 100);
}

/* ------------------------------------------------------------------ */
/* A/B testing                                                         */
/* ------------------------------------------------------------------ */

export type AbVariant = {
  id: string;
  label: string;
  copy: string;
  sent: number;
  delivered: number;
  replies: number;
  clicks: number;
  conversions: number;
  optOuts: number;
};

export type AbTest = {
  id: string;
  name: string;
  agent: AgentId;
  status: "Running" | "Completed";
  variants: AbVariant[];
};

export const AB_TESTS: AbTest[] = [
  {
    id: "ab1",
    name: "Flash Sale subject hook",
    agent: "sales",
    status: "Running",
    variants: [
      { id: "A", label: "Urgency", copy: "⏰ 6 HOURS LEFT on the flash sale, {first_name}. nl.co/shop Reply STOP to opt out.", sent: 4200, delivered: 4118, replies: 512, clicks: 1284, conversions: 318, optOuts: 21 },
      { id: "B", label: "Value", copy: "{first_name}, 30% off your {last_purchase} favourites today. nl.co/shop Reply STOP to opt out.", sent: 4200, delivered: 4140, replies: 604, clicks: 1478, conversions: 402, optOuts: 12 },
    ],
  },
  {
    id: "ab2",
    name: "Cart recovery tone test",
    agent: "retention",
    status: "Completed",
    variants: [
      { id: "A", label: "Supportive", copy: "Need help deciding, {first_name}? Your cart is saved: nl.co/cart Reply STOP to opt out.", sent: 1080, delivered: 1064, replies: 191, clicks: 348, conversions: 96, optOuts: 3 },
      { id: "B", label: "Coupon", copy: "{dynamic_coupon} unlocks 10% off your cart, {first_name}: nl.co/cart Reply STOP to opt out.", sent: 1080, delivered: 1071, replies: 173, clicks: 402, conversions: 134, optOuts: 7 },
    ],
  },
];

export function variantStats(v: AbVariant) {
  const pct = (n: number, d: number) => (d ? (n / d) * 100 : 0);
  return {
    deliveryRate: pct(v.delivered, v.sent),
    replyRate: pct(v.replies, v.delivered),
    clickRate: pct(v.clicks, v.delivered),
    conversionRate: pct(v.conversions, v.delivered),
    optOutRate: pct(v.optOuts, v.delivered),
    revenue: v.conversions * 62,
    roi: (v.conversions * 62) / Math.max(v.sent * 0.0075, 0.01),
  };
}

export function pickWinner(test: AbTest) {
  return [...test.variants].sort(
    (a, b) => variantStats(b).conversionRate - variantStats(a).conversionRate,
  )[0]!;
}

/* ------------------------------------------------------------------ */
/* Contacts & segmentation                                             */
/* ------------------------------------------------------------------ */

export type Contact = {
  id: string;
  firstName: string;
  lastName: string;
  phone: string;
  city: string;
  timezone: string;
  tags: string[];
  sentiment: "positive" | "neutral" | "negative";
  lastPurchase: string;
  ltv: number;
  lastReplyDays: number;
  subscribed: boolean;
};

export const CONTACTS: Contact[] = [
  { id: "u1", firstName: "Maya", lastName: "Chen", phone: "+1 415 555 0132", city: "San Francisco", timezone: "America/Los_Angeles", tags: ["VIP", "Repeat"], sentiment: "positive", lastPurchase: "Trail Runner 2", ltv: 2480, lastReplyDays: 1, subscribed: true },
  { id: "u2", firstName: "Devon", lastName: "Parker", phone: "+1 312 555 0188", city: "Chicago", timezone: "America/Chicago", tags: ["Refund"], sentiment: "negative", lastPurchase: "Cloud Tee", ltv: 890, lastReplyDays: 0, subscribed: true },
  { id: "u3", firstName: "Priya", lastName: "Raman", phone: "+44 7700 900412", city: "London", timezone: "Europe/London", tags: ["Lead", "Spring Drop"], sentiment: "neutral", lastPurchase: "—", ltv: 0, lastReplyDays: 4, subscribed: true },
  { id: "u4", firstName: "Luis", lastName: "Ortega", phone: "+1 786 555 0110", city: "Miami", timezone: "America/New_York", tags: ["Resolved", "NPS9"], sentiment: "positive", lastPurchase: "Flex Hoodie", ltv: 1310, lastReplyDays: 9, subscribed: true },
  { id: "u5", firstName: "Sarah", lastName: "Whitfield", phone: "+1 206 555 0147", city: "Seattle", timezone: "America/Los_Angeles", tags: ["Wholesale"], sentiment: "neutral", lastPurchase: "Bulk order #221", ltv: 5600, lastReplyDays: 6, subscribed: true },
  { id: "u6", firstName: "Ahmed", lastName: "Karim", phone: "+971 50 555 8890", city: "Dubai", timezone: "Asia/Dubai", tags: ["VIP"], sentiment: "positive", lastPurchase: "Aero Jacket", ltv: 3120, lastReplyDays: 12, subscribed: true },
  { id: "u7", firstName: "Ella", lastName: "Nowak", phone: "+48 512 555 331", city: "Warsaw", timezone: "Europe/Warsaw", tags: ["Lapsed"], sentiment: "neutral", lastPurchase: "Runner Socks", ltv: 210, lastReplyDays: 41, subscribed: false },
  { id: "u8", firstName: "Tom", lastName: "Baker", phone: "+61 412 555 220", city: "Sydney", timezone: "Australia/Sydney", tags: ["Repeat"], sentiment: "positive", lastPurchase: "Trail Runner 2", ltv: 1740, lastReplyDays: 3, subscribed: true },
];

export type SegmentRule = {
  id: string;
  field: "sentiment" | "tag" | "lastReplyDays" | "ltv" | "subscribed";
  operator: "is" | "isNot" | "gt" | "lt";
  value: string;
};

export function matchesRule(c: Contact, r: SegmentRule): boolean {
  switch (r.field) {
    case "sentiment":
      return r.operator === "isNot" ? c.sentiment !== r.value : c.sentiment === r.value;
    case "tag": {
      const has = c.tags.some((t) => t.toLowerCase() === r.value.toLowerCase());
      return r.operator === "isNot" ? !has : has;
    }
    case "lastReplyDays":
      return r.operator === "lt" ? c.lastReplyDays < Number(r.value) : c.lastReplyDays > Number(r.value);
    case "ltv":
      return r.operator === "lt" ? c.ltv < Number(r.value) : c.ltv > Number(r.value);
    case "subscribed":
      return String(c.subscribed) === r.value;
    default:
      return true;
  }
}

export function applySegment(contacts: Contact[], rules: SegmentRule[], mode: "AND" | "OR") {
  if (rules.length === 0) return contacts;
  return contacts.filter((c) =>
    mode === "AND" ? rules.every((r) => matchesRule(c, r)) : rules.some((r) => matchesRule(c, r)),
  );
}

export function contactsToCsv(contacts: Contact[]) {
  const header = "first_name,last_name,phone,city,timezone,tags,sentiment,last_purchase,ltv,subscribed";
  const rows = contacts.map((c) =>
    [c.firstName, c.lastName, c.phone, c.city, c.timezone, c.tags.join("|"), c.sentiment, c.lastPurchase, c.ltv, c.subscribed]
      .map((v) => `"${String(v).replace(/"/g, '""')}"`)
      .join(","),
  );
  return [header, ...rows].join("\n");
}

/* ------------------------------------------------------------------ */
/* Scheduling queue                                                    */
/* ------------------------------------------------------------------ */

export type QueueStatus = "Queued" | "Paused" | "Sending" | "Cancelled" | "Sent";

export type QueuedSend = {
  id: string;
  campaign: string;
  agent: AgentId;
  audience: string;
  recipients: number;
  date: string; // yyyy-mm-dd
  time: string; // HH:mm
  timezone: string;
  recurrence: "None" | "Daily" | "Weekly" | "Monthly";
  status: QueueStatus;
};

export const TIMEZONES = [
  "America/Los_Angeles",
  "America/New_York",
  "Europe/London",
  "Europe/Warsaw",
  "Asia/Dubai",
  "Asia/Karachi",
  "Australia/Sydney",
];

export const INITIAL_QUEUE: QueuedSend[] = [
  { id: "q1", campaign: "Flash Sale — Sneakers", agent: "sales", audience: "VIP + Repeat", recipients: 8420, date: "2026-08-24", time: "10:00", timezone: "America/Los_Angeles", recurrence: "None", status: "Queued" },
  { id: "q2", campaign: "Cart Recovery Drip", agent: "retention", audience: "Abandoned carts", recipients: 2160, date: "2026-08-22", time: "18:30", timezone: "America/New_York", recurrence: "Daily", status: "Sending" },
  { id: "q3", campaign: "Spring Drop Reminder", agent: "onboarding", audience: "New subscribers", recipients: 4310, date: "2026-08-27", time: "09:00", timezone: "Europe/London", recurrence: "Weekly", status: "Paused" },
  { id: "q4", campaign: "Winback 90-day", agent: "retention", audience: "Lapsed customers", recipients: 5120, date: "2026-09-01", time: "11:15", timezone: "Asia/Dubai", recurrence: "Monthly", status: "Queued" },
];

/** Local hour in the recipient timezone for a given send time. */
export function localHourIn(timezone: string, date: string, time: string): number | null {
  try {
    const iso = new Date(`${date}T${time}:00Z`);
    const hour = new Intl.DateTimeFormat("en-GB", { hour: "2-digit", hour12: false, timeZone: timezone }).format(iso);
    return Number(hour);
  } catch {
    return null;
  }
}

export function isQuietHours(hour: number | null) {
  if (hour == null) return false;
  return hour < 8 || hour >= 21;
}

/* ------------------------------------------------------------------ */
/* Analytics data with filters                                         */
/* ------------------------------------------------------------------ */

export type RangeId = "7d" | "30d" | "90d";

export const RANGES: { id: RangeId; label: string; points: number }[] = [
  { id: "7d", label: "Last 7 days", points: 7 },
  { id: "30d", label: "Last 30 days", points: 15 },
  { id: "90d", label: "Last 90 days", points: 12 },
];

function seeded(i: number, seed: number) {
  const x = Math.sin(i * 12.9898 + seed * 78.233) * 43758.5453;
  return x - Math.floor(x);
}

export type PerfPoint = {
  label: string;
  delivery: number;
  response: number;
  conversion: number;
  optOut: number;
  roi: number;
  positive: number;
  neutral: number;
  negative: number;
};

export function buildPerformance(range: RangeId, agent: AgentId | "all", campaign: string): PerfPoint[] {
  const meta = RANGES.find((r) => r.id === range)!;
  const seed =
    (agent === "all" ? 1 : AGENTS.findIndex((a) => a.id === agent) + 2) * (campaign === "all" ? 1 : campaign.length);
  return Array.from({ length: meta.points }).map((_, i) => {
    const r = seeded(i, seed);
    const r2 = seeded(i + 50, seed);
    const positive = 52 + Math.round(r * 26);
    const negative = 4 + Math.round(r2 * 9);
    return {
      label: range === "7d" ? ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"][i]! : range === "30d" ? `D${i * 2 + 1}` : `W${i + 1}`,
      delivery: Number((95.5 + r * 4).toFixed(1)),
      response: Number((18 + r * 16).toFixed(1)),
      conversion: Number((5 + r2 * 9).toFixed(1)),
      optOut: Number((0.2 + r2 * 1.1).toFixed(2)),
      roi: Number((3.2 + r * 4.6).toFixed(2)),
      positive,
      neutral: 100 - positive - negative,
      negative,
    };
  });
}

export function averageOf(points: PerfPoint[], key: keyof PerfPoint) {
  const nums = points.map((p) => Number(p[key]));
  return nums.reduce((a, b) => a + b, 0) / Math.max(nums.length, 1);
}
