import { createClient } from "@supabase/supabase-js";
import type { Database } from "@/integrations/supabase/types";

export class AuthError extends Error {
  constructor(
    public readonly status: number,
    message: string,
  ) {
    super(message);
    this.name = "AuthError";
  }
}

/**
 * Authenticate a request for a TanStack server route handler.
 * Returns a Supabase client scoped to the caller's bearer token and the
 * decoded user id. Throws AuthError (mapped to a Response) on failure.
 */
export async function getAuthenticatedUser(request: Request) {
  const SUPABASE_URL = process.env.SUPABASE_URL;
  const SUPABASE_PUBLISHABLE_KEY = process.env.SUPABASE_PUBLISHABLE_KEY;

  if (!SUPABASE_URL || !SUPABASE_PUBLISHABLE_KEY) {
    throw new AuthError(500, "Supabase is not configured");
  }

  const authHeader = request.headers.get("authorization") ?? "";
  if (!authHeader.startsWith("Bearer ")) {
    throw new AuthError(401, "Unauthorized: Bearer token required");
  }

  const token = authHeader.slice(7).trim();
  if (!token) {
    throw new AuthError(401, "Unauthorized: Empty token");
  }

  const supabase = createClient<Database>(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY, {
    global: {
      headers: { Authorization: `Bearer ${token}` },
    },
    auth: {
      persistSession: false,
      autoRefreshToken: false,
    },
  });

  const { data: userData, error: userError } = await supabase.auth.getUser(token);
  if (userError || !userData?.user) {
    throw new AuthError(401, "Unauthorized: Invalid token");
  }

  return { userId: userData.user.id, supabase };
}

export function authErrorToResponse(error: unknown): Response {
  if (error instanceof AuthError) {
    return new Response(error.message, { status: error.status });
  }
  return new Response("Internal server error", { status: 500 });
}
