import { useEffect, useState } from "react";

// Note: the admin identity is enforced server-side via the user_roles table
// and the checkAdminAccess server function. No email is hardcoded in the
// client bundle.

export type Faq = { id: string; question: string; answer: string };
export type SystemFlags = {
  registrationsOff: boolean;
  maintenanceMode: boolean;
  forceDarkMode: boolean;
};

const FAQ_KEY = "sms_ai_faqs";
const FLAGS_KEY = "sms_ai_flags";
const EVT = "sms_ai_admin_update";

const DEFAULT_FAQS: Faq[] = [
  {
    id: "1",
    question: "What is SMS AI?",
    answer:
      "SMS AI is an elite, multimodal AI workspace built on next-generation reasoning engines. In one place you get streaming chat, a code generator, document analysis with retrieval over large files, image generation, web-aware research, and a voice assistant — so you can move from an idea to a finished artifact without switching tools.",
  },
  {
    id: "2",
    question: "Is there a free plan?",
    answer:
      "Yes. The Free tier costs nothing and includes 10 chat messages per day at standard response speed, with no credit card required. Document uploads and premium image generation are reserved for Pro. When you need unlimited conversations, priority model speed, and document analysis, you can upgrade to Pro at any time — and downgrade just as easily.",
  },
  {
    id: "3",
    question: "How is my data handled?",
    answer:
      "Your conversations are encrypted in transit and stored behind row-level security policies, which means every chat, message, and uploaded file is tied to your account and readable only by you. We never sell your data or use your private conversations to train public models, and you can delete a conversation — along with its stored content — at any time.",
  },
  {
    id: "4",
    question: "Which AI models power the platform?",
    answer:
      "SMS AI routes each task to the model best suited for it: fast reasoning models for chat and code, a high-fidelity image model for visual generation, and a dedicated speech model for transcription. Model routing is handled automatically, so you always get the strongest available engine for the job.",
  },
];


const DEFAULT_FLAGS: SystemFlags = {
  registrationsOff: false,
  maintenanceMode: false,
  forceDarkMode: true,
};

function read<T>(key: string, fallback: T): T {
  if (typeof window === "undefined") return fallback;
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

function write<T>(key: string, value: T) {
  if (typeof window === "undefined") return;
  localStorage.setItem(key, JSON.stringify(value));
  window.dispatchEvent(new Event(EVT));
}

export function useFaqs(): [Faq[], (next: Faq[]) => void] {
  const [faqs, setFaqs] = useState<Faq[]>(() => read(FAQ_KEY, DEFAULT_FAQS));
  useEffect(() => {
    const sync = () => setFaqs(read(FAQ_KEY, DEFAULT_FAQS));
    window.addEventListener(EVT, sync);
    window.addEventListener("storage", sync);
    return () => {
      window.removeEventListener(EVT, sync);
      window.removeEventListener("storage", sync);
    };
  }, []);
  return [faqs, (next) => { write(FAQ_KEY, next); setFaqs(next); }];
}

export function useFlags(): [SystemFlags, (next: SystemFlags) => void] {
  const [flags, setFlags] = useState<SystemFlags>(() => read(FLAGS_KEY, DEFAULT_FLAGS));
  useEffect(() => {
    const sync = () => setFlags(read(FLAGS_KEY, DEFAULT_FLAGS));
    window.addEventListener(EVT, sync);
    window.addEventListener("storage", sync);
    return () => {
      window.removeEventListener(EVT, sync);
      window.removeEventListener("storage", sync);
    };
  }, []);
  return [flags, (next) => { write(FLAGS_KEY, next); setFlags(next); }];
}
