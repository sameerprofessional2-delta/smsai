/**
 * Streaming resilience for the chat transport.
 *
 * Two layers:
 *  1. Connect-phase retries with exponential backoff + jitter (network drops,
 *     429s and 5xx get another chance instead of surfacing as a dead stream).
 *  2. Chunk aggregation on the response body: bytes are buffered and only
 *     forwarded as *complete* SSE events, so a packet split mid-event can never
 *     reach the parser as a truncated frame. If the socket dies mid-stream we
 *     emit a synthetic terminator so the UI finalizes the partial answer
 *     instead of freezing mid-sentence.
 */

export type StreamNotice =
  | { type: "retry"; attempt: number; delayMs: number }
  | { type: "recovered"; attempt: number }
  | { type: "interrupted" };

type Options = {
  maxAttempts?: number;
  baseDelayMs?: number;
  onNotice?: (notice: StreamNotice) => void;
};

const RETRYABLE_STATUS = new Set([408, 425, 429, 500, 502, 503, 504]);

function backoffDelay(attempt: number, base: number): number {
  const exponential = base * 2 ** (attempt - 1);
  return Math.min(8000, exponential) + Math.random() * 250;
}

function sleep(ms: number, signal?: AbortSignal | null): Promise<void> {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(done, ms);
    function done() {
      clearTimeout(timer);
      signal?.removeEventListener("abort", onAbort);
      resolve();
    }
    function onAbort() {
      clearTimeout(timer);
      signal?.removeEventListener("abort", onAbort);
      reject(new DOMException("Aborted", "AbortError"));
    }
    signal?.addEventListener("abort", onAbort);
  });
}

function isAbort(error: unknown): boolean {
  return error instanceof DOMException
    ? error.name === "AbortError"
    : error instanceof Error && error.name === "AbortError";
}

/**
 * Buffers the SSE body and re-emits it as whole events. On a mid-stream
 * failure the partial tail is flushed and a `finish` + `[DONE]` pair is
 * appended so the chat UI closes the message cleanly.
 */
function aggregateEvents(
  body: ReadableStream<Uint8Array>,
  onNotice?: (notice: StreamNotice) => void,
): ReadableStream<Uint8Array> {
  const decoder = new TextDecoder();
  const encoder = new TextEncoder();
  let buffer = "";

  return new ReadableStream<Uint8Array>({
    async start(controller) {
      const reader = body.getReader();
      try {
        for (;;) {
          const { done, value } = await reader.read();
          if (done) break;
          buffer += decoder.decode(value, { stream: true });
          const boundary = buffer.lastIndexOf("\n\n");
          if (boundary === -1) continue;
          // Forward every complete event as a single aggregated chunk.
          controller.enqueue(encoder.encode(buffer.slice(0, boundary + 2)));
          buffer = buffer.slice(boundary + 2);
        }
        buffer += decoder.decode();
        if (buffer) controller.enqueue(encoder.encode(buffer));
        controller.close();
      } catch (error) {
        if (isAbort(error)) {
          controller.close();
          return;
        }
        // Network died mid-answer: flush what we have, then terminate the
        // protocol so the client keeps (and can persist) the partial text.
        if (buffer.trim()) controller.enqueue(encoder.encode(buffer.endsWith("\n\n") ? buffer : `${buffer}\n\n`));
        controller.enqueue(encoder.encode(`data: {"type":"finish"}\n\n`));
        controller.enqueue(encoder.encode("data: [DONE]\n\n"));
        onNotice?.({ type: "interrupted" });
        controller.close();
      } finally {
        reader.releaseLock();
      }
    },
    cancel(reason) {
      void body.cancel(reason);
    },
  });
}

export function withStreamingResilience(
  inner: (url: RequestInfo | URL, init?: RequestInit) => Promise<Response>,
  { maxAttempts = 4, baseDelayMs = 400, onNotice }: Options = {},
) {
  return async function resilientFetch(url: RequestInfo | URL, init?: RequestInit): Promise<Response> {
    let lastError: unknown = null;

    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      try {
        const response = await inner(url, init);

        if (!response.ok && RETRYABLE_STATUS.has(response.status) && attempt < maxAttempts) {
          const retryAfter = Number(response.headers.get("retry-after"));
          const delayMs = Number.isFinite(retryAfter) && retryAfter > 0
            ? retryAfter * 1000
            : backoffDelay(attempt, baseDelayMs);
          void response.body?.cancel();
          onNotice?.({ type: "retry", attempt, delayMs });
          await sleep(delayMs, init?.signal ?? null);
          continue;
        }

        if (attempt > 1 && response.ok) onNotice?.({ type: "recovered", attempt });
        if (!response.ok || !response.body) return response;

        return new Response(aggregateEvents(response.body, onNotice), {
          status: response.status,
          statusText: response.statusText,
          headers: response.headers,
        });
      } catch (error) {
        if (isAbort(error) || init?.signal?.aborted) throw error;
        lastError = error;
        if (attempt >= maxAttempts) break;
        const delayMs = backoffDelay(attempt, baseDelayMs);
        onNotice?.({ type: "retry", attempt, delayMs });
        await sleep(delayMs, init?.signal ?? null);
      }
    }

    throw lastError instanceof Error ? lastError : new Error("Network request failed");
  };
}
