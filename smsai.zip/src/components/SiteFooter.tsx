import { Link } from "@tanstack/react-router";
import { Logo } from "./Logo";

type Col = { title: string; links: { label: string; to?: string; href?: string }[] };

const columns: Col[] = [
  {
    title: "Product",
    links: [
      { label: "Features", href: "/#features" },
      { label: "Pricing", to: "/pricing" },
      { label: "Model Integrity", href: "/#faq" },
    ],
  },
  {
    title: "Security & Support",
    links: [
      { label: "System Status", href: "/#faq" },
      { label: "Help Center", href: "/#faq" },
      { label: "support@deltacoders.com", href: "mailto:support@deltacoders.com" },
    ],
  },
  {
    title: "Company",
    links: [
      { label: "About Us", href: "/#features" },
      { label: "Enterprise Solutions", to: "/pricing" },
      { label: "Brand Guidelines", href: "/#features" },
    ],
  },
  {
    title: "Legal",
    links: [
      { label: "Terms of Service", href: "/#faq" },
      { label: "Privacy Policy", href: "/#faq" },
    ],
  },
];

const linkClass = "text-sm text-muted-foreground hover:text-foreground transition-colors";

export function SiteFooter() {
  return (
    <footer className="border-t border-border/50">
      <div className="container mx-auto px-6 py-14">
        <div className="grid gap-10 md:grid-cols-5">
          <div className="md:col-span-1">
            <Logo />
            <p className="mt-3 text-sm text-muted-foreground max-w-xs">
              Intelligence without limits — an elite multimodal AI workspace.
            </p>
          </div>
          {columns.map((col) => (
            <div key={col.title}>
              <h3 className="text-sm font-semibold text-foreground">{col.title}</h3>
              <ul className="mt-4 space-y-2.5">
                {col.links.map((l) => (
                  <li key={l.label}>
                    {l.to ? (
                      <Link to={l.to} className={linkClass}>{l.label}</Link>
                    ) : (
                      <a href={l.href} className={linkClass}>{l.label}</a>
                    )}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        <div className="mt-12 border-t border-border/50 pt-6 text-center text-xs text-muted-foreground">
          © 2026 SMS AI by Deltacoders. All rights reserved.
        </div>
      </div>
    </footer>
  );
}
