import { Component, type ReactNode } from "react";
import { reportLovableError } from "@/lib/lovable-error-reporting";

interface Props { children: ReactNode; fallback?: ReactNode }
interface State { error: Error | null }

export class ErrorBoundary extends Component<Props, State> {
  state: State = { error: null };

  static getDerivedStateFromError(error: Error): State { return { error }; }

  componentDidCatch(error: Error, info: { componentStack?: string | null }) {
    console.error("[ErrorBoundary]", error, info);
    reportLovableError(error, { boundary: "app_error_boundary" });
  }

  reset = () => this.setState({ error: null });

  render() {
    if (this.state.error) {
      if (this.props.fallback) return this.props.fallback;
      return (
        <div className="flex min-h-[40vh] items-center justify-center p-6">
          <div className="glass rounded-2xl p-8 max-w-md text-center">
            <div className="text-xs uppercase tracking-wider text-destructive">Runtime caught</div>
            <h2 className="mt-2 text-xl font-semibold">Something glitched</h2>
            <p className="mt-2 text-sm text-muted-foreground break-words">{this.state.error.message}</p>
            <button onClick={this.reset} className="mt-5 rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:opacity-90">
              Try again
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}
