import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { CheckCircle2, CreditCard, Loader2, ShieldCheck } from "lucide-react";
import { useProfile, type SubscriptionTier } from "@/lib/profile";
import { toast } from "sonner";

type Brand = "visa" | "mastercard" | "amex" | "unknown";
function detectBrand(num: string): Brand {
  const n = num.replace(/\s/g, "");
  if (/^4/.test(n)) return "visa";
  if (/^(5[1-5]|2[2-7])/.test(n)) return "mastercard";
  if (/^3[47]/.test(n)) return "amex";
  return "unknown";
}
const BrandBadge = ({ brand }: { brand: Brand }) => {
  if (brand === "unknown") return null;
  const label = { visa: "VISA", mastercard: "MC", amex: "AMEX" }[brand];
  const color = { visa: "from-blue-500 to-blue-700", mastercard: "from-orange-500 to-red-600", amex: "from-sky-400 to-indigo-600" }[brand];
  return (
    <span className={`inline-flex items-center justify-center rounded-md bg-gradient-to-br ${color} px-2 py-1 text-[10px] font-bold text-white tracking-wider`}>{label}</span>
  );
};

const formatCard = (v: string) => v.replace(/\D/g, "").slice(0, 19).replace(/(.{4})/g, "$1 ").trim();
const formatExp = (v: string) => {
  const d = v.replace(/\D/g, "").slice(0, 4);
  return d.length < 3 ? d : `${d.slice(0, 2)}/${d.slice(2)}`;
};

export function PaymentModal({ open, onOpenChange, tier = "Pro Mode" }: { open: boolean; onOpenChange: (v: boolean) => void; tier?: SubscriptionTier }) {
  const { upgrade } = useProfile();
  const [name, setName] = useState("");
  const [card, setCard] = useState("");
  const [exp, setExp] = useState("");
  const [cvv, setCvv] = useState("");
  const [status, setStatus] = useState<"idle" | "processing" | "success">("idle");
  const [touched, setTouched] = useState(false);

  const brand = detectBrand(card);
  const cardDigits = card.replace(/\s/g, "");
  const cardValid = brand === "amex" ? cardDigits.length === 15 : cardDigits.length >= 16;
  const expValid = /^\d{2}\/\d{2}$/.test(exp);
  const cvvValid = brand === "amex" ? cvv.length === 4 : cvv.length === 3;
  const nameValid = name.trim().length > 1;
  const formValid = cardValid && expValid && cvvValid && nameValid;

  async function pay() {
    setTouched(true);
    if (!formValid) return;
    setStatus("processing");
    await new Promise((r) => setTimeout(r, 2000));
    try {
      await upgrade(tier);
      setStatus("success");
      toast.success(`Welcome to ${tier}! 🎉`);
      setTimeout(() => { onOpenChange(false); setStatus("idle"); }, 1800);
    } catch (e) {
      toast.error((e as Error).message);
      setStatus("idle");
    }
  }

  const err = (ok: boolean) => touched && !ok ? "border-destructive ring-1 ring-destructive/40" : "";

  return (
    <Dialog open={open} onOpenChange={(v) => { if (status !== "processing") onOpenChange(v); }}>
      <DialogContent className="max-w-md glass-strong border-border/60">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <CreditCard className="h-5 w-5 text-primary" />
            Unlock {tier}
          </DialogTitle>
          <DialogDescription>
            Secure checkout — your card details are tokenized and never stored.
          </DialogDescription>
        </DialogHeader>

        <AnimatePresence mode="wait">
          {status === "success" ? (
            <motion.div key="ok" initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="py-10 text-center">
              <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: "spring", stiffness: 200 }} className="mx-auto inline-flex h-16 w-16 items-center justify-center rounded-full bg-emerald-500/20 border border-emerald-500/40">
                <CheckCircle2 className="h-8 w-8 text-emerald-400" />
              </motion.div>
              <h3 className="mt-4 text-xl font-bold">Premium activated</h3>
              <p className="mt-1 text-sm text-muted-foreground">All premium features are now unlocked.</p>
            </motion.div>
          ) : (
            <motion.div key="form" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
              <div>
                <Label>Cardholder name</Label>
                <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Jane Appleseed" className={err(nameValid)} />
              </div>
              <div>
                <Label>Card number</Label>
                <div className="relative">
                  <Input value={card} onChange={(e) => setCard(formatCard(e.target.value))} placeholder="4242 4242 4242 4242" inputMode="numeric" className={`pr-16 font-mono ${err(cardValid)}`} />
                  <div className="absolute right-2 top-1/2 -translate-y-1/2"><BrandBadge brand={brand} /></div>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label>Expiry</Label>
                  <Input value={exp} onChange={(e) => setExp(formatExp(e.target.value))} placeholder="MM/YY" inputMode="numeric" className={`font-mono ${err(expValid)}`} />
                </div>
                <div>
                  <Label>CVV</Label>
                  <Input value={cvv} onChange={(e) => setCvv(e.target.value.replace(/\D/g, "").slice(0, 4))} placeholder={brand === "amex" ? "4 digits" : "3 digits"} inputMode="numeric" className={`font-mono ${err(cvvValid)}`} />
                </div>
              </div>
              <div className="flex items-center gap-2 text-[11px] text-muted-foreground pt-1">
                <ShieldCheck className="h-3.5 w-3.5 text-emerald-400" />
                256-bit TLS · PCI-compliant · No card data stored
              </div>
              <Button onClick={pay} disabled={status === "processing"} className="w-full bg-gradient-to-r from-primary to-primary-glow text-primary-foreground shadow-glow">
                {status === "processing" ? <><Loader2 className="h-4 w-4 mr-2 animate-spin" /> Processing payment…</> : `Pay $19 / month`}
              </Button>
            </motion.div>
          )}
        </AnimatePresence>
      </DialogContent>
    </Dialog>
  );
}
