import { useMemo, useRef, useState, type ReactNode } from "react";
import { Copy, Download, FileSpreadsheet, Lock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

function extractMatrix(node: HTMLTableElement): string[][] {
  return Array.from(node.querySelectorAll("tr")).map((tr) =>
    Array.from(tr.querySelectorAll("th,td")).map((c) => (c.textContent ?? "").trim()),
  );
}

function toMarkdown(rows: string[][]): string {
  if (!rows.length) return "";
  const head = rows[0];
  const body = rows.slice(1);
  const sep = head.map(() => "---");
  return [head, sep, ...body].map((r) => `| ${r.join(" | ")} |`).join("\n");
}

function toCsv(rows: string[][]): string {
  return rows.map((r) => r.map((c) => `"${c.replace(/"/g, '""')}"`).join(",")).join("\n");
}

function escapeXml(v: string): string {
  return v.replace(/[<>&'"]/g, (c) =>
    c === "<" ? "&lt;" : c === ">" ? "&gt;" : c === "&" ? "&amp;" : c === "'" ? "&apos;" : "&quot;",
  );
}

// Excel opens SpreadsheetML 2003 XML natively when saved with a .xls extension.
function toExcelXml(rows: string[][]): string {
  const body = rows
    .map(
      (r) =>
        `<Row>${r
          .map((c) => `<Cell><Data ss:Type="String">${escapeXml(c)}</Data></Cell>`)
          .join("")}</Row>`,
    )
    .join("");
  return `<?xml version="1.0"?>
<?mso-application progid="Excel.Sheet"?>
<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"
 xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">
 <Worksheet ss:Name="SMS AI"><Table>${body}</Table></Worksheet>
</Workbook>`;
}

function downloadBlob(content: string, mime: string, filename: string) {
  const blob = new Blob([content], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

export function ChatTable({ children, isPremium, onUpgrade }: { children?: ReactNode; isPremium: boolean; onUpgrade: () => void }) {
  const ref = useRef<HTMLTableElement>(null);
  const [hover, setHover] = useState(false);

  const actions = useMemo(() => ({
    copyMd: () => {
      if (!ref.current) return;
      navigator.clipboard.writeText(toMarkdown(extractMatrix(ref.current)));
      toast.success("Markdown copied");
    },
    csv: () => {
      if (!ref.current) return;
      downloadBlob(toCsv(extractMatrix(ref.current)), "text/csv", "sms-ai-table.csv");
    },
    xlsx: () => {
      if (!ref.current) return;
      downloadBlob(toExcelXml(extractMatrix(ref.current)), "application/vnd.ms-excel", "sms-ai-table.xls");
    },
  }), []);


  if (!isPremium) {
    return (
      <div className="relative my-4">
        <div className="rounded-xl glass-strong border border-border/50 p-6 text-center">
          <Lock className="h-5 w-5 text-primary mx-auto" />
          <h4 className="mt-2 font-semibold text-sm">Data Matrix locked</h4>
          <p className="mt-1 text-xs text-muted-foreground">Upgrade to Pro Mode to render interactive tables with one-click Excel, CSV, and Markdown export.</p>
          <Button onClick={onUpgrade} size="sm" className="mt-3 bg-gradient-to-r from-primary to-primary-glow text-primary-foreground">
            Unlock 3000 Engine
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="relative my-4 group" onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}>
      <div className={`absolute -top-3 right-2 z-10 flex gap-1 transition-opacity ${hover ? "opacity-100" : "opacity-0"}`}>
        <Button size="sm" variant="secondary" className="h-7 px-2 text-[11px] gap-1" onClick={actions.copyMd}><Copy className="h-3 w-3" />MD</Button>
        <Button size="sm" variant="secondary" className="h-7 px-2 text-[11px] gap-1" onClick={actions.csv}><Download className="h-3 w-3" />CSV</Button>
        <Button size="sm" variant="secondary" className="h-7 px-2 text-[11px] gap-1" onClick={actions.xlsx}><FileSpreadsheet className="h-3 w-3" />XLSX</Button>
      </div>
      <div className="overflow-x-auto rounded-xl border border-border/50 glass">
        <table ref={ref} className="w-full text-sm border-collapse [&_th]:sticky [&_th]:top-0 [&_th]:bg-muted/60 [&_th]:backdrop-blur [&_th]:text-left [&_th]:font-semibold [&_th]:px-3 [&_th]:py-2 [&_td]:px-3 [&_td]:py-2 [&_tr:nth-child(even)]:bg-white/[0.02] [&_tr:hover]:bg-primary/5 [&_tr]:border-b [&_tr]:border-border/40">
          {children}
        </table>
      </div>
    </div>
  );
}
