import type { UIMessage } from "ai";
import { Logo } from "./Logo";
import { AnimatedMarkdown } from "./AnimatedMarkdown";
import { Copy, Check } from "lucide-react";
import { memo, useMemo, useState } from "react";
import { useProfile } from "@/lib/profile";

export const ChatMessage = memo(function ChatMessage({
  message,
  userInitial,
  onUpgrade,
  streaming = false,
}: {
  message: UIMessage;
  userInitial: string;
  onUpgrade: () => void;
  streaming?: boolean;
}) {
  const isUser = message.role === "user";
  const text = useMemo(
    () => message.parts.map((p) => (p.type === "text" ? p.text : "")).join(""),
    [message.parts],
  );
  const [copied, setCopied] = useState(false);
  const { isPremium } = useProfile();

  const copy = () => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  return (
    <div className="group flex gap-4 px-4 py-6 animate-fade-in-up">
      <div className="shrink-0">
        {isUser ? (
          <div className="h-8 w-8 rounded-full bg-gradient-to-br from-primary to-primary-glow flex items-center justify-center text-xs font-semibold text-primary-foreground">
            {userInitial}
          </div>
        ) : (
          <div className="h-8 w-8 rounded-full glass flex items-center justify-center">
            <Logo size={20} withText={false} />
          </div>
        )}
      </div>
      <div className="flex-1 min-w-0">
        <div className="text-xs text-muted-foreground mb-1">{isUser ? "You" : "SMS AI"}</div>
        <div className="prose prose-invert prose-sm max-w-none break-words overflow-x-hidden prose-pre:bg-black/40 prose-pre:border prose-pre:border-border prose-code:text-primary prose-headings:text-foreground prose-strong:text-foreground prose-a:text-primary">
          <AnimatedMarkdown
            text={text}
            streaming={streaming}
            isPremium={isPremium}
            onUpgrade={onUpgrade}
          />
        </div>
        {!isUser && text && !streaming && (
          <button onClick={copy} className="mt-2 inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground opacity-0 group-hover:opacity-100 transition-opacity">
            {copied ? <Check className="h-3 w-3" /> : <Copy className="h-3 w-3" />} {copied ? "Copied" : "Copy"}
          </button>
        )}
      </div>
    </div>
  );
});
