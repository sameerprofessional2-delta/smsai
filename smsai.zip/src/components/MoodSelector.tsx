import { Check, ChevronDown, Sparkles } from "lucide-react";
import { MOODS, useMood, type MoodId } from "@/lib/mood";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { toast } from "sonner";

export function MoodSelector() {
  const { mood, setMood } = useMood();
  const active = MOODS.find((m) => m.id === mood)!;

  function pick(id: MoodId) {
    setMood(id);
    const m = MOODS.find((x) => x.id === id)!;
    toast.success(`Mood: ${m.emoji} ${m.label}`);
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button
          type="button"
          className="inline-flex items-center gap-1.5 rounded-lg border border-border/50 bg-muted/30 px-2.5 py-1.5 text-xs text-foreground/90 hover:bg-muted/60 transition-colors"
          title="AI personality mood"
        >
          <Sparkles className="h-3.5 w-3.5 text-primary" />
          <span>{active.emoji} {active.label}</span>
          <ChevronDown className="h-3 w-3 opacity-60" />
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="start" className="w-64">
        <DropdownMenuLabel className="text-[11px] uppercase tracking-wider text-muted-foreground">
          AI Personality Mood
        </DropdownMenuLabel>
        {MOODS.map((m) => (
          <DropdownMenuItem key={m.id} onClick={() => pick(m.id)} className="gap-2 py-2 cursor-pointer">
            <span className="text-base">{m.emoji}</span>
            <div className="flex-1 min-w-0">
              <div className="text-sm font-medium">{m.label}</div>
              <div className="text-[10.5px] text-muted-foreground truncate">{m.description}</div>
            </div>
            {mood === m.id && <Check className="h-4 w-4 text-primary" />}
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
