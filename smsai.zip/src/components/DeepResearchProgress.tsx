import { Globe, Link2, Brain, Check, Loader2 } from "lucide-react";

export type ResearchPhase = "search" | "analyze" | "synthesize";

const STEPS: Array<{ key: ResearchPhase; label: string; icon: typeof Globe }> = [
  { key: "search", label: "Searching the web…", icon: Globe },
  { key: "analyze", label: "Analyzing links…", icon: Link2 },
  { key: "synthesize", label: "Synthesizing sources…", icon: Brain },
];

/**
 * Step-by-step Deep Research indicator. The active step reflects the *real*
 * stage of the live web-search call (no simulation).
 */
export function DeepResearchProgress({
  query,
  phase,
  sourceCount,
}: {
  query: string;
  phase: ResearchPhase;
  sourceCount: number;
}) {
  const activeIndex = STEPS.findIndex((s) => s.key === phase);
  const pct = Math.round(((activeIndex + 1) / STEPS.length) * 100);

  return (
    <div className="mx-4 my-3 glass rounded-xl p-4 animate-in fade-in slide-in-from-bottom-1">
      <div className="flex items-center gap-2 text-sm">
        <Globe className="h-4 w-4 text-primary animate-pulse" />
        <span className="font-medium">Deep Research</span>
        <span className="ml-auto text-xs text-primary">{pct}%</span>
      </div>

      <div className="mt-3 h-1 overflow-hidden rounded-full bg-muted/40">
        <div
          className="h-full bg-gradient-to-r from-primary to-primary-glow transition-all duration-500"
          style={{ width: `${pct}%` }}
        />
      </div>

      <ul className="mt-3 space-y-1.5">
        {STEPS.map((step, i) => {
          const Icon = step.icon;
          const done = i < activeIndex;
          const active = i === activeIndex;
          return (
            <li
              key={step.key}
              className={
                "flex items-center gap-2 text-xs " +
                (done ? "text-muted-foreground" : active ? "text-foreground" : "text-muted-foreground/50")
              }
            >
              {done ? (
                <Check className="h-3.5 w-3.5 text-primary" />
              ) : active ? (
                <Loader2 className="h-3.5 w-3.5 animate-spin text-primary" />
              ) : (
                <Icon className="h-3.5 w-3.5" />
              )}
              {step.label}
              {step.key === "analyze" && sourceCount > 0 && (
                <span className="text-muted-foreground">· {sourceCount} sources</span>
              )}
            </li>
          );
        })}
      </ul>

      <p className="mt-2 truncate text-[11px] text-muted-foreground">Query: {query}</p>
    </div>
  );
}
