import { Link } from "@tanstack/react-router";
import { Check } from "lucide-react";
import { Button } from "@/components/ui/button";

const tiers = [
  {
    name: "Free",
    price: "$0",
    period: "/mo",
    desc: "Explore the platform at no cost.",
    features: [
      "10 chat messages per day",
      "No document uploads",
      "Standard response speed",
      "Community support",
    ],
    cta: "Start free",
    highlight: false,
  },
  {
    name: "Pro",
    price: "$20",
    period: "/mo",
    desc: "For power users who ship every day.",
    features: [
      "Unlimited chats",
      "Standard document analysis",
      "Priority model speed",
      "GPT Image 2 access",
      "Export to CSV & Excel",
    ],
    cta: "Upgrade to Pro",
    highlight: true,
  },
  {
    name: "Enterprise",
    price: "Custom",
    period: "",
    desc: "For teams with high-volume workloads.",
    features: [
      "Unlimited high-volume RAG processing",
      "Custom API endpoints",
      "Dedicated support & SLA",
      "SSO and audit logging",
    ],
    cta: "Contact sales",
    highlight: false,
  },
];

export function PricingTiers() {
  return (
    <section id="pricing" className="container mx-auto px-6 pb-32">
      <div className="text-center max-w-2xl mx-auto mb-14">
        <h2 className="text-4xl md:text-5xl font-bold">Simple, <span className="text-gradient">transparent pricing</span></h2>
        <p className="mt-4 text-muted-foreground">Start free. Scale when you need to.</p>
      </div>
      <div className="grid gap-6 md:grid-cols-3 max-w-5xl mx-auto items-start">
        {tiers.map((t) => (
          <div
            key={t.name}
            className={`relative glass rounded-2xl p-8 transition-all hover:-translate-y-1 ${
              t.highlight ? "border-primary/50 shadow-glow md:scale-[1.03]" : ""
            }`}
          >
            {t.highlight && (
              <span className="absolute -top-3 left-8 rounded-full bg-gradient-to-r from-primary to-primary-glow px-3 py-1 text-[10px] font-semibold uppercase tracking-wider text-primary-foreground">
                Most popular
              </span>
            )}
            <h3 className="text-lg font-semibold">{t.name}</h3>
            <div className="mt-3 flex items-end gap-1">
              <span className="text-4xl font-bold text-gradient">{t.price}</span>
              <span className="mb-1 text-sm text-muted-foreground">{t.period}</span>
            </div>
            <p className="mt-2 text-sm text-muted-foreground">{t.desc}</p>
            <ul className="mt-6 space-y-3">
              {t.features.map((f) => (
                <li key={f} className="flex gap-2.5 text-sm">
                  <Check className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                  <span className="text-muted-foreground">{f}</span>
                </li>
              ))}
            </ul>
            <Link to="/pricing" className="mt-8 block">
              <Button
                className={`w-full ${
                  t.highlight
                    ? "bg-gradient-to-r from-primary to-primary-glow text-primary-foreground hover:opacity-90"
                    : ""
                }`}
                variant={t.highlight ? "default" : "outline"}
              >
                {t.cta}
              </Button>
            </Link>
          </div>
        ))}
      </div>
    </section>
  );
}
