import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Download, Copy, RefreshCw, ImageIcon, Loader2, ZoomIn } from "lucide-react";
import { streamImage } from "@/lib/streamImage";
import { toast } from "sonner";

const PHASES = [
  "Analyzing prompt…",
  "Synthesizing latent spaces…",
  "Upscaling resolution…",
];

export function ImageGenerator({ open, onOpenChange }: { open: boolean; onOpenChange: (v: boolean) => void }) {
  const [prompt, setPrompt] = useState("");
  const [src, setSrc] = useState<string | null>(null);
  const [isFinal, setIsFinal] = useState(false);
  const [busy, setBusy] = useState(false);
  const [phase, setPhase] = useState(0);
  const [zoom, setZoom] = useState(false);

  async function generate(p?: string) {
    const q = (p ?? prompt).trim();
    if (!q || busy) return;
    setBusy(true); setSrc(null); setIsFinal(false); setPhase(0);
    const phaseTimer = setInterval(() => setPhase((i) => Math.min(i + 1, PHASES.length - 1)), 1800);
    try {
      await streamImage(q, (url, final) => { setSrc(url); if (final) setIsFinal(true); });
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      clearInterval(phaseTimer);
      setBusy(false);
    }
  }

  function download() {
    if (!src) return;
    const a = document.createElement("a"); a.href = src; a.download = "sms-ai-image.png"; a.click();
  }
  async function copyImg() {
    if (!src) return;
    try {
      const blob = await (await fetch(src)).blob();
      await navigator.clipboard.write([new ClipboardItem({ "image/png": blob })]);
      toast.success("Image copied");
    } catch { toast.error("Copy not supported"); }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl glass-strong">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <ImageIcon className="h-5 w-5 text-primary" /> Generative Canvas
          </DialogTitle>
        </DialogHeader>

        <div className="flex gap-2">
          <Input value={prompt} onChange={(e) => setPrompt(e.target.value)} placeholder="A cinematic city skyline at twilight…" onKeyDown={(e) => { if (e.key === "Enter") generate(); }} />
          <Button onClick={() => generate()} disabled={busy || !prompt.trim()} className="bg-gradient-to-r from-primary to-primary-glow text-primary-foreground">
            {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : "Generate"}
          </Button>
        </div>

        <div className="relative aspect-square rounded-xl overflow-hidden border border-border/50 bg-black/30">
          <AnimatePresence>
            {!src && busy && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="absolute inset-0 flex flex-col items-center justify-center gap-3 p-6">
                <div className="h-full w-full absolute inset-0 animate-pulse bg-gradient-to-br from-primary/10 via-transparent to-primary-glow/10" />
                <Loader2 className="h-8 w-8 text-primary animate-spin relative" />
                <div className="text-sm text-muted-foreground relative">{PHASES[phase]}</div>
              </motion.div>
            )}
          </AnimatePresence>
          {src && (
            <motion.img
              key={src}
              src={src}
              alt={prompt}
              initial={{ opacity: 0 }} animate={{ opacity: 1 }}
              className={`h-full w-full object-cover transition-[filter] duration-500 ${isFinal ? "blur-0" : "blur-2xl"}`}
              onClick={() => isFinal && setZoom(true)}
            />
          )}
          {!src && !busy && (
            <div className="absolute inset-0 flex items-center justify-center text-xs text-muted-foreground">Enter a prompt to begin</div>
          )}
        </div>

        {src && isFinal && (
          <div className="flex gap-2">
            <Button variant="secondary" size="sm" onClick={download}><Download className="h-3.5 w-3.5 mr-1" />HD Download</Button>
            <Button variant="secondary" size="sm" onClick={copyImg}><Copy className="h-3.5 w-3.5 mr-1" />Copy</Button>
            <Button variant="secondary" size="sm" onClick={() => generate(prompt)}><RefreshCw className="h-3.5 w-3.5 mr-1" />Vary</Button>
            <Button variant="secondary" size="sm" onClick={() => setZoom(true)}><ZoomIn className="h-3.5 w-3.5 mr-1" />Zoom</Button>
          </div>
        )}

        {zoom && src && (
          <div className="fixed inset-0 z-[100] bg-black/90 backdrop-blur flex items-center justify-center p-6" onClick={() => setZoom(false)}>
            <img src={src} alt="" className="max-h-full max-w-full rounded-lg shadow-glow" />
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
