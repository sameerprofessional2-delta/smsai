import { useState } from "react";
import { Calculator, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface Key { label: string; insert: string; }
const TABS: Record<string, Key[]> = {
  Basic: [
    { label: "+", insert: "+" }, { label: "−", insert: "-" }, { label: "×", insert: "\\times " },
    { label: "÷", insert: "\\div " }, { label: "=", insert: "=" }, { label: "≠", insert: "\\neq " },
    { label: "<", insert: "<" }, { label: ">", insert: ">" }, { label: "≤", insert: "\\leq " },
    { label: "≥", insert: "\\geq " }, { label: "%", insert: "\\%" }, { label: "( )", insert: "(  )" },
  ],
  Algebra: [
    { label: "x²", insert: "x^{2}" }, { label: "xⁿ", insert: "x^{n}" }, { label: "√", insert: "\\sqrt{}" },
    { label: "ⁿ√", insert: "\\sqrt[n]{}" }, { label: "a/b", insert: "\\frac{a}{b}" }, { label: "|x|", insert: "|x|" },
    { label: "log", insert: "\\log_{}" }, { label: "ln", insert: "\\ln(x)" }, { label: "e^x", insert: "e^{x}" },
    { label: "π", insert: "\\pi " }, { label: "θ", insert: "\\theta " }, { label: "∞", insert: "\\infty " },
  ],
  Calculus: [
    { label: "∫", insert: "\\int_{a}^{b} f(x)\\,dx" }, { label: "∮", insert: "\\oint " },
    { label: "d/dx", insert: "\\frac{d}{dx}" }, { label: "∂", insert: "\\partial " },
    { label: "lim", insert: "\\lim_{x \\to 0}" }, { label: "Σ", insert: "\\sum_{i=1}^{n}" },
    { label: "∏", insert: "\\prod_{i=1}^{n}" }, { label: "∇", insert: "\\nabla " },
    { label: "→", insert: "\\to " }, { label: "≈", insert: "\\approx " }, { label: "∝", insert: "\\propto " },
    { label: "δ", insert: "\\delta " },
  ],
  Matrix: [
    { label: "[ ]", insert: "\\begin{bmatrix} a & b \\\\ c & d \\end{bmatrix}" },
    { label: "( )", insert: "\\begin{pmatrix} a & b \\\\ c & d \\end{pmatrix}" },
    { label: "det", insert: "\\det(A)" }, { label: "Aᵀ", insert: "A^{T}" }, { label: "A⁻¹", insert: "A^{-1}" },
    { label: "·", insert: "\\cdot " }, { label: "⊗", insert: "\\otimes " }, { label: "⊕", insert: "\\oplus " },
    { label: "∈", insert: "\\in " }, { label: "∉", insert: "\\notin " }, { label: "∪", insert: "\\cup " }, { label: "∩", insert: "\\cap " },
  ],
};

export function MathKeyboard({ onInsert }: { onInsert: (latex: string) => void }) {
  const [open, setOpen] = useState(false);
  const [tab, setTab] = useState<keyof typeof TABS>("Basic");

  return (
    <div className="relative">
      <Button
        type="button"
        size="icon"
        variant="ghost"
        onClick={() => setOpen((o) => !o)}
        className={cn("h-8 w-8 rounded-lg", open && "bg-primary/15 text-primary")}
        title="Math keyboard"
      >
        <Calculator className="h-4 w-4" />
      </Button>
      {open && (
        <div className="absolute bottom-12 left-0 z-30 w-[min(92vw,420px)] glass-strong border border-border/60 rounded-2xl p-3 shadow-glow animate-in fade-in slide-in-from-bottom-2">
          <div className="flex items-center justify-between mb-2">
            <div className="flex gap-1 flex-wrap">
              {Object.keys(TABS).map((k) => (
                <button
                  key={k}
                  onClick={() => setTab(k as keyof typeof TABS)}
                  className={cn(
                    "px-2.5 py-1 rounded-md text-[11px] font-medium transition-colors",
                    tab === k ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground hover:bg-muted/40",
                  )}
                >
                  {k}
                </button>
              ))}
            </div>
            <button onClick={() => setOpen(false)} className="text-muted-foreground hover:text-foreground">
              <X className="h-3.5 w-3.5" />
            </button>
          </div>
          <div className="grid grid-cols-6 gap-1.5">
            {TABS[tab].map((k) => (
              <button
                key={k.label}
                onClick={() => onInsert(`$${k.insert}$`)}
                className="rounded-lg bg-muted/30 hover:bg-primary/15 hover:text-primary border border-border/40 px-2 py-2 text-sm font-medium transition-colors"
              >
                {k.label}
              </button>
            ))}
          </div>
          <p className="mt-2 text-[10px] text-muted-foreground text-center">Symbols insert as LaTeX · rendered in chat bubbles</p>
        </div>
      )}
    </div>
  );
}
