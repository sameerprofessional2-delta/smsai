import { useEffect, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { ShieldAlert, LogOut, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";

/**
 * Full-screen blocker shown whenever the signed-in user's profile.status === 'blocked'.
 * It also revokes the local session and prevents any child UI from rendering.
 */
export function BlockedGate({ userId, children }: { userId: string; children: React.ReactNode }) {
  const qc = useQueryClient();
  const navigate = useNavigate();
  const [signingOut, setSigningOut] = useState(false);

  const { data, isLoading } = useQuery({
    queryKey: ["profile-status", userId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("profiles")
        .select("status")
        .eq("id", userId)
        .maybeSingle();
      if (error) throw error;
      return (data?.status as "active" | "blocked" | undefined) ?? "active";
    },
    refetchInterval: 8_000,
    refetchOnWindowFocus: true,
  });

  // Realtime kick: when the row updates to blocked, we react immediately
  useEffect(() => {
    const channel = supabase
      .channel(`profile-status-${userId}`)
      .on(
        "postgres_changes",
        { event: "UPDATE", schema: "public", table: "profiles", filter: `id=eq.${userId}` },
        () => qc.invalidateQueries({ queryKey: ["profile-status", userId] }),
      )
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [userId, qc]);

  const blocked = data === "blocked";

  async function forceSignOut() {
    setSigningOut(true);
    try {
      await qc.cancelQueries();
      qc.clear();
      await supabase.auth.signOut();
    } finally {
      navigate({ to: "/auth", replace: true });
    }
  }

  if (isLoading) {
    return (
      <div className="fixed inset-0 z-[100] flex items-center justify-center bg-background">
        <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (blocked) {
    return (
      <div className="fixed inset-0 z-[100] flex items-center justify-center bg-background/95 backdrop-blur-md p-6">
        <div className="glass-strong rounded-2xl p-10 max-w-lg w-full text-center border border-destructive/30">
          <div className="mx-auto inline-flex h-14 w-14 items-center justify-center rounded-full bg-destructive/15 border border-destructive/40">
            <ShieldAlert className="h-7 w-7 text-destructive" />
          </div>
          <div className="mt-5 text-[11px] uppercase tracking-[0.25em] text-destructive">Account Blocked</div>
          <h1 className="mt-2 text-2xl font-bold">Access to SMS AI has been disabled</h1>
          <p className="mt-3 text-sm text-muted-foreground">
            An administrator has blocked this account. AI capabilities, dashboards and chat threads are unavailable
            until your access is restored. If you believe this is a mistake, please contact support.
          </p>
          <Button onClick={forceSignOut} disabled={signingOut} variant="destructive" className="mt-6">
            {signingOut ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <LogOut className="h-4 w-4 mr-2" />}
            Sign out
          </Button>
        </div>
      </div>
    );
  }

  return <>{children}</>;
}
