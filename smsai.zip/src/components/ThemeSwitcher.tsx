import { Check, ChevronDown, Lock, Palette } from "lucide-react";
import { THEMES, useTheme, type ThemeId } from "@/lib/theme";
import { useProfile } from "@/lib/profile";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

export function ThemeSwitcher({ onUpgrade }: { onUpgrade?: () => void }) {
  const { theme, setTheme } = useTheme();
  const { isPremium } = useProfile();
  const active = THEMES.find((t) => t.id === theme);

  function pick(t: ThemeId) {
    const target = THEMES.find((x) => x.id === t)!;
    if (target.premium && !isPremium) {
      toast.error("Premium theme — upgrade to unlock");
      onUpgrade?.();
      return;
    }
    setTheme(t);
    toast.success(`Theme: ${target.label}`);
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="sm" className="gap-2">
          <Palette className="h-4 w-4" />
          <span className="hidden sm:inline">{active?.label ?? "Theme"}</span>
          <ChevronDown className="h-3 w-3 opacity-60" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-72">
        {THEMES.map((t) => {
          const locked = t.premium && !isPremium;
          return (
            <DropdownMenuItem key={t.id} onClick={() => pick(t.id)} className="gap-3 py-2.5 cursor-pointer">
              <div className="flex gap-1">
                {t.swatch.map((c) => (
                  <span key={c} className="h-5 w-2.5 rounded-sm border border-black/20" style={{ background: c }} />
                ))}
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-sm font-medium flex items-center gap-1.5">
                  {t.label}
                  {locked && <Lock className="h-3 w-3 text-muted-foreground" />}
                </div>
                <div className="text-[10.5px] text-muted-foreground truncate">{t.description}</div>
              </div>
              {theme === t.id && <Check className="h-4 w-4 text-primary" />}
            </DropdownMenuItem>
          );
        })}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
