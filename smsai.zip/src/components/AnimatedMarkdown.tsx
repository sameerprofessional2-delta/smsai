import { memo } from "react";
import ReactMarkdown from "react-markdown";
import remarkMath from "remark-math";
import remarkGfm from "remark-gfm";
import rehypeKatex from "rehype-katex";
import { toast } from "sonner";
import { ChatTable } from "./ChatTable";
import { useSmoothWords } from "@/lib/useSmoothWords";

/**
 * Markdown renderer whose token parser works at the word level.
 *
 * A small rehype pass rewrites every text node into per-word <span> elements
 * (whitespace is preserved as plain text so wrapping is unaffected). Because
 * word spans keep stable positions across re-renders, only *newly arrived*
 * words mount — and each mounting word plays the `animate-word-in` fade +
 * 2px upward slide. Markdown structure, layout, colors and spacing are
 * untouched: only the text nodes are wrapped.
 */

type HastNode = {
  type: string;
  tagName?: string;
  value?: string;
  properties?: Record<string, unknown>;
  children?: HastNode[];
};

const NO_SPLIT = new Set(["code", "pre", "math", "style", "script"]);

function splitWords(value: string): HastNode[] {
  const out: HastNode[] = [];
  for (const token of value.split(/(\s+)/)) {
    if (!token) continue;
    if (/^\s+$/.test(token)) {
      out.push({ type: "text", value: token });
      continue;
    }
    out.push({
      type: "element",
      tagName: "span",
      properties: { className: ["word-in"] },
      children: [{ type: "text", value: token }],
    });
  }
  return out;
}

function rehypeWordTokens() {
  return (tree: HastNode) => {
    const walk = (node: HastNode) => {
      if (!node.children?.length) return;
      if (node.tagName && NO_SPLIT.has(node.tagName)) return;

      const next: HastNode[] = [];
      for (const child of node.children) {
        if (child.type === "text" && typeof child.value === "string" && child.value.trim()) {
          next.push(...splitWords(child.value));
        } else {
          if (child.type === "element") walk(child);
          next.push(child);
        }
      }
      node.children = next;
    };
    walk(tree);
  };
}

function extractCodeText(node: unknown): string {
  if (node == null) return "";
  if (typeof node === "string") return node;
  if (typeof node === "number" || typeof node === "boolean") return String(node);
  if (Array.isArray(node)) return node.map(extractCodeText).join("");
  if (typeof node === "object" && "props" in node && node.props && typeof node.props === "object") {
    return extractCodeText((node.props as { children?: unknown }).children);
  }
  return "";
}

export const AnimatedMarkdown = memo(function AnimatedMarkdown({
  text,
  streaming = false,
  isPremium,
  onUpgrade,
}: {
  text: string;
  streaming?: boolean;
  isPremium: boolean;
  onUpgrade: () => void;
}) {
  const shown = useSmoothWords(text, streaming);

  return (
    <div className={streaming ? "stream-words" : undefined}>
      <ReactMarkdown
        remarkPlugins={[remarkMath, remarkGfm]}
        rehypePlugins={[rehypeKatex, rehypeWordTokens]}
        components={{
          table: ({ children }) => (
            <ChatTable isPremium={isPremium} onUpgrade={onUpgrade}>
              {children}
            </ChatTable>
          ),
          a: ({ children, href }) => (
            <a href={href} target="_blank" rel="noopener noreferrer">
              {children}
            </a>
          ),
          pre: ({ children }) => {
            const codeText = extractCodeText(children);
            return (
              <div className="relative group/code my-3">
                <button
                  onClick={() => {
                    navigator.clipboard.writeText(codeText);
                    toast.success("Code copied");
                  }}
                  className="absolute right-2 top-2 z-10 text-[10px] uppercase tracking-wider text-muted-foreground hover:text-foreground bg-black/40 border border-border/50 rounded px-2 py-0.5 opacity-0 group-hover/code:opacity-100 transition-opacity"
                >
                  Copy code
                </button>
                <pre className="overflow-x-auto">{children}</pre>
              </div>
            );
          },
        }}
      >
        {shown || (streaming ? "" : "…")}
      </ReactMarkdown>
      {streaming && (
        <span
          className="ml-0.5 inline-block h-4 w-[2px] translate-y-[2px] bg-primary animate-pulse align-middle"
          aria-hidden
        />
      )}
    </div>
  );
});
