import logo from "@/assets/sms-ai-logo.png";

export function Logo({ size = 32, withText = true }: { size?: number; withText?: boolean }) {
  return (
    <div className="flex items-center gap-2">
      <div className="relative shrink-0" style={{ width: size, height: size }}>
        <div
          className="absolute inset-0 rounded-full bg-primary/40 blur-lg animate-pulse-glow"
          aria-hidden
        />
        <img
          src={logo}
          alt="SMS AI logo"
          width={size}
          height={size}
          className="relative h-full w-full object-contain drop-shadow-[0_0_12px_rgba(80,160,255,0.5)]"
        />
      </div>
      {withText && (
        <span className="font-display text-lg font-bold tracking-tight">
          <span className="text-gradient">SMS</span>
          <span className="text-foreground"> AI</span>
        </span>
      )}
    </div>
  );
}
