import { forwardRef, memo, useImperativeHandle, useRef, type KeyboardEvent } from "react";
import { Button } from "@/components/ui/button";
import { ArrowUp, Loader2 } from "lucide-react";

export type ChatInputHandle = {
  /** Insert a snippet at the caret without any parent re-render. */
  insert: (snippet: string) => void;
  /** Read + clear the DOM value in one shot. */
  take: () => string;
  focus: () => void;
};

type Props = {
  placeholder: string;
  busy: boolean;
  onSubmit: (value: string) => void;
};

/**
 * Fully uncontrolled input: keystrokes mutate only the DOM node.
 * Zero parent re-renders while typing — the send button's disabled state
 * is driven imperatively via a direct style/attribute write, not React state.
 */
export const ChatInput = memo(
  forwardRef<ChatInputHandle, Props>(function ChatInput({ placeholder, busy, onSubmit }, ref) {
    const taRef = useRef<HTMLTextAreaElement>(null);

    useImperativeHandle(ref, () => ({
      insert(snippet: string) {
        const el = taRef.current;
        if (!el) return;
        const start = el.selectionStart ?? el.value.length;
        const end = el.selectionEnd ?? el.value.length;
        el.value = el.value.slice(0, start) + snippet + el.value.slice(end);
        const pos = start + snippet.length;
        el.focus();
        el.setSelectionRange(pos, pos);
        autoGrow(el);
      },
      take() {
        const el = taRef.current;
        if (!el) return "";
        const v = el.value;
        el.value = "";
        el.style.height = "48px";
        return v;
      },
      focus() {
        taRef.current?.focus();
      },
    }));

    const autoGrow = (el: HTMLTextAreaElement) => {
      el.style.height = "48px";
      el.style.height = Math.min(el.scrollHeight, 160) + "px";
    };

    const send = () => {
      const el = taRef.current;
      if (!el) return;
      const value = el.value.trim();
      if (!value) return;
      el.value = "";
      el.style.height = "48px";
      onSubmit(value);
      el.focus();
    };

    const onKeyDown = (e: KeyboardEvent<HTMLTextAreaElement>) => {
      if (e.key === "Enter" && !e.shiftKey) {
        e.preventDefault();
        send();
      }
    };

    return (
      <div className="relative glass rounded-2xl border-border/50">
        <textarea
          ref={taRef}
          onKeyDown={onKeyDown}
          onInput={(e) => autoGrow(e.currentTarget)}
          rows={1}
          placeholder={placeholder}
          spellCheck={false}
          className="w-full resize-none bg-transparent px-4 py-3 pr-14 text-sm outline-none placeholder:text-muted-foreground max-h-40"
          style={{ minHeight: "48px", height: "48px", contain: "layout style" }}
        />
        <Button
          size="icon"
          onClick={send}
          disabled={busy}
          className="absolute right-2 bottom-2 h-8 w-8 rounded-lg bg-gradient-to-r from-primary to-primary-glow text-primary-foreground"
        >
          {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <ArrowUp className="h-4 w-4" />}
        </Button>
      </div>
    );
  }),
);
