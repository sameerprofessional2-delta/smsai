import { useRef, useState } from "react";
import { Paperclip, X, FileText, Image as ImageIcon, FileSpreadsheet, File as FileIcon, Loader2 } from "lucide-react";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { cn } from "@/lib/utils";

export type Attachment = {
  id: string;
  name: string;
  size: number;
  type: string;
  url?: string;
  excerpt?: string;
  status: "reading" | "ready";
};

function iconFor(type: string) {
  if (type.startsWith("image/")) return ImageIcon;
  if (type === "application/pdf") return FileText;
  if (type.includes("csv") || type.includes("sheet")) return FileSpreadsheet;
  return FileIcon;
}

const KINDS = [
  { label: "Documents", accept: ".pdf,.doc,.docx,.txt,.md,.rtf" },
  { label: "Images", accept: "image/*" },
  { label: "Data / Sheets", accept: ".csv,.tsv,.xls,.xlsx,.json" },
  { label: "Code & archives", accept: ".ts,.tsx,.js,.py,.java,.go,.rs,.sql,.zip" },
  { label: "Any file type", accept: "*/*" },
];

const TEXT_LIKE = /^(text\/|application\/(json|xml|javascript|sql))/;

export function AttachMenu({
  attachments,
  onChange,
}: {
  attachments: Attachment[];
  onChange: (next: Attachment[]) => void;
}) {
  const [open, setOpen] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const acceptRef = useRef("*/*");

  const pick = (accept: string) => {
    acceptRef.current = accept;
    if (inputRef.current) {
      inputRef.current.accept = accept;
      inputRef.current.value = "";
      inputRef.current.click();
    }
    setOpen(false);
  };

  const ingest = async (list: FileList | null) => {
    if (!list?.length) return;
    const files = Array.from(list);
    const staged: Attachment[] = files.map((f) => ({
      id: crypto.randomUUID(),
      name: f.name,
      size: f.size,
      type: f.type || "application/octet-stream",
      url: f.type.startsWith("image/") ? URL.createObjectURL(f) : undefined,
      status: "reading" as const,
    }));
    let current = [...attachments, ...staged];
    onChange(current);

    await Promise.all(
      files.map(async (f, i) => {
        let excerpt = "";
        if (TEXT_LIKE.test(f.type) || /\.(txt|md|csv|tsv|json|ts|tsx|js|py|sql)$/i.test(f.name)) {
          try {
            excerpt = (await f.text()).slice(0, 6000);
          } catch {
            /* ignore */
          }
        }
        current = current.map((a) =>
          a.id === staged[i].id ? { ...a, excerpt, status: "ready" as const } : a,
        );
        onChange(current);
      }),
    );
  };

  return (
    <>
      <input
        ref={inputRef}
        type="file"
        multiple
        hidden
        onChange={(e) => void ingest(e.target.files)}
      />
      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <button
            type="button"
            className={cn(
              "inline-flex items-center gap-1.5 rounded-lg border px-2.5 py-1.5 text-xs transition-colors",
              attachments.length
                ? "border-primary/60 bg-primary/15 text-primary"
                : "border-border/50 text-muted-foreground hover:text-foreground hover:bg-muted/40",
            )}
            title="Attach files"
          >
            <Paperclip className="h-3.5 w-3.5" />
            Attach{attachments.length ? ` · ${attachments.length}` : ""}
          </button>
        </PopoverTrigger>
        <PopoverContent align="start" className="w-64 p-2 glass-strong">
          <p className="px-2 py-1.5 text-[11px] uppercase tracking-wider text-muted-foreground">
            Attach anything
          </p>
          {KINDS.map((k) => (
            <button
              key={k.label}
              onClick={() => pick(k.accept)}
              className="w-full rounded-lg px-2 py-2 text-left text-sm hover:bg-muted/50 transition-colors"
            >
              {k.label}
            </button>
          ))}
        </PopoverContent>
      </Popover>

      {attachments.length > 0 && (
        <div className="flex w-full flex-wrap gap-2 pt-1">
          {attachments.map((a) => {
            const Icon = iconFor(a.type);
            return (
              <span
                key={a.id}
                className="inline-flex items-center gap-2 rounded-lg border border-border/50 bg-muted/30 px-2 py-1 text-xs"
              >
                {a.status === "reading" ? (
                  <Loader2 className="h-3.5 w-3.5 animate-spin text-primary" />
                ) : (
                  <Icon className="h-3.5 w-3.5 text-primary" />
                )}
                <span className="max-w-[160px] truncate">{a.name}</span>
                <button
                  onClick={() => onChange(attachments.filter((x) => x.id !== a.id))}
                  className="text-muted-foreground hover:text-foreground"
                  aria-label={`Remove ${a.name}`}
                >
                  <X className="h-3 w-3" />
                </button>
              </span>
            );
          })}
        </div>
      )}
    </>
  );
}

export function attachmentsToPrompt(attachments: Attachment[]): string {
  if (!attachments.length) return "";
  const blocks = attachments.map((a) => {
    const size = `${(a.size / 1024).toFixed(1)} KB`;
    const body = a.excerpt
      ? `\nExtracted content (truncated):\n"""\n${a.excerpt.slice(0, 4000)}\n"""`
      : `\n(Binary/${a.type} file — describe how you would analyse it and ask for any needed detail.)`;
    return `- ${a.name} (${a.type}, ${size})${body}`;
  });
  return `[Attached files]\n${blocks.join("\n")}\n\nUser message: `;
}
