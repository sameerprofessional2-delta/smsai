import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Activity, Bug, Sparkles, Trash2, Pause, Play } from "lucide-react";

type Level = "info" | "warn" | "error" | "ok";
interface LogEntry { id: string; t: string; level: Level; tag: string; msg: string; }

const SAMPLES: Array<Omit<LogEntry, "id" | "t">> = [
  { level: "info", tag: "net", msg: "GET /api/chat → 200 (142ms)" },
  { level: "ok", tag: "stream", msg: "stream chunk delivered (24 tokens)" },
  { level: "warn", tag: "latency", msg: "model RTT 1284ms — above p95 budget" },
  { level: "info", tag: "auth", msg: "session refresh ok (jwt)" },
  { level: "error", tag: "api", msg: "POST /api/files → 504 gateway timeout" },
  { level: "ok", tag: "cache", msg: "thread:abc warm hit (Δ 3ms)" },
  { level: "warn", tag: "memory", msg: "context window 84% used" },
  { level: "info", tag: "router", msg: "navigate → /chat/$threadId" },
  { level: "error", tag: "fn", msg: "tool.search() rejected: rate_limited" },
  { level: "ok", tag: "supabase", msg: "rls policy check passed" },
];

const colorFor: Record<Level, string> = {
  info: "text-sky-400",
  warn: "text-amber-400",
  error: "text-rose-400",
  ok: "text-emerald-400",
};

function nowStr() {
  const d = new Date();
  return d.toTimeString().slice(0, 8) + "." + String(d.getMilliseconds()).padStart(3, "0");
}

export function DebugPanel() {
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [running, setRunning] = useState(true);
  const [optimizing, setOptimizing] = useState(false);
  const [progress, setProgress] = useState(0);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!running) return;
    const id = setInterval(() => {
      const s = SAMPLES[Math.floor(Math.random() * SAMPLES.length)];
      setLogs((l) => [...l.slice(-120), { ...s, id: crypto.randomUUID(), t: nowStr() }]);
    }, 1100);
    return () => clearInterval(id);
  }, [running]);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight });
  }, [logs]);

  async function fixAndClean() {
    setOptimizing(true);
    setProgress(0);
    const steps = [
      "Scanning component tree…",
      "Pruning stale query cache…",
      "Deduping network requests…",
      "Recompiling style tokens…",
      "Compacting log buffer…",
      "Re-running RLS sanity checks…",
      "All systems nominal.",
    ];
    for (let i = 0; i < steps.length; i++) {
      await new Promise((r) => setTimeout(r, 380));
      setProgress(Math.round(((i + 1) / steps.length) * 100));
      setLogs((l) => [...l, { id: crypto.randomUUID(), t: nowStr(), level: i === steps.length - 1 ? "ok" : "info", tag: "optimizer", msg: steps[i] }]);
    }
    setOptimizing(false);
  }

  const counts = logs.reduce(
    (acc, l) => ((acc[l.level]++, acc)),
    { info: 0, warn: 0, error: 0, ok: 0 } as Record<Level, number>,
  );

  return (
    <div className="glass rounded-2xl p-5">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-2">
          <Bug className="h-4 w-4 text-primary" />
          <h2 className="font-semibold">System Logs · Debug Panel</h2>
        </div>
        <div className="flex items-center gap-2">
          <Button size="sm" variant="ghost" onClick={() => setRunning((r) => !r)}>
            {running ? <Pause className="h-3.5 w-3.5 mr-1.5" /> : <Play className="h-3.5 w-3.5 mr-1.5" />}
            {running ? "Pause" : "Resume"}
          </Button>
          <Button size="sm" variant="ghost" onClick={() => setLogs([])}>
            <Trash2 className="h-3.5 w-3.5 mr-1.5" /> Clear
          </Button>
          <Button size="sm" disabled={optimizing} onClick={fixAndClean} className="bg-gradient-to-r from-primary to-primary-glow text-primary-foreground">
            <Sparkles className={`h-3.5 w-3.5 mr-1.5 ${optimizing ? "animate-spin" : ""}`} /> Fix & Clean
          </Button>
        </div>
      </div>

      <div className="mt-4 grid grid-cols-4 gap-2 text-xs">
        {(["info", "ok", "warn", "error"] as Level[]).map((k) => (
          <div key={k} className="rounded-lg bg-muted/30 px-3 py-2">
            <div className={`uppercase tracking-wider ${colorFor[k]}`}>{k}</div>
            <div className="text-lg font-semibold">{counts[k]}</div>
          </div>
        ))}
      </div>

      {optimizing && (
        <div className="mt-4">
          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <span className="flex items-center gap-1.5"><Activity className="h-3 w-3 animate-pulse" /> Optimizing runtime…</span>
            <span>{progress}%</span>
          </div>
          <div className="mt-1 h-1.5 rounded-full bg-muted/40 overflow-hidden">
            <div className="h-full bg-gradient-to-r from-primary to-primary-glow transition-all" style={{ width: `${progress}%` }} />
          </div>
        </div>
      )}

      <div
        ref={scrollRef}
        className="mt-4 h-72 overflow-y-auto rounded-xl border border-border/50 bg-black/40 p-3 font-mono text-[11px] leading-relaxed"
      >
        {logs.length === 0 && <div className="text-muted-foreground">Awaiting telemetry…</div>}
        {logs.map((l) => (
          <div key={l.id} className="flex gap-2">
            <span className="text-muted-foreground/60 shrink-0">{l.t}</span>
            <span className={`shrink-0 w-12 uppercase ${colorFor[l.level]}`}>{l.level}</span>
            <span className="text-muted-foreground shrink-0">[{l.tag}]</span>
            <span className="text-foreground/90 break-all">{l.msg}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
